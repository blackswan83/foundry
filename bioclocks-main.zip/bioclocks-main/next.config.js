/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Enable standalone for containerized deployment
  output: 'standalone',
  // Ensure images work in standalone mode
  images: {
    unoptimized: true,
  },
}

module.exports = nextConfig
