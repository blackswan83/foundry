import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format a number with appropriate decimal places
 */
export function formatNumber(value: number, decimals: number = 1): string {
  return value.toFixed(decimals);
}

/**
 * Get age interpretation text
 */
export function getAgeInterpretationText(difference: number): string {
  const absDiff = Math.abs(difference);
  const years = absDiff === 1 ? 'year' : 'years';

  if (difference <= -2) {
    return `${formatNumber(absDiff, 1)} ${years} younger`;
  } else if (difference >= 2) {
    return `${formatNumber(absDiff, 1)} ${years} older`;
  }
  return 'On track';
}

/**
 * Get color class based on age interpretation
 */
export function getAgeColor(interpretation: 'younger' | 'ontrack' | 'older'): string {
  switch (interpretation) {
    case 'younger':
      return 'text-semantic-success';
    case 'older':
      return 'text-semantic-error';
    default:
      return 'text-semantic-warning';
  }
}

/**
 * Get background color class based on age interpretation
 */
export function getAgeBgColor(interpretation: 'younger' | 'ontrack' | 'older'): string {
  switch (interpretation) {
    case 'younger':
      return 'bg-semantic-success-light';
    case 'older':
      return 'bg-semantic-error-light';
    default:
      return 'bg-semantic-warning-light';
  }
}

/**
 * Store data in localStorage
 */
export function saveToStorage<T>(key: string, data: T): void {
  if (typeof window !== 'undefined') {
    localStorage.setItem(key, JSON.stringify(data));
  }
}

/**
 * Load data from localStorage
 */
export function loadFromStorage<T>(key: string): T | null {
  if (typeof window !== 'undefined') {
    const data = localStorage.getItem(key);
    if (data) {
      try {
        return JSON.parse(data) as T;
      } catch {
        return null;
      }
    }
  }
  return null;
}

/**
 * Generate a unique ID
 */
export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}
