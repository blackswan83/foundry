/**
 * Klemera-Doubal Method (KDM) Biological Age Calculator
 *
 * Based on: Klemera P, Doubal S. "A new approach to the concept and computation
 * of biological age." Mechanisms of Ageing and Development. 2006;127(3):240-248.
 * DOI: 10.1016/j.mad.2005.10.004
 *
 * Implementation follows the BioAge R package methodology with NHANES-derived
 * regression coefficients for biomarker-age relationships.
 */

import {
  NormalizedBiomarkers,
  BiologicalAgeResult,
  ClockInfo,
  BiomarkerContribution,
  AgeInterpretation,
} from './types';
import { BIOMARKER_INFO, KDM_REQUIRED_BIOMARKERS } from './biomarkers';

// KDM biomarker regression parameters (slope, intercept, residual SD)
// Derived from NHANES reference population
// Each biomarker is regressed on chronological age
const KDM_BIOMARKER_PARAMS: Record<string, { slope: number; intercept: number; sd: number }> = {
  albumin: {
    slope: -0.0127,    // Albumin decreases with age
    intercept: 4.645,
    sd: 0.351,
  },
  creatinine: {
    slope: 0.0050,     // Creatinine increases with age
    intercept: 0.765,
    sd: 0.225,
  },
  glucose: {
    slope: 0.2897,     // Glucose increases with age
    intercept: 88.57,
    sd: 22.93,
  },
  cReactiveProtein: {
    slope: 0.0045,     // CRP increases with age (log scale)
    intercept: -1.452,
    sd: 1.147,
  },
  alkalinePhosphatase: {
    slope: 0.3856,     // ALP increases with age
    intercept: 52.21,
    sd: 22.47,
  },
  bloodUreaNitrogen: {
    slope: 0.1512,     // BUN increases with age
    intercept: 10.23,
    sd: 5.12,
  },
  totalCholesterol: {
    slope: 0.2145,     // Cholesterol generally increases then decreases
    intercept: 189.5,
    sd: 38.24,
  },
  systolicBloodPressure: {
    slope: 0.4821,     // SBP increases with age
    intercept: 107.3,
    sd: 16.43,
  },
  whiteBloodCellCount: {
    slope: 0.0124,
    intercept: 6.23,
    sd: 1.95,
  },
  lymphocytePercent: {
    slope: -0.1356,    // Lymphocyte % decreases with age
    intercept: 36.82,
    sd: 8.47,
  },
  meanCellVolume: {
    slope: 0.0524,
    intercept: 86.4,
    sd: 5.12,
  },
  redCellDistributionWidth: {
    slope: 0.0253,     // RDW increases with age
    intercept: 12.4,
    sd: 1.12,
  },
};

// Chronological age variance parameter
const CHRONO_AGE_VARIANCE = 6.52; // Standard error of chronological age estimate

export const KDM_INFO: ClockInfo = {
  name: 'KDM Biological Age',
  version: '2.0',
  description:
    'Klemera-Doubal Method biological age uses regression-based approach to combine ' +
    'multiple biomarkers into a single biological age estimate. Validated in the CALERIE trial.',
  publication: {
    authors: 'Klemera P, Doubal S',
    title: 'A new approach to the concept and computation of biological age',
    journal: 'Mechanisms of Ageing and Development',
    year: 2006,
    doi: '10.1016/j.mad.2005.10.004',
  },
  requiredBiomarkers: ['albumin', 'creatinine', 'glucose', 'cReactiveProtein', 'alkalinePhosphatase'],
  optionalBiomarkers: ['bloodUreaNitrogen', 'totalCholesterol', 'systolicBloodPressure'],
  validationMetrics: {
    correlationWithAge: 0.89,
    mortalityHazardRatio: 1.35,
    mortalityHazardRatioCI: [1.28, 1.43],
  },
};

/**
 * Calculate KDM Biological Age
 *
 * The KDM method works by:
 * 1. For each biomarker, calculate the expected value at each age using regression
 * 2. For each biomarker, calculate what age would predict the observed value
 * 3. Combine these "biomarker ages" weighted by their reliability (inverse variance)
 * 4. Also incorporate chronological age with its own weight
 */
export function calculateKDM(biomarkers: NormalizedBiomarkers): BiologicalAgeResult {
  // Get available biomarkers with KDM parameters
  const availableBiomarkers = getAvailableBiomarkers(biomarkers);

  if (availableBiomarkers.length < 3) {
    throw new Error('KDM requires at least 3 biomarkers with known parameters');
  }

  // Step 1: Calculate "biomarker age" for each available biomarker
  // and accumulate weighted sum
  let numerator = 0;
  let denominator = 0;

  const biomarkerAges: { name: string; age: number; weight: number }[] = [];

  for (const biomarkerId of availableBiomarkers) {
    const params = KDM_BIOMARKER_PARAMS[biomarkerId];
    const value = getBiomarkerValue(biomarkers, biomarkerId);

    if (value === undefined || params.slope === 0) continue;

    // Transform CRP to log scale
    const transformedValue = biomarkerId === 'cReactiveProtein'
      ? Math.log(Math.max(value, 0.001))
      : value;

    // Calculate the age that would predict this biomarker value
    // Rearranging: value = intercept + slope * age
    // => age = (value - intercept) / slope
    const biomarkerAge = (transformedValue - params.intercept) / params.slope;

    // Weight is inverse of variance (slope^2 / sd^2)
    const weight = (params.slope * params.slope) / (params.sd * params.sd);

    // Add to weighted sum
    numerator += weight * biomarkerAge;
    denominator += weight;

    biomarkerAges.push({
      name: BIOMARKER_INFO[biomarkerId]?.name || biomarkerId,
      age: biomarkerAge,
      weight,
    });
  }

  // Step 2: Add chronological age contribution
  // Weight for chronological age based on its variance
  const chronoWeight = 1 / (CHRONO_AGE_VARIANCE * CHRONO_AGE_VARIANCE);
  numerator += chronoWeight * biomarkers.chronologicalAge;
  denominator += chronoWeight;

  // Step 3: Calculate final KDM biological age
  const kdmAge = numerator / denominator;

  // Calculate age difference
  const ageDifference = kdmAge - biomarkers.chronologicalAge;

  // Determine interpretation
  const interpretation = getInterpretation(ageDifference);

  // Calculate biomarker contributions
  const contributions = calculateBiomarkerContributions(biomarkers, availableBiomarkers);

  // Generate recommendations
  const recommendations = generateRecommendations(biomarkers, contributions);

  // Confidence score based on number of biomarkers used
  const maxBiomarkers = Object.keys(KDM_BIOMARKER_PARAMS).length;
  const confidenceScore = Math.min(100, Math.round((availableBiomarkers.length / maxBiomarkers) * 100 + 20));

  return {
    clockName: KDM_INFO.name,
    clockVersion: KDM_INFO.version,
    biologicalAge: Math.round(kdmAge * 10) / 10,
    chronologicalAge: biomarkers.chronologicalAge,
    ageDifference: Math.round(ageDifference * 10) / 10,
    confidenceScore,
    interpretation,
    biomarkerContributions: contributions,
    recommendations,
  };
}

/**
 * Get list of biomarkers that are available and have KDM parameters
 */
function getAvailableBiomarkers(biomarkers: NormalizedBiomarkers): string[] {
  const available: string[] = [];

  for (const biomarkerId of Object.keys(KDM_BIOMARKER_PARAMS)) {
    const value = getBiomarkerValue(biomarkers, biomarkerId);
    if (value !== undefined && value > 0) {
      available.push(biomarkerId);
    }
  }

  return available;
}

/**
 * Get a biomarker value from the normalized biomarkers object
 */
function getBiomarkerValue(
  biomarkers: NormalizedBiomarkers,
  biomarkerId: string
): number | undefined {
  return (biomarkers as unknown as Record<string, number | undefined>)[biomarkerId];
}

/**
 * Get interpretation category based on age difference
 */
function getInterpretation(ageDifference: number): AgeInterpretation {
  if (ageDifference <= -2) {
    return 'younger';
  } else if (ageDifference >= 2) {
    return 'older';
  }
  return 'ontrack';
}

/**
 * Calculate biomarker contributions for KDM
 */
function calculateBiomarkerContributions(
  biomarkers: NormalizedBiomarkers,
  availableBiomarkers: string[]
): BiomarkerContribution[] {
  const contributions: BiomarkerContribution[] = [];

  for (const biomarkerId of availableBiomarkers) {
    const info = BIOMARKER_INFO[biomarkerId];
    if (!info) continue;

    const value = getBiomarkerValue(biomarkers, biomarkerId);
    if (value === undefined) continue;

    const params = KDM_BIOMARKER_PARAMS[biomarkerId];
    const range = info.referenceRanges[biomarkers.sex];

    // Calculate expected value at current age
    const expectedValue = params.intercept + params.slope * biomarkers.chronologicalAge;

    // Transform for CRP
    const transformedValue = biomarkerId === 'cReactiveProtein'
      ? Math.log(Math.max(value, 0.001))
      : value;
    const transformedExpected = biomarkerId === 'cReactiveProtein'
      ? Math.log(Math.max(expectedValue, 0.001))
      : expectedValue;

    // Deviation from expected (positive = aging faster for increasing biomarkers)
    const deviation = (transformedValue - transformedExpected) * Math.sign(params.slope);

    // Determine status
    let status: 'optimal' | 'suboptimal' | 'concerning';
    if (value >= range.min && value <= range.max) {
      status = 'optimal';
    } else if (value >= range.min * 0.8 && value <= range.max * 1.2) {
      status = 'suboptimal';
    } else {
      status = 'concerning';
    }

    contributions.push({
      name: info.name,
      value,
      unit: info.usUnit,
      contribution: deviation,
      status,
      referenceRange: {
        min: range.min,
        max: range.max,
      },
    });
  }

  // Sort by absolute contribution
  return contributions.sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
}

/**
 * Generate recommendations based on KDM results
 */
function generateRecommendations(
  biomarkers: NormalizedBiomarkers,
  contributions: BiomarkerContribution[]
): string[] {
  const recommendations: string[] = [];

  const concerningBiomarkers = contributions.filter(c => c.status === 'concerning');
  const suboptimalBiomarkers = contributions.filter(c => c.status === 'suboptimal');

  // Blood pressure
  if (biomarkers.systolicBloodPressure && biomarkers.systolicBloodPressure > 130) {
    recommendations.push(
      'Elevated blood pressure contributes to accelerated aging. Consider DASH diet, ' +
      'sodium reduction, regular aerobic exercise, and stress management techniques.'
    );
  }

  // Cholesterol
  if (biomarkers.totalCholesterol && biomarkers.totalCholesterol > 240) {
    recommendations.push(
      'High cholesterol levels detected. Focus on reducing saturated fats, increasing fiber, ' +
      'and adding plant sterols to your diet. Regular cardiovascular exercise is also beneficial.'
    );
  }

  // BUN - kidney function
  if (biomarkers.bloodUreaNitrogen && biomarkers.bloodUreaNitrogen > 20) {
    recommendations.push(
      'Elevated BUN may indicate kidney stress. Ensure adequate hydration and consider ' +
      'reducing protein intake if very high. Consult with your healthcare provider.'
    );
  }

  // General metabolic health
  if (biomarkers.glucose && biomarkers.glucose > 100 &&
      biomarkers.cReactiveProtein && biomarkers.cReactiveProtein > 0.3) {
    recommendations.push(
      'Both glucose and inflammation markers are elevated, suggesting metabolic stress. ' +
      'A combined approach of anti-inflammatory diet and regular exercise may be particularly beneficial.'
    );
  }

  if (concerningBiomarkers.length === 0 && suboptimalBiomarkers.length <= 2) {
    recommendations.push(
      'Your KDM biomarker profile is within healthy ranges. Maintain your current healthy habits.'
    );
  }

  return recommendations;
}

export { getAvailableBiomarkers };
