/**
 * Unit conversion utilities for international biomarker support
 * Converts between US conventional units and SI (International) units
 */

import { BiomarkerInput, NormalizedBiomarkers, UnitSystem } from './types';
import { BIOMARKER_INFO } from './biomarkers';

/**
 * Convert a single biomarker value from SI to US units
 */
export function siToUs(biomarkerId: string, siValue: number): number {
  const info = BIOMARKER_INFO[biomarkerId];
  if (!info || info.conversionFactor === 1) {
    return siValue;
  }

  // SI to US is the reverse of US to SI
  return siValue / info.conversionFactor;
}

/**
 * Convert a single biomarker value from US to SI units
 */
export function usToSi(biomarkerId: string, usValue: number): number {
  const info = BIOMARKER_INFO[biomarkerId];
  if (!info || info.conversionFactor === 1) {
    return usValue;
  }

  return usValue * info.conversionFactor;
}

/**
 * Normalize biomarker input to US units for calculation
 * All clock algorithms use US conventional units
 */
export function normalizeBiomarkers(
  input: BiomarkerInput,
  unitSystem: UnitSystem
): NormalizedBiomarkers {
  // If already in US units, just restructure
  if (unitSystem === 'us') {
    return {
      chronologicalAge: input.chronologicalAge,
      sex: input.sex,
      whiteBloodCellCount: input.whiteBloodCellCount,
      lymphocytePercent: input.lymphocytePercent,
      meanCellVolume: input.meanCellVolume,
      redCellDistributionWidth: input.redCellDistributionWidth,
      albumin: input.albumin,
      creatinine: input.creatinine,
      glucose: input.glucose,
      alkalinePhosphatase: input.alkalinePhosphatase,
      cReactiveProtein: input.cReactiveProtein,
      bloodUreaNitrogen: input.bloodUreaNitrogen,
      totalCholesterol: input.totalCholesterol,
      hba1c: input.hba1c,
      systolicBloodPressure: input.systolicBloodPressure,
      uricAcid: input.uricAcid,
    };
  }

  // Convert from SI to US
  return {
    chronologicalAge: input.chronologicalAge,
    sex: input.sex,
    whiteBloodCellCount: siToUs('whiteBloodCellCount', input.whiteBloodCellCount),
    lymphocytePercent: input.lymphocytePercent, // Same units
    meanCellVolume: input.meanCellVolume, // Same units
    redCellDistributionWidth: input.redCellDistributionWidth, // Same units
    albumin: siToUs('albumin', input.albumin),
    creatinine: siToUs('creatinine', input.creatinine),
    glucose: siToUs('glucose', input.glucose),
    alkalinePhosphatase: input.alkalinePhosphatase, // Same units
    cReactiveProtein: siToUs('cReactiveProtein', input.cReactiveProtein),
    bloodUreaNitrogen: input.bloodUreaNitrogen !== undefined
      ? siToUs('bloodUreaNitrogen', input.bloodUreaNitrogen)
      : undefined,
    totalCholesterol: input.totalCholesterol !== undefined
      ? siToUs('totalCholesterol', input.totalCholesterol)
      : undefined,
    hba1c: input.hba1c, // Same units
    systolicBloodPressure: input.systolicBloodPressure, // Same units
    uricAcid: input.uricAcid !== undefined
      ? siToUs('uricAcid', input.uricAcid)
      : undefined,
  };
}

/**
 * Get the appropriate unit string for display
 */
export function getUnitString(biomarkerId: string, unitSystem: UnitSystem): string {
  const info = BIOMARKER_INFO[biomarkerId];
  if (!info) return '';

  return unitSystem === 'us' ? info.usUnit : info.siUnit;
}

/**
 * Get display value in user's preferred unit system
 */
export function getDisplayValue(
  biomarkerId: string,
  usValue: number,
  targetSystem: UnitSystem
): number {
  if (targetSystem === 'us') {
    return usValue;
  }
  return usToSi(biomarkerId, usValue);
}

/**
 * Format a biomarker value for display with appropriate precision
 */
export function formatBiomarkerValue(
  biomarkerId: string,
  value: number,
  unitSystem: UnitSystem
): string {
  const displayValue = getDisplayValue(biomarkerId, value, unitSystem);
  const unit = getUnitString(biomarkerId, unitSystem);

  // Determine appropriate decimal places based on biomarker
  let decimals = 1;
  if (biomarkerId === 'cReactiveProtein') {
    decimals = 2;
  } else if (['whiteBloodCellCount', 'glucose', 'alkalinePhosphatase'].includes(biomarkerId)) {
    decimals = 0;
  }

  return `${displayValue.toFixed(decimals)} ${unit}`;
}

/**
 * Validate that a biomarker value is within plausible physiological range
 */
export function validateBiomarkerRange(
  biomarkerId: string,
  value: number,
  sex: 'male' | 'female'
): { valid: boolean; warning?: string } {
  const info = BIOMARKER_INFO[biomarkerId];
  if (!info) {
    return { valid: true };
  }

  const range = info.referenceRanges[sex];

  // Allow 3x outside reference range as "plausible" but warn if outside reference
  const minPlausible = range.min * 0.2;
  const maxPlausible = range.max * 3;

  if (value < minPlausible || value > maxPlausible) {
    return {
      valid: false,
      warning: `Value ${value} is outside plausible physiological range for ${info.name}`,
    };
  }

  if (value < range.min || value > range.max) {
    return {
      valid: true,
      warning: `Value is outside normal reference range (${range.min}-${range.max})`,
    };
  }

  return { valid: true };
}
