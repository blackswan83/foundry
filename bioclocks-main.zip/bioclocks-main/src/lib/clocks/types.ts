/**
 * Types for Biological Age Clock calculations
 */

// Unit systems for international compatibility
export type UnitSystem = 'us' | 'si';

// Raw biomarker values as entered by user
export interface BiomarkerInput {
  // Demographics
  chronologicalAge: number;
  sex: 'male' | 'female';

  // CBC (Complete Blood Count) markers
  whiteBloodCellCount: number;      // 1000 cells/µL (US) or 10^9/L (SI)
  lymphocytePercent: number;        // %
  meanCellVolume: number;           // fL (same in both systems)
  redCellDistributionWidth: number; // %

  // Comprehensive Metabolic Panel markers
  albumin: number;                  // g/dL (US) or g/L (SI)
  creatinine: number;               // mg/dL (US) or µmol/L (SI)
  glucose: number;                  // mg/dL (US) or mmol/L (SI)
  alkalinePhosphatase: number;      // U/L (same in both systems)

  // Additional markers
  cReactiveProtein: number;         // mg/dL (US) or mg/L (SI)

  // Optional markers for extended clocks
  bloodUreaNitrogen?: number;       // mg/dL (US) or mmol/L (SI)
  totalCholesterol?: number;        // mg/dL (US) or mmol/L (SI)
  hba1c?: number;                   // %
  systolicBloodPressure?: number;   // mmHg
  uricAcid?: number;                // mg/dL (US) or µmol/L (SI)
}

// Normalized biomarker values in standard units for calculations
export interface NormalizedBiomarkers {
  chronologicalAge: number;
  sex: 'male' | 'female';

  // All values in US units for calculation
  whiteBloodCellCount: number;      // 1000 cells/µL
  lymphocytePercent: number;        // %
  meanCellVolume: number;           // fL
  redCellDistributionWidth: number; // %
  albumin: number;                  // g/dL
  creatinine: number;               // mg/dL
  glucose: number;                  // mg/dL
  alkalinePhosphatase: number;      // U/L
  cReactiveProtein: number;         // mg/dL (log-transformed in calculations)

  // Optional
  bloodUreaNitrogen?: number;
  totalCholesterol?: number;
  hba1c?: number;
  systolicBloodPressure?: number;
  uricAcid?: number;
}

// Result from a biological age calculation
export interface BiologicalAgeResult {
  clockName: string;
  clockVersion: string;
  biologicalAge: number;
  chronologicalAge: number;
  ageDifference: number;           // Positive = older, negative = younger
  percentile?: number;             // Where user falls in population
  confidenceScore: number;         // 0-100 based on data completeness
  interpretation: AgeInterpretation;
  biomarkerContributions: BiomarkerContribution[];
  recommendations: string[];
}

export type AgeInterpretation = 'younger' | 'ontrack' | 'older';

export interface BiomarkerContribution {
  name: string;
  value: number;
  unit: string;
  contribution: number;            // How much this marker affects the result
  status: 'optimal' | 'suboptimal' | 'concerning';
  referenceRange: {
    min: number;
    max: number;
    optimalMin?: number;
    optimalMax?: number;
  };
}

// Clock metadata
export interface ClockInfo {
  name: string;
  version: string;
  description: string;
  publication: {
    authors: string;
    title: string;
    journal: string;
    year: number;
    doi?: string;
  };
  requiredBiomarkers: string[];
  optionalBiomarkers: string[];
  validationMetrics: {
    correlationWithAge: number;
    mortalityHazardRatio: number;
    mortalityHazardRatioCI: [number, number];
  };
}

// Biomarker reference information
export interface BiomarkerInfo {
  id: string;
  name: string;
  abbreviation: string;
  description: string;
  usUnit: string;
  siUnit: string;
  conversionFactor: number;        // SI = US * factor (or special conversion)
  conversionType: 'multiply' | 'divide' | 'custom';
  referenceRanges: {
    male: { min: number; max: number };
    female: { min: number; max: number };
  };
  source: 'CBC' | 'CMP' | 'Lipid Panel' | 'Other';
}

// History entry for tracking over time
export interface HistoryEntry {
  id: string;
  date: string;
  biomarkers: BiomarkerInput;
  unitSystem: UnitSystem;
  results: BiologicalAgeResult[];
}
