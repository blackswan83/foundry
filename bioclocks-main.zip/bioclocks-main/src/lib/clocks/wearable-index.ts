/**
 * Wearable-Based Biological Age Clocks - Main Export
 *
 * Provides unified access to all wearable-based aging clocks:
 * - HRV Age: Based on heart rate variability
 * - Sleep Age: Based on sleep quality and architecture
 * - Circadian Age: Based on activity rhythm patterns
 */

// Types
export * from './wearable-types';

// Individual clocks
export { calculateHRVAge, HRV_AGE_INFO, getAvailableHRVMetrics, getMissingHRVMetrics } from './hrv-age';
export { calculateSleepAge, SLEEP_AGE_INFO, getMissingSleepMetrics } from './sleep-age';
export { calculateCircadianAge, CIRCADIAN_AGE_INFO, getMissingCircadianMetrics } from './circadian-age';

import { WearableInput, WearableAgeResult, WearableClockInfo } from './wearable-types';
import { calculateHRVAge, HRV_AGE_INFO, getMissingHRVMetrics } from './hrv-age';
import { calculateSleepAge, SLEEP_AGE_INFO, getMissingSleepMetrics } from './sleep-age';
import { calculateCircadianAge, CIRCADIAN_AGE_INFO, getMissingCircadianMetrics } from './circadian-age';

export interface WearableCalculationResult {
  success: boolean;
  results: WearableAgeResult[];
  compositeAge?: number;
  errors: { clock: string; error: string }[];
  warnings: string[];
  availableClocks: string[];
  missingDataFor: { clock: string; missing: string[] }[];
}

/**
 * List of all available wearable clocks
 */
export const WEARABLE_CLOCKS: WearableClockInfo[] = [
  HRV_AGE_INFO,
  SLEEP_AGE_INFO,
  CIRCADIAN_AGE_INFO,
];

/**
 * Calculate all applicable wearable-based biological age clocks
 */
export function calculateAllWearableClocks(input: WearableInput): WearableCalculationResult {
  const result: WearableCalculationResult = {
    success: false,
    results: [],
    errors: [],
    warnings: [],
    availableClocks: [],
    missingDataFor: [],
  };

  // Check data duration
  if (input.daysOfData < 3) {
    result.warnings.push(
      `Only ${input.daysOfData} days of data provided. At least 7 days recommended for accurate results.`
    );
  }

  // Try HRV Age
  const missingHRV = getMissingHRVMetrics(input);
  if (missingHRV.length === 0) {
    try {
      const hrvResult = calculateHRVAge(input);
      result.results.push(hrvResult);
      result.availableClocks.push('HRV Age');
    } catch (error) {
      result.errors.push({
        clock: 'HRV Age',
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  } else {
    result.missingDataFor.push({ clock: 'HRV Age', missing: missingHRV });
  }

  // Try Sleep Age
  const missingSleep = getMissingSleepMetrics(input);
  if (missingSleep.length === 0) {
    try {
      const sleepResult = calculateSleepAge(input);
      result.results.push(sleepResult);
      result.availableClocks.push('Sleep Age');
    } catch (error) {
      result.errors.push({
        clock: 'Sleep Age',
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  } else {
    result.missingDataFor.push({ clock: 'Sleep Age', missing: missingSleep });
  }

  // Try Circadian Age
  const missingCircadian = getMissingCircadianMetrics(input);
  if (missingCircadian.length === 0) {
    try {
      const circadianResult = calculateCircadianAge(input);
      result.results.push(circadianResult);
      result.availableClocks.push('Circadian Age');
    } catch (error) {
      result.errors.push({
        clock: 'Circadian Age',
        error: error instanceof Error ? error.message : 'Unknown error',
      });
    }
  } else {
    result.missingDataFor.push({ clock: 'Circadian Age', missing: missingCircadian });
  }

  // Calculate composite age if multiple clocks succeeded
  if (result.results.length > 0) {
    result.success = true;

    if (result.results.length >= 2) {
      // Weighted average based on confidence scores
      const totalConfidence = result.results.reduce((sum, r) => sum + r.confidenceScore, 0);
      const weightedAge = result.results.reduce(
        (sum, r) => sum + r.biologicalAge * (r.confidenceScore / totalConfidence),
        0
      );
      result.compositeAge = Math.round(weightedAge * 10) / 10;
    } else {
      result.compositeAge = result.results[0].biologicalAge;
    }
  }

  // Add general warnings
  if (result.results.length === 1) {
    result.warnings.push(
      'Only one wearable clock could be calculated. Provide more data types for a more comprehensive assessment.'
    );
  }

  return result;
}

/**
 * Get a summary of what wearable data is needed for each clock
 */
export function getWearableDataRequirements(): {
  clock: string;
  required: string[];
  optional: string[];
  description: string;
}[] {
  return WEARABLE_CLOCKS.map(clock => ({
    clock: clock.name,
    required: clock.requiredMetrics,
    optional: clock.optionalMetrics,
    description: clock.description,
  }));
}

/**
 * Check which clocks can be calculated with the given input
 */
export function checkWearableDataCompleteness(input: WearableInput): {
  clock: string;
  canCalculate: boolean;
  missingRequired: string[];
  availableOptional: string[];
}[] {
  return [
    {
      clock: 'HRV Age',
      canCalculate: getMissingHRVMetrics(input).length === 0,
      missingRequired: getMissingHRVMetrics(input),
      availableOptional: getAvailableOptionalHRV(input),
    },
    {
      clock: 'Sleep Age',
      canCalculate: getMissingSleepMetrics(input).length === 0,
      missingRequired: getMissingSleepMetrics(input),
      availableOptional: getAvailableOptionalSleep(input),
    },
    {
      clock: 'Circadian Age',
      canCalculate: getMissingCircadianMetrics(input).length === 0,
      missingRequired: getMissingCircadianMetrics(input),
      availableOptional: getAvailableOptionalCircadian(input),
    },
  ];
}

// Helper functions for checking optional data

function getAvailableOptionalHRV(input: WearableInput): string[] {
  const available: string[] = [];
  if (input.hrv?.sdnn) available.push('sdnn');
  if (input.hrv?.pnn50) available.push('pnn50');
  if (input.hrv?.lfHfRatio) available.push('lfHfRatio');
  if (input.heartRate?.restingHeartRate) available.push('restingHeartRate');
  return available;
}

function getAvailableOptionalSleep(input: WearableInput): string[] {
  const available: string[] = [];
  if (input.sleep?.deepSleepMinutes) available.push('deepSleepMinutes');
  if (input.sleep?.remSleepMinutes) available.push('remSleepMinutes');
  if (input.sleep?.wakeAfterSleepOnset) available.push('wakeAfterSleepOnset');
  if (input.sleep?.sleepOnsetLatency) available.push('sleepOnsetLatency');
  return available;
}

function getAvailableOptionalCircadian(input: WearableInput): string[] {
  const available: string[] = [];
  if (input.circadian?.interdailyStability) available.push('interdailyStability');
  if (input.circadian?.intradailyVariability) available.push('intradailyVariability');
  if (input.circadian?.acrophase) available.push('acrophase');
  if (input.circadian?.amplitude) available.push('amplitude');
  return available;
}

/**
 * Convert raw wearable data from common formats to our input format
 */
export function normalizeWearableData(
  rawData: Record<string, unknown>,
  deviceType: WearableInput['deviceType']
): Partial<WearableInput> {
  // This would be extended to handle device-specific data formats
  // For now, return a basic mapping

  const normalized: Partial<WearableInput> = {
    deviceType,
  };

  // HRV data
  if (rawData.rmssd || rawData.hrv_rmssd) {
    normalized.hrv = {
      rmssd: Number(rawData.rmssd || rawData.hrv_rmssd),
      sdnn: rawData.sdnn ? Number(rawData.sdnn) : undefined,
      measurementDuration: 5,
      measurementContext: 'sleep',
    };
  }

  // Sleep data
  if (rawData.total_sleep_time || rawData.sleepDuration) {
    normalized.sleep = {
      totalSleepTime: Number(rawData.total_sleep_time || rawData.sleepDuration),
      sleepEfficiency: Number(rawData.sleep_efficiency || rawData.sleepEfficiency || 85),
      deepSleepMinutes: rawData.deep_sleep ? Number(rawData.deep_sleep) : undefined,
      remSleepMinutes: rawData.rem_sleep ? Number(rawData.rem_sleep) : undefined,
    };
  }

  // Heart rate
  if (rawData.resting_heart_rate || rawData.restingHR) {
    normalized.heartRate = {
      restingHeartRate: Number(rawData.resting_heart_rate || rawData.restingHR),
    };
  }

  // Activity
  if (rawData.steps || rawData.daily_steps) {
    normalized.activity = {
      dailySteps: Number(rawData.steps || rawData.daily_steps),
    };
  }

  return normalized;
}
