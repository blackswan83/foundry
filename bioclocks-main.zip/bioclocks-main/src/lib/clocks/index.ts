/**
 * Biological Age Clocks - Main Export
 *
 * This module provides validated biological age calculation algorithms
 * based on peer-reviewed scientific publications.
 *
 * Includes:
 * - Blood Biomarker Clocks: PhenoAge, KDM
 * - Wearable Clocks: HRV Age, Sleep Age, Circadian Age
 */

// Types
export * from './types';

// Biomarker definitions and info
export * from './biomarkers';

// Unit conversion utilities
export * from './conversion';

// Blood biomarker clock algorithms
export { calculatePhenoAge, PHENOAGE_INFO, getMissingBiomarkers } from './phenoage';
export { calculateKDM, KDM_INFO, getAvailableBiomarkers } from './kdm';
export { calculateLinAge2, LINAGE2_REQUIRED_BIOMARKERS, biomarkerInputToLinAge2 } from './linage2';
export type { LinAge2Input, LinAge2Result } from './linage2';

// Wearable-based clock algorithms
export * from './wearable-index';

// Convenience function to run all available clocks
import { NormalizedBiomarkers, BiologicalAgeResult, UnitSystem, BiomarkerInput } from './types';
import { normalizeBiomarkers } from './conversion';
import { calculatePhenoAge, getMissingBiomarkers } from './phenoage';
import { calculateKDM } from './kdm';
import { BIOMARKER_INFO } from './biomarkers';

export interface CalculationResult {
  success: boolean;
  results: BiologicalAgeResult[];
  errors: { clock: string; error: string }[];
  warnings: string[];
}

/**
 * Calculate all applicable biological age clocks for given biomarkers
 */
export function calculateAllClocks(
  input: BiomarkerInput,
  unitSystem: UnitSystem
): CalculationResult {
  const result: CalculationResult = {
    success: false,
    results: [],
    errors: [],
    warnings: [],
  };

  // Normalize biomarkers to US units
  const normalized = normalizeBiomarkers(input, unitSystem);

  // Try PhenoAge
  try {
    const missingForPheno = getMissingBiomarkers(normalized);
    if (missingForPheno.length === 0) {
      const phenoResult = calculatePhenoAge(normalized);
      result.results.push(phenoResult);
    } else {
      result.errors.push({
        clock: 'PhenoAge',
        error: `Missing biomarkers: ${missingForPheno.join(', ')}`,
      });
    }
  } catch (error) {
    result.errors.push({
      clock: 'PhenoAge',
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }

  // Try KDM
  try {
    const kdmResult = calculateKDM(normalized);
    result.results.push(kdmResult);
  } catch (error) {
    result.errors.push({
      clock: 'KDM',
      error: error instanceof Error ? error.message : 'Unknown error',
    });
  }

  // Add warnings for suboptimal conditions
  if (normalized.cReactiveProtein > 1) {
    result.warnings.push(
      'High CRP detected. Biological age estimates may be affected by acute inflammation. ' +
      'Consider retesting when not ill.'
    );
  }

  result.success = result.results.length > 0;

  return result;
}

/**
 * Get a summary of what each biomarker means
 */
export function getBiomarkerSummary(): {
  id: string;
  name: string;
  source: string;
  description: string;
}[] {
  return Object.values(BIOMARKER_INFO).map((info) => ({
    id: info.id,
    name: info.name,
    source: info.source,
    description: info.description,
  }));
}
