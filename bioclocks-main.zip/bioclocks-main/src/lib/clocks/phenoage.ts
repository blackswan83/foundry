/**
 * PhenoAge Biological Age Calculator
 *
 * Based on: Levine ME, et al. "An epigenetic biomarker of aging for lifespan
 * and healthspan." Aging (Albany NY). 2018;10(4):573-591.
 * DOI: 10.18632/aging.101414
 *
 * Algorithm coefficients from the BioAge R package (dayoonkwon/BioAge)
 * and the original publication.
 */

import {
  NormalizedBiomarkers,
  BiologicalAgeResult,
  ClockInfo,
  BiomarkerContribution,
  AgeInterpretation,
} from './types';
import { BIOMARKER_INFO, PHENOAGE_REQUIRED_BIOMARKERS } from './biomarkers';

// PhenoAge linear model coefficients (from Levine 2018 / BioAge R package)
// These predict the "phenotypic age" mortality score
const PHENOAGE_COEFFICIENTS = {
  intercept: -19.9067,
  albumin: -0.0336,           // g/dL - protective (negative coefficient)
  creatinine: 0.0095,         // mg/dL
  glucose: 0.1953,            // log(mg/dL)
  cReactiveProtein: 0.0954,   // log(mg/dL) - note: needs log transform
  lymphocytePercent: -0.0120, // % - protective
  meanCellVolume: 0.0268,     // fL
  redCellDistributionWidth: 0.3306, // % - strong aging marker
  alkalinePhosphatase: 0.0019, // U/L
  whiteBloodCellCount: 0.0554, // 1000 cells/µL
  chronologicalAge: 0.0804,
};

// Parameters for converting mortality score to phenotypic age
// These come from the Gompertz mortality model fitting
const GOMPERTZ_PARAMS = {
  gamma: 0.0076927,  // Aging rate parameter
  lambda: 0.0022802, // Baseline mortality parameter
};

export const PHENOAGE_INFO: ClockInfo = {
  name: 'PhenoAge',
  version: '1.0',
  description:
    'Second-generation aging clock trained on mortality data. Uses 9 blood biomarkers ' +
    'available from standard CBC and metabolic panels plus high-sensitivity CRP.',
  publication: {
    authors: 'Levine ME, Lu AT, Quach A, et al.',
    title: 'An epigenetic biomarker of aging for lifespan and healthspan',
    journal: 'Aging (Albany NY)',
    year: 2018,
    doi: '10.18632/aging.101414',
  },
  requiredBiomarkers: PHENOAGE_REQUIRED_BIOMARKERS,
  optionalBiomarkers: [],
  validationMetrics: {
    correlationWithAge: 0.94,
    mortalityHazardRatio: 1.43,
    mortalityHazardRatioCI: [1.37, 1.49],
  },
};

/**
 * Calculate PhenoAge biological age
 */
export function calculatePhenoAge(biomarkers: NormalizedBiomarkers): BiologicalAgeResult {
  // Validate required biomarkers are present
  const missingBiomarkers = getMissingBiomarkers(biomarkers);
  if (missingBiomarkers.length > 0) {
    throw new Error(`Missing required biomarkers: ${missingBiomarkers.join(', ')}`);
  }

  // Step 1: Calculate the linear predictor (xb)
  // This is the "mortality score" from the biomarkers
  const xb = calculateLinearPredictor(biomarkers);

  // Step 2: Convert mortality score to 10-year mortality probability
  const mortalityProb10yr = 1 - Math.exp(-Math.exp(xb) * (Math.exp(120 * GOMPERTZ_PARAMS.gamma) - 1) / GOMPERTZ_PARAMS.gamma);

  // Step 3: Convert mortality probability to phenotypic age
  // Inverse of the Gompertz mortality function
  const phenoAge = calculatePhenoAgeFromMortality(mortalityProb10yr, biomarkers.chronologicalAge);

  // Calculate age difference
  const ageDifference = phenoAge - biomarkers.chronologicalAge;

  // Determine interpretation
  const interpretation = getInterpretation(ageDifference);

  // Calculate biomarker contributions
  const contributions = calculateBiomarkerContributions(biomarkers);

  // Generate recommendations based on results
  const recommendations = generateRecommendations(biomarkers, contributions);

  // Calculate confidence score (100% if all biomarkers present)
  const confidenceScore = 100;

  return {
    clockName: PHENOAGE_INFO.name,
    clockVersion: PHENOAGE_INFO.version,
    biologicalAge: Math.round(phenoAge * 10) / 10,
    chronologicalAge: biomarkers.chronologicalAge,
    ageDifference: Math.round(ageDifference * 10) / 10,
    confidenceScore,
    interpretation,
    biomarkerContributions: contributions,
    recommendations,
  };
}

/**
 * Calculate the linear predictor (mortality score) from biomarkers
 */
function calculateLinearPredictor(biomarkers: NormalizedBiomarkers): number {
  // Log-transform glucose and CRP as per the original algorithm
  const logGlucose = Math.log(biomarkers.glucose);
  // CRP needs special handling - add small value to avoid log(0)
  const logCRP = Math.log(Math.max(biomarkers.cReactiveProtein, 0.001));

  const xb =
    PHENOAGE_COEFFICIENTS.intercept +
    PHENOAGE_COEFFICIENTS.albumin * biomarkers.albumin +
    PHENOAGE_COEFFICIENTS.creatinine * biomarkers.creatinine +
    PHENOAGE_COEFFICIENTS.glucose * logGlucose +
    PHENOAGE_COEFFICIENTS.cReactiveProtein * logCRP +
    PHENOAGE_COEFFICIENTS.lymphocytePercent * biomarkers.lymphocytePercent +
    PHENOAGE_COEFFICIENTS.meanCellVolume * biomarkers.meanCellVolume +
    PHENOAGE_COEFFICIENTS.redCellDistributionWidth * biomarkers.redCellDistributionWidth +
    PHENOAGE_COEFFICIENTS.alkalinePhosphatase * biomarkers.alkalinePhosphatase +
    PHENOAGE_COEFFICIENTS.whiteBloodCellCount * biomarkers.whiteBloodCellCount +
    PHENOAGE_COEFFICIENTS.chronologicalAge * biomarkers.chronologicalAge;

  return xb;
}

/**
 * Convert 10-year mortality probability to phenotypic age
 * Uses the inverse Gompertz function
 */
function calculatePhenoAgeFromMortality(mortalityProb: number, chronoAge: number): number {
  // Clamp mortality probability to valid range
  const clampedProb = Math.max(0.0001, Math.min(0.9999, mortalityProb));

  // Inverse Gompertz calculation
  // PhenoAge = (1/gamma) * ln(-gamma * ln(1-M) / lambda + 1)
  // where M is 10-year mortality probability
  const gamma = GOMPERTZ_PARAMS.gamma;
  const lambda = GOMPERTZ_PARAMS.lambda;

  const innerTerm = (-gamma * Math.log(1 - clampedProb)) / lambda + 1;

  if (innerTerm <= 0) {
    // Fallback for extreme values
    return chronoAge;
  }

  const phenoAge = (1 / gamma) * Math.log(innerTerm);

  // Sanity check - phenotypic age should be within reasonable bounds
  const minAge = Math.max(0, chronoAge - 30);
  const maxAge = chronoAge + 30;

  return Math.max(minAge, Math.min(maxAge, phenoAge));
}

/**
 * Get interpretation category based on age difference
 */
function getInterpretation(ageDifference: number): AgeInterpretation {
  // Within 2 years is considered "on track"
  if (ageDifference <= -2) {
    return 'younger';
  } else if (ageDifference >= 2) {
    return 'older';
  }
  return 'ontrack';
}

/**
 * Calculate how each biomarker contributes to the result
 */
function calculateBiomarkerContributions(
  biomarkers: NormalizedBiomarkers
): BiomarkerContribution[] {
  const contributions: BiomarkerContribution[] = [];

  // Albumin - higher is better (protective)
  contributions.push(createContribution(
    'albumin',
    biomarkers.albumin,
    'g/dL',
    PHENOAGE_COEFFICIENTS.albumin * biomarkers.albumin,
    biomarkers.sex,
    true // inverse - higher is better
  ));

  // Creatinine
  contributions.push(createContribution(
    'creatinine',
    biomarkers.creatinine,
    'mg/dL',
    PHENOAGE_COEFFICIENTS.creatinine * biomarkers.creatinine,
    biomarkers.sex
  ));

  // Glucose (log-transformed in calculation)
  contributions.push(createContribution(
    'glucose',
    biomarkers.glucose,
    'mg/dL',
    PHENOAGE_COEFFICIENTS.glucose * Math.log(biomarkers.glucose),
    biomarkers.sex
  ));

  // CRP (log-transformed)
  contributions.push(createContribution(
    'cReactiveProtein',
    biomarkers.cReactiveProtein,
    'mg/dL',
    PHENOAGE_COEFFICIENTS.cReactiveProtein * Math.log(Math.max(biomarkers.cReactiveProtein, 0.001)),
    biomarkers.sex
  ));

  // Lymphocyte % - higher is better (protective)
  contributions.push(createContribution(
    'lymphocytePercent',
    biomarkers.lymphocytePercent,
    '%',
    PHENOAGE_COEFFICIENTS.lymphocytePercent * biomarkers.lymphocytePercent,
    biomarkers.sex,
    true
  ));

  // MCV
  contributions.push(createContribution(
    'meanCellVolume',
    biomarkers.meanCellVolume,
    'fL',
    PHENOAGE_COEFFICIENTS.meanCellVolume * biomarkers.meanCellVolume,
    biomarkers.sex
  ));

  // RDW - important aging marker
  contributions.push(createContribution(
    'redCellDistributionWidth',
    biomarkers.redCellDistributionWidth,
    '%',
    PHENOAGE_COEFFICIENTS.redCellDistributionWidth * biomarkers.redCellDistributionWidth,
    biomarkers.sex
  ));

  // Alkaline Phosphatase
  contributions.push(createContribution(
    'alkalinePhosphatase',
    biomarkers.alkalinePhosphatase,
    'U/L',
    PHENOAGE_COEFFICIENTS.alkalinePhosphatase * biomarkers.alkalinePhosphatase,
    biomarkers.sex
  ));

  // WBC
  contributions.push(createContribution(
    'whiteBloodCellCount',
    biomarkers.whiteBloodCellCount,
    '1000/µL',
    PHENOAGE_COEFFICIENTS.whiteBloodCellCount * biomarkers.whiteBloodCellCount,
    biomarkers.sex
  ));

  // Sort by absolute contribution (most impactful first)
  return contributions.sort((a, b) => Math.abs(b.contribution) - Math.abs(a.contribution));
}

/**
 * Create a biomarker contribution object
 */
function createContribution(
  biomarkerId: string,
  value: number,
  unit: string,
  contribution: number,
  sex: 'male' | 'female',
  isInverse = false
): BiomarkerContribution {
  const info = BIOMARKER_INFO[biomarkerId];
  const range = info.referenceRanges[sex];

  // Determine status based on reference range
  let status: 'optimal' | 'suboptimal' | 'concerning';

  if (value >= range.min && value <= range.max) {
    status = 'optimal';
  } else if (
    value >= range.min * 0.8 && value <= range.max * 1.2
  ) {
    status = 'suboptimal';
  } else {
    status = 'concerning';
  }

  return {
    name: info.name,
    value,
    unit,
    contribution,
    status,
    referenceRange: {
      min: range.min,
      max: range.max,
    },
  };
}

/**
 * Generate personalized recommendations based on biomarker values
 */
function generateRecommendations(
  biomarkers: NormalizedBiomarkers,
  contributions: BiomarkerContribution[]
): string[] {
  const recommendations: string[] = [];

  // Find concerning biomarkers and provide targeted advice
  const concerningBiomarkers = contributions.filter(c => c.status === 'concerning');
  const suboptimalBiomarkers = contributions.filter(c => c.status === 'suboptimal');

  // CRP - inflammation
  const crpContrib = contributions.find(c => c.name === 'C-Reactive Protein');
  if (crpContrib && biomarkers.cReactiveProtein > 0.3) {
    recommendations.push(
      'Consider anti-inflammatory lifestyle changes: regular exercise, omega-3 fatty acids, ' +
      'and a Mediterranean-style diet can help reduce inflammation markers.'
    );
  }

  // Glucose
  const glucoseContrib = contributions.find(c => c.name === 'Fasting Glucose');
  if (glucoseContrib && biomarkers.glucose > 100) {
    recommendations.push(
      'Blood glucose is elevated. Focus on reducing refined carbohydrates, ' +
      'increasing fiber intake, and regular physical activity to improve metabolic health.'
    );
  }

  // RDW - often elevated with nutritional deficiencies
  const rdwContrib = contributions.find(c => c.name === 'Red Cell Distribution Width');
  if (rdwContrib && biomarkers.redCellDistributionWidth > 14.5) {
    recommendations.push(
      'Elevated RDW may indicate nutritional deficiencies (iron, B12, folate) or chronic inflammation. ' +
      'Consider comprehensive nutritional assessment.'
    );
  }

  // Albumin - low albumin
  const albContrib = contributions.find(c => c.name === 'Albumin');
  if (albContrib && biomarkers.albumin < 3.8) {
    recommendations.push(
      'Albumin levels may benefit from adequate protein intake (0.8-1g per kg body weight) ' +
      'and liver-supportive nutrition.'
    );
  }

  // General recommendations if everything is suboptimal but not concerning
  if (concerningBiomarkers.length === 0 && suboptimalBiomarkers.length > 2) {
    recommendations.push(
      'Multiple biomarkers show room for improvement. A comprehensive lifestyle approach including ' +
      'regular exercise, quality sleep, stress management, and balanced nutrition may help optimize your biological age.'
    );
  }

  // Positive reinforcement if doing well
  if (concerningBiomarkers.length === 0 && suboptimalBiomarkers.length <= 1) {
    recommendations.push(
      'Your biomarker profile looks healthy. Continue maintaining your current lifestyle habits.'
    );
  }

  return recommendations;
}

/**
 * Check which required biomarkers are missing
 */
function getMissingBiomarkers(biomarkers: NormalizedBiomarkers): string[] {
  const missing: string[] = [];

  if (!biomarkers.whiteBloodCellCount) missing.push('White Blood Cell Count');
  if (!biomarkers.lymphocytePercent) missing.push('Lymphocyte %');
  if (!biomarkers.meanCellVolume) missing.push('Mean Cell Volume');
  if (!biomarkers.redCellDistributionWidth) missing.push('Red Cell Distribution Width');
  if (!biomarkers.albumin) missing.push('Albumin');
  if (!biomarkers.creatinine) missing.push('Creatinine');
  if (!biomarkers.glucose) missing.push('Glucose');
  if (!biomarkers.alkalinePhosphatase) missing.push('Alkaline Phosphatase');
  if (biomarkers.cReactiveProtein === undefined) missing.push('C-Reactive Protein');

  return missing;
}

export { getMissingBiomarkers };
