/**
 * HRV-Based Biological Age Estimation
 *
 * Based on research showing HRV metrics decline predictably with age.
 * Uses RMSSD and SDNN as primary markers of autonomic aging.
 *
 * References:
 * - Umetani et al. (1998) "Twenty-four hour time domain HRV and heart rate"
 * - Voss et al. (2015) "Short-term HRV - age dependence in healthy subjects"
 * - Zhang et al. (2024) "HRV as a biomarker of aging"
 */

import {
  WearableInput,
  WearableAgeResult,
  WearableContribution,
  WearableClockInfo,
  HRVMetrics,
} from './wearable-types';

export const HRV_AGE_INFO: WearableClockInfo = {
  name: 'HRV Age',
  version: '1.0.0',
  description:
    'Estimates biological age based on heart rate variability metrics, ' +
    'reflecting autonomic nervous system health and cardiac resilience.',
  requiredMetrics: ['rmssd', 'chronologicalAge', 'sex'],
  optionalMetrics: ['sdnn', 'restingHeartRate', 'pnn50', 'lfHfRatio'],
  minimumDaysRequired: 7,
  supportedDevices: ['apple_watch', 'fitbit', 'oura', 'whoop', 'garmin', 'samsung', 'other'],
  publication: {
    authors: 'Voss A, et al.',
    title: 'Short-term heart rate variability - influence of gender and age in healthy subjects',
    journal: 'PLOS ONE',
    year: 2015,
    doi: '10.1371/journal.pone.0118308',
  },
};

/**
 * Reference RMSSD values by age (based on population studies)
 * Values in milliseconds, representing 50th percentile
 */
const RMSSD_REFERENCE: { [age: number]: { male: number; female: number } } = {
  20: { male: 42, female: 45 },
  25: { male: 40, female: 43 },
  30: { male: 37, female: 40 },
  35: { male: 34, female: 37 },
  40: { male: 31, female: 34 },
  45: { male: 28, female: 31 },
  50: { male: 25, female: 28 },
  55: { male: 23, female: 26 },
  60: { male: 21, female: 24 },
  65: { male: 19, female: 22 },
  70: { male: 17, female: 20 },
  75: { male: 16, female: 19 },
  80: { male: 15, female: 18 },
};

/**
 * Reference SDNN values by age (24-hour recordings)
 */
const SDNN_REFERENCE: { [age: number]: { male: number; female: number } } = {
  20: { male: 155, female: 145 },
  25: { male: 150, female: 140 },
  30: { male: 142, female: 132 },
  35: { male: 133, female: 123 },
  40: { male: 123, female: 114 },
  45: { male: 114, female: 106 },
  50: { male: 105, female: 98 },
  55: { male: 97, female: 91 },
  60: { male: 90, female: 85 },
  65: { male: 84, female: 80 },
  70: { male: 79, female: 75 },
  75: { male: 74, female: 71 },
  80: { male: 70, female: 68 },
};

/**
 * Reference resting heart rate by age
 */
const RHR_REFERENCE: { [age: number]: { male: number; female: number } } = {
  20: { male: 62, female: 65 },
  30: { male: 64, female: 67 },
  40: { male: 66, female: 69 },
  50: { male: 68, female: 71 },
  60: { male: 70, female: 73 },
  70: { male: 72, female: 75 },
  80: { male: 74, female: 77 },
};

/**
 * Interpolate reference value for exact age
 */
function interpolateReference(
  age: number,
  sex: 'male' | 'female',
  reference: { [age: number]: { male: number; female: number } }
): number {
  const ages = Object.keys(reference).map(Number).sort((a, b) => a - b);

  if (age <= ages[0]) return reference[ages[0]][sex];
  if (age >= ages[ages.length - 1]) return reference[ages[ages.length - 1]][sex];

  // Find surrounding ages
  let lowerAge = ages[0];
  let upperAge = ages[ages.length - 1];

  for (let i = 0; i < ages.length - 1; i++) {
    if (ages[i] <= age && ages[i + 1] > age) {
      lowerAge = ages[i];
      upperAge = ages[i + 1];
      break;
    }
  }

  // Linear interpolation
  const ratio = (age - lowerAge) / (upperAge - lowerAge);
  const lowerValue = reference[lowerAge][sex];
  const upperValue = reference[upperAge][sex];

  return lowerValue + ratio * (upperValue - lowerValue);
}

/**
 * Estimate biological age from HRV metrics
 *
 * The algorithm:
 * 1. Compare measured RMSSD to age-expected RMSSD
 * 2. Find the age that matches the measured RMSSD
 * 3. Adjust with SDNN and RHR if available
 * 4. Weight and combine estimates
 */
export function calculateHRVAge(input: WearableInput): WearableAgeResult {
  const { chronologicalAge, sex, hrv, heartRate } = input;

  if (!hrv?.rmssd) {
    throw new Error('RMSSD is required for HRV Age calculation');
  }

  const contributions: WearableContribution[] = [];
  const ages: { metric: string; age: number; weight: number }[] = [];

  // 1. RMSSD-based age estimation
  const rmssdAge = estimateAgeFromMetric(
    hrv.rmssd,
    sex,
    RMSSD_REFERENCE,
    'decreasing'
  );
  ages.push({ metric: 'rmssd', age: rmssdAge, weight: 0.5 });

  contributions.push({
    metric: 'RMSSD',
    category: 'hrv',
    value: hrv.rmssd,
    unit: 'ms',
    percentile: calculatePercentile(hrv.rmssd, chronologicalAge, sex, RMSSD_REFERENCE, 'decreasing'),
    status: getMetricStatus(hrv.rmssd, chronologicalAge, sex, RMSSD_REFERENCE, 'decreasing'),
    ageImpact: rmssdAge - chronologicalAge,
  });

  // 2. SDNN-based age (if available)
  if (hrv.sdnn) {
    const sdnnAge = estimateAgeFromMetric(
      hrv.sdnn,
      sex,
      SDNN_REFERENCE,
      'decreasing'
    );
    ages.push({ metric: 'sdnn', age: sdnnAge, weight: 0.25 });

    contributions.push({
      metric: 'SDNN',
      category: 'hrv',
      value: hrv.sdnn,
      unit: 'ms',
      percentile: calculatePercentile(hrv.sdnn, chronologicalAge, sex, SDNN_REFERENCE, 'decreasing'),
      status: getMetricStatus(hrv.sdnn, chronologicalAge, sex, SDNN_REFERENCE, 'decreasing'),
      ageImpact: sdnnAge - chronologicalAge,
    });
  }

  // 3. Resting heart rate (if available)
  if (heartRate?.restingHeartRate) {
    const rhrAge = estimateAgeFromMetric(
      heartRate.restingHeartRate,
      sex,
      RHR_REFERENCE,
      'increasing'
    );
    ages.push({ metric: 'rhr', age: rhrAge, weight: 0.25 });

    contributions.push({
      metric: 'Resting Heart Rate',
      category: 'heart_rate',
      value: heartRate.restingHeartRate,
      unit: 'bpm',
      percentile: calculatePercentile(heartRate.restingHeartRate, chronologicalAge, sex, RHR_REFERENCE, 'increasing'),
      status: getMetricStatus(heartRate.restingHeartRate, chronologicalAge, sex, RHR_REFERENCE, 'increasing'),
      ageImpact: rhrAge - chronologicalAge,
    });
  }

  // Normalize weights
  const totalWeight = ages.reduce((sum, a) => sum + a.weight, 0);
  const weightedAge = ages.reduce((sum, a) => sum + (a.age * a.weight), 0) / totalWeight;

  // Round to one decimal
  const biologicalAge = Math.round(weightedAge * 10) / 10;
  const ageDifference = Math.round((biologicalAge - chronologicalAge) * 10) / 10;

  // Determine interpretation
  let interpretation: 'younger' | 'ontrack' | 'older';
  if (ageDifference <= -2) {
    interpretation = 'younger';
  } else if (ageDifference >= 2) {
    interpretation = 'older';
  } else {
    interpretation = 'ontrack';
  }

  // Generate recommendations
  const recommendations = generateHRVRecommendations(contributions, interpretation);

  // Calculate confidence score based on data completeness
  let confidenceScore = 60; // Base score with just RMSSD
  if (hrv.sdnn) confidenceScore += 15;
  if (heartRate?.restingHeartRate) confidenceScore += 15;
  if (input.daysOfData >= 14) confidenceScore += 10;
  else if (input.daysOfData >= 7) confidenceScore += 5;

  return {
    clockName: HRV_AGE_INFO.name,
    clockVersion: HRV_AGE_INFO.version,
    biologicalAge,
    chronologicalAge,
    ageDifference,
    confidenceScore: Math.min(confidenceScore, 100),
    interpretation,
    componentAges: {
      hrvAge: biologicalAge,
    },
    contributions,
    recommendations,
  };
}

/**
 * Estimate age from a single metric using reference values
 */
function estimateAgeFromMetric(
  value: number,
  sex: 'male' | 'female',
  reference: { [age: number]: { male: number; female: number } },
  direction: 'increasing' | 'decreasing'
): number {
  const ages = Object.keys(reference).map(Number).sort((a, b) => a - b);

  // Find the age that best matches this value
  for (let age = ages[0]; age <= ages[ages.length - 1]; age++) {
    const expectedValue = interpolateReference(age, sex, reference);

    if (direction === 'decreasing') {
      // Value decreases with age (like RMSSD, SDNN)
      if (value >= expectedValue) {
        // Find more precise age by continuing
        if (age === ages[0]) return ages[0];
      }
      if (value >= interpolateReference(age, sex, reference) &&
        value < interpolateReference(age - 1, sex, reference)) {
        return age;
      }
    } else {
      // Value increases with age (like RHR)
      if (value <= expectedValue) {
        return age;
      }
    }
  }

  // Binary search for better precision
  let low = ages[0];
  let high = ages[ages.length - 1];

  while (high - low > 0.5) {
    const mid = (low + high) / 2;
    const midValue = interpolateReference(mid, sex, reference);

    if (direction === 'decreasing') {
      if (value < midValue) {
        low = mid;
      } else {
        high = mid;
      }
    } else {
      if (value > midValue) {
        low = mid;
      } else {
        high = mid;
      }
    }
  }

  return Math.round((low + high) / 2);
}

/**
 * Calculate percentile for a metric given age
 */
function calculatePercentile(
  value: number,
  age: number,
  sex: 'male' | 'female',
  reference: { [age: number]: { male: number; female: number } },
  direction: 'increasing' | 'decreasing'
): number {
  const expected = interpolateReference(age, sex, reference);
  // Assume ~15% standard deviation for most HRV metrics
  const stdDev = expected * 0.35;
  const zScore = (value - expected) / stdDev;

  // Convert z-score to percentile (simplified)
  // For decreasing metrics, higher value = better = higher percentile
  const adjustedZ = direction === 'decreasing' ? zScore : -zScore;

  // Approximate normal CDF
  const percentile = 50 + 50 * Math.tanh(adjustedZ * 0.6);
  return Math.round(Math.max(1, Math.min(99, percentile)));
}

/**
 * Determine status of a metric
 */
function getMetricStatus(
  value: number,
  age: number,
  sex: 'male' | 'female',
  reference: { [age: number]: { male: number; female: number } },
  direction: 'increasing' | 'decreasing'
): 'optimal' | 'suboptimal' | 'concerning' {
  const percentile = calculatePercentile(value, age, sex, reference, direction);

  if (percentile >= 40 && percentile <= 90) return 'optimal';
  if (percentile >= 20 || percentile <= 95) return 'suboptimal';
  return 'concerning';
}

/**
 * Generate personalized recommendations based on HRV analysis
 */
function generateHRVRecommendations(
  contributions: WearableContribution[],
  interpretation: 'younger' | 'ontrack' | 'older'
): string[] {
  const recommendations: string[] = [];

  const rmssdContrib = contributions.find(c => c.metric === 'RMSSD');
  const rhrContrib = contributions.find(c => c.metric === 'Resting Heart Rate');

  if (interpretation === 'older') {
    recommendations.push(
      'Consider incorporating regular aerobic exercise to improve heart rate variability'
    );
  }

  if (rmssdContrib?.status === 'concerning') {
    recommendations.push(
      'Low RMSSD indicates reduced parasympathetic activity. Focus on stress management and quality sleep.'
    );
    recommendations.push(
      'Breathing exercises (4-7-8 technique, box breathing) can improve vagal tone.'
    );
  }

  if (rhrContrib?.status === 'concerning') {
    recommendations.push(
      'Elevated resting heart rate may indicate stress or deconditioning. Regular cardio exercise can help.'
    );
  }

  if (interpretation === 'younger') {
    recommendations.push(
      'Your HRV metrics indicate excellent autonomic health. Maintain your current lifestyle habits.'
    );
  }

  if (recommendations.length === 0) {
    recommendations.push(
      'Continue regular exercise, prioritize sleep, and manage stress to maintain healthy HRV.'
    );
  }

  return recommendations;
}

/**
 * Check which HRV metrics are available
 */
export function getAvailableHRVMetrics(input: WearableInput): string[] {
  const available: string[] = [];

  if (input.hrv?.rmssd) available.push('rmssd');
  if (input.hrv?.sdnn) available.push('sdnn');
  if (input.hrv?.pnn50) available.push('pnn50');
  if (input.hrv?.lfHfRatio) available.push('lfHfRatio');
  if (input.heartRate?.restingHeartRate) available.push('restingHeartRate');

  return available;
}

/**
 * Get missing required metrics
 */
export function getMissingHRVMetrics(input: WearableInput): string[] {
  const missing: string[] = [];

  if (!input.hrv?.rmssd) missing.push('rmssd');

  return missing;
}
