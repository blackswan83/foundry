/**
 * Types for Wearable-Based Biological Age Clocks
 *
 * Supports data from smartwatches, fitness trackers, and other wearables
 */

// Heart Rate Variability metrics
export interface HRVMetrics {
  // Time-domain metrics
  sdnn?: number;           // Standard deviation of NN intervals (ms)
  rmssd?: number;          // Root mean square of successive differences (ms)
  pnn50?: number;          // Percentage of successive intervals differing by >50ms

  // Frequency-domain metrics
  lfPower?: number;        // Low frequency power (0.04-0.15 Hz)
  hfPower?: number;        // High frequency power (0.15-0.4 Hz)
  lfHfRatio?: number;      // LF/HF ratio

  // Contextual
  measurementDuration: number;  // Duration in minutes
  measurementContext: 'sleep' | 'rest' | 'active' | 'unknown';
}

// Sleep metrics from wearables
export interface SleepMetrics {
  totalSleepTime: number;       // TST - Total sleep time in minutes
  sleepEfficiency: number;      // Percentage (0-100)
  sleepOnsetLatency?: number;   // SOL - Time to fall asleep in minutes
  wakeAfterSleepOnset?: number; // WASO - Wake time after sleep onset in minutes
  numberOfAwakenings?: number;  // NWB - Number of wake bouts

  // Sleep stages (if available)
  deepSleepMinutes?: number;
  lightSleepMinutes?: number;
  remSleepMinutes?: number;
  awakeMinutes?: number;

  // Sleep timing
  bedtime?: string;             // ISO time string
  wakeTime?: string;            // ISO time string
}

// Circadian rhythm metrics
export interface CircadianMetrics {
  // Cosinor analysis parameters
  acrophase?: number;           // Peak activity time (hours from midnight)
  amplitude?: number;           // Strength of circadian rhythm
  mesor?: number;               // Rhythm-adjusted mean activity level

  // Non-parametric circadian indices
  interdailyStability?: number; // IS - Consistency of rhythm across days (0-1)
  intradailyVariability?: number; // IV - Fragmentation of rhythm (0-2)
  relativeAmplitude?: number;   // RA - Ratio of most to least active periods

  // Activity timing
  l5?: number;                  // Least active 5-hour period (start hour)
  l5Value?: number;             // Average activity during L5
  m10?: number;                 // Most active 10-hour period (start hour)
  m10Value?: number;            // Average activity during M10
}

// Physical activity metrics
export interface ActivityMetrics {
  dailySteps: number;
  activeMinutes?: number;
  sedentaryMinutes?: number;
  caloriesBurned?: number;

  // Activity intensity distribution
  lightActivityMinutes?: number;
  moderateActivityMinutes?: number;
  vigorousActivityMinutes?: number;

  // ENMO - Euclidean Norm Minus One (for accelerometry)
  avgEnmo?: number;             // Average ENMO in mg
}

// Resting heart rate
export interface HeartRateMetrics {
  restingHeartRate: number;     // BPM
  maxHeartRate?: number;
  avgHeartRate?: number;
  heartRateRecovery?: number;   // BPM drop after exercise
}

// Combined wearable input
export interface WearableInput {
  // Demographics
  chronologicalAge: number;
  sex: 'male' | 'female';

  // Data collection period
  dataStartDate: string;        // ISO date
  dataEndDate: string;          // ISO date
  daysOfData: number;

  // Core metrics
  hrv?: HRVMetrics;
  sleep?: SleepMetrics;
  circadian?: CircadianMetrics;
  activity?: ActivityMetrics;
  heartRate?: HeartRateMetrics;

  // Device info
  deviceType?: 'apple_watch' | 'fitbit' | 'oura' | 'whoop' | 'garmin' | 'samsung' | 'other';
  deviceModel?: string;
}

// Result from wearable-based age calculation
export interface WearableAgeResult {
  clockName: string;
  clockVersion: string;
  biologicalAge: number;
  chronologicalAge: number;
  ageDifference: number;
  confidenceScore: number;
  interpretation: 'younger' | 'ontrack' | 'older';

  // Component ages (if available)
  componentAges?: {
    circadianAge?: number;
    sleepAge?: number;
    hrvAge?: number;
    activityAge?: number;
  };

  // Contributing factors
  contributions: WearableContribution[];
  recommendations: string[];
}

export interface WearableContribution {
  metric: string;
  category: 'hrv' | 'sleep' | 'circadian' | 'activity' | 'heart_rate';
  value: number;
  unit: string;
  percentile?: number;
  status: 'optimal' | 'suboptimal' | 'concerning';
  ageImpact: number;  // Years added/subtracted
}

// Clock metadata for wearable clocks
export interface WearableClockInfo {
  name: string;
  version: string;
  description: string;
  requiredMetrics: string[];
  optionalMetrics: string[];
  minimumDaysRequired: number;
  supportedDevices: string[];
  publication?: {
    authors: string;
    title: string;
    journal: string;
    year: number;
    doi?: string;
  };
}

// Reference ranges for wearable metrics by age and sex
export interface WearableReferenceRanges {
  hrv: {
    rmssd: { [ageGroup: string]: { male: [number, number]; female: [number, number] } };
    sdnn: { [ageGroup: string]: { male: [number, number]; female: [number, number] } };
  };
  sleep: {
    efficiency: { optimal: [number, number]; acceptable: [number, number] };
    duration: { [ageGroup: string]: [number, number] };
  };
  restingHeartRate: {
    [ageGroup: string]: { male: [number, number]; female: [number, number] };
  };
}
