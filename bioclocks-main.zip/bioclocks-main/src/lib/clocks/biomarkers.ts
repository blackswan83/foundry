/**
 * Biomarker definitions and reference ranges
 * Based on NHANES reference populations and clinical guidelines
 */

import { BiomarkerInfo } from './types';

export const BIOMARKER_INFO: Record<string, BiomarkerInfo> = {
  whiteBloodCellCount: {
    id: 'whiteBloodCellCount',
    name: 'White Blood Cell Count',
    abbreviation: 'WBC',
    description: 'Total number of white blood cells, key indicator of immune function',
    usUnit: '1000 cells/µL',
    siUnit: '10⁹/L',
    conversionFactor: 1, // Same numeric value, different unit notation
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 4.5, max: 11.0 },
      female: { min: 4.5, max: 11.0 },
    },
    source: 'CBC',
  },

  lymphocytePercent: {
    id: 'lymphocytePercent',
    name: 'Lymphocyte Percentage',
    abbreviation: 'Lymph %',
    description: 'Percentage of lymphocytes in white blood cells, indicates immune status',
    usUnit: '%',
    siUnit: '%',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 20, max: 40 },
      female: { min: 20, max: 40 },
    },
    source: 'CBC',
  },

  meanCellVolume: {
    id: 'meanCellVolume',
    name: 'Mean Cell Volume',
    abbreviation: 'MCV',
    description: 'Average size of red blood cells',
    usUnit: 'fL',
    siUnit: 'fL',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 80, max: 100 },
      female: { min: 80, max: 100 },
    },
    source: 'CBC',
  },

  redCellDistributionWidth: {
    id: 'redCellDistributionWidth',
    name: 'Red Cell Distribution Width',
    abbreviation: 'RDW',
    description: 'Variation in red blood cell size, marker of cellular aging',
    usUnit: '%',
    siUnit: '%',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 11.5, max: 14.5 },
      female: { min: 11.5, max: 14.5 },
    },
    source: 'CBC',
  },

  albumin: {
    id: 'albumin',
    name: 'Albumin',
    abbreviation: 'ALB',
    description: 'Main blood protein, indicates liver function and nutritional status',
    usUnit: 'g/dL',
    siUnit: 'g/L',
    conversionFactor: 10, // g/L = g/dL * 10
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 3.5, max: 5.0 },
      female: { min: 3.5, max: 5.0 },
    },
    source: 'CMP',
  },

  creatinine: {
    id: 'creatinine',
    name: 'Creatinine',
    abbreviation: 'CREAT',
    description: 'Waste product filtered by kidneys, indicates kidney function',
    usUnit: 'mg/dL',
    siUnit: 'µmol/L',
    conversionFactor: 88.4, // µmol/L = mg/dL * 88.4
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 0.7, max: 1.3 },
      female: { min: 0.6, max: 1.1 },
    },
    source: 'CMP',
  },

  glucose: {
    id: 'glucose',
    name: 'Fasting Glucose',
    abbreviation: 'GLU',
    description: 'Blood sugar level, key metabolic health marker',
    usUnit: 'mg/dL',
    siUnit: 'mmol/L',
    conversionFactor: 0.0555, // mmol/L = mg/dL * 0.0555
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 70, max: 100 },
      female: { min: 70, max: 100 },
    },
    source: 'CMP',
  },

  alkalinePhosphatase: {
    id: 'alkalinePhosphatase',
    name: 'Alkaline Phosphatase',
    abbreviation: 'ALP',
    description: 'Enzyme related to liver and bone health',
    usUnit: 'U/L',
    siUnit: 'U/L',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 44, max: 147 },
      female: { min: 44, max: 147 },
    },
    source: 'CMP',
  },

  cReactiveProtein: {
    id: 'cReactiveProtein',
    name: 'C-Reactive Protein',
    abbreviation: 'CRP',
    description: 'Inflammation marker, sensitive indicator of systemic inflammation',
    usUnit: 'mg/dL',
    siUnit: 'mg/L',
    conversionFactor: 10, // mg/L = mg/dL * 10
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 0, max: 0.3 },    // <3 mg/L = <0.3 mg/dL
      female: { min: 0, max: 0.3 },
    },
    source: 'Other',
  },

  bloodUreaNitrogen: {
    id: 'bloodUreaNitrogen',
    name: 'Blood Urea Nitrogen',
    abbreviation: 'BUN',
    description: 'Waste product indicating kidney function',
    usUnit: 'mg/dL',
    siUnit: 'mmol/L',
    conversionFactor: 0.357, // mmol/L = mg/dL * 0.357
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 7, max: 20 },
      female: { min: 7, max: 20 },
    },
    source: 'CMP',
  },

  totalCholesterol: {
    id: 'totalCholesterol',
    name: 'Total Cholesterol',
    abbreviation: 'TC',
    description: 'Total blood cholesterol level',
    usUnit: 'mg/dL',
    siUnit: 'mmol/L',
    conversionFactor: 0.0259, // mmol/L = mg/dL * 0.0259
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 125, max: 200 },
      female: { min: 125, max: 200 },
    },
    source: 'Lipid Panel',
  },

  hba1c: {
    id: 'hba1c',
    name: 'Hemoglobin A1c',
    abbreviation: 'HbA1c',
    description: 'Average blood sugar over 2-3 months',
    usUnit: '%',
    siUnit: '%',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 4.0, max: 5.6 },
      female: { min: 4.0, max: 5.6 },
    },
    source: 'Other',
  },

  systolicBloodPressure: {
    id: 'systolicBloodPressure',
    name: 'Systolic Blood Pressure',
    abbreviation: 'SBP',
    description: 'Pressure in arteries when heart beats',
    usUnit: 'mmHg',
    siUnit: 'mmHg',
    conversionFactor: 1,
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 90, max: 120 },
      female: { min: 90, max: 120 },
    },
    source: 'Other',
  },

  uricAcid: {
    id: 'uricAcid',
    name: 'Uric Acid',
    abbreviation: 'UA',
    description: 'Metabolic waste product, elevated in gout',
    usUnit: 'mg/dL',
    siUnit: 'µmol/L',
    conversionFactor: 59.48, // µmol/L = mg/dL * 59.48
    conversionType: 'multiply',
    referenceRanges: {
      male: { min: 3.5, max: 7.2 },
      female: { min: 2.5, max: 6.2 },
    },
    source: 'CMP',
  },
};

// Required biomarkers for PhenoAge
export const PHENOAGE_REQUIRED_BIOMARKERS = [
  'whiteBloodCellCount',
  'lymphocytePercent',
  'meanCellVolume',
  'redCellDistributionWidth',
  'albumin',
  'creatinine',
  'glucose',
  'alkalinePhosphatase',
  'cReactiveProtein',
];

// Required biomarkers for KDM
export const KDM_REQUIRED_BIOMARKERS = [
  'albumin',
  'creatinine',
  'glucose',
  'cReactiveProtein',
  'alkalinePhosphatase',
  'bloodUreaNitrogen',
  'totalCholesterol',
  'systolicBloodPressure',
];

// Get biomarkers grouped by source for UI
export function getBiomarkersBySource(): Record<string, BiomarkerInfo[]> {
  const grouped: Record<string, BiomarkerInfo[]> = {};

  Object.values(BIOMARKER_INFO).forEach(biomarker => {
    if (!grouped[biomarker.source]) {
      grouped[biomarker.source] = [];
    }
    grouped[biomarker.source].push(biomarker);
  });

  return grouped;
}
