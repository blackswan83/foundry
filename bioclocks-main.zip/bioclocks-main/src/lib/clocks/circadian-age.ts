/**
 * Circadian Rhythm-Based Biological Age Estimation
 *
 * Inspired by CosinorAge methodology. Uses activity rhythm metrics to estimate
 * biological age based on circadian health.
 *
 * References:
 * - Zeitzer et al. (2024) "Circadian rhythm analysis as digital biomarker of aging"
 * - Windred et al. (2024) "Sleep regularity and mortality risk"
 * - Tranah et al. (2011) "Circadian activity rhythms and mortality"
 */

import {
  WearableInput,
  WearableAgeResult,
  WearableContribution,
  WearableClockInfo,
  CircadianMetrics,
} from './wearable-types';

export const CIRCADIAN_AGE_INFO: WearableClockInfo = {
  name: 'Circadian Age',
  version: '1.0.0',
  description:
    'Estimates biological age from circadian rhythm strength and regularity. ' +
    'Weak or fragmented circadian rhythms are associated with accelerated aging and mortality.',
  requiredMetrics: ['relativeAmplitude', 'chronologicalAge'],
  optionalMetrics: ['interdailyStability', 'intradailyVariability', 'acrophase', 'amplitude'],
  minimumDaysRequired: 7,
  supportedDevices: ['apple_watch', 'fitbit', 'oura', 'whoop', 'garmin', 'samsung', 'other'],
  publication: {
    authors: 'Zeitzer JM, et al.',
    title: 'Circadian rhythm analysis using wearable-based accelerometry as a digital biomarker of aging',
    journal: 'npj Digital Medicine',
    year: 2024,
    doi: '10.1038/s41746-024-01111-x',
  },
};

/**
 * Age-related changes in circadian metrics (based on research)
 *
 * RA (Relative Amplitude): Decreases with age (0.8-0.9 in young, 0.5-0.6 in elderly)
 * IS (Interdaily Stability): Decreases slightly with age
 * IV (Intradaily Variability): Increases with age (more fragmented)
 * Amplitude: Decreases with age
 */
interface CircadianNorms {
  relativeAmplitude: number;
  interdailyStability: number;
  intradailyVariability: number;
  amplitude: number;
}

const CIRCADIAN_NORMS_BY_AGE: { [age: number]: CircadianNorms } = {
  20: {
    relativeAmplitude: 0.90,
    interdailyStability: 0.65,
    intradailyVariability: 0.70,
    amplitude: 0.85,
  },
  30: {
    relativeAmplitude: 0.87,
    interdailyStability: 0.63,
    intradailyVariability: 0.75,
    amplitude: 0.82,
  },
  40: {
    relativeAmplitude: 0.82,
    interdailyStability: 0.60,
    intradailyVariability: 0.82,
    amplitude: 0.78,
  },
  50: {
    relativeAmplitude: 0.76,
    interdailyStability: 0.57,
    intradailyVariability: 0.90,
    amplitude: 0.72,
  },
  60: {
    relativeAmplitude: 0.68,
    interdailyStability: 0.53,
    intradailyVariability: 1.00,
    amplitude: 0.65,
  },
  70: {
    relativeAmplitude: 0.58,
    interdailyStability: 0.48,
    intradailyVariability: 1.12,
    amplitude: 0.55,
  },
  80: {
    relativeAmplitude: 0.48,
    interdailyStability: 0.42,
    intradailyVariability: 1.25,
    amplitude: 0.45,
  },
};

/**
 * Interpolate circadian norms for specific age
 */
function interpolateCircadianNorms(age: number): CircadianNorms {
  const ages = Object.keys(CIRCADIAN_NORMS_BY_AGE).map(Number).sort((a, b) => a - b);

  if (age <= ages[0]) return CIRCADIAN_NORMS_BY_AGE[ages[0]];
  if (age >= ages[ages.length - 1]) return CIRCADIAN_NORMS_BY_AGE[ages[ages.length - 1]];

  let lowerAge = ages[0];
  let upperAge = ages[ages.length - 1];

  for (let i = 0; i < ages.length - 1; i++) {
    if (ages[i] <= age && ages[i + 1] > age) {
      lowerAge = ages[i];
      upperAge = ages[i + 1];
      break;
    }
  }

  const ratio = (age - lowerAge) / (upperAge - lowerAge);
  const lower = CIRCADIAN_NORMS_BY_AGE[lowerAge];
  const upper = CIRCADIAN_NORMS_BY_AGE[upperAge];

  return {
    relativeAmplitude: lower.relativeAmplitude + ratio * (upper.relativeAmplitude - lower.relativeAmplitude),
    interdailyStability: lower.interdailyStability + ratio * (upper.interdailyStability - lower.interdailyStability),
    intradailyVariability: lower.intradailyVariability + ratio * (upper.intradailyVariability - lower.intradailyVariability),
    amplitude: lower.amplitude + ratio * (upper.amplitude - lower.amplitude),
  };
}

/**
 * Find age that matches a circadian metric value
 */
function findCircadianAge(
  value: number,
  metricName: keyof CircadianNorms,
  direction: 'increasing' | 'decreasing'
): number {
  const ages = Object.keys(CIRCADIAN_NORMS_BY_AGE).map(Number).sort((a, b) => a - b);

  let low = ages[0];
  let high = ages[ages.length - 1];

  while (high - low > 0.5) {
    const mid = (low + high) / 2;
    const midNorms = interpolateCircadianNorms(mid);
    const midValue = midNorms[metricName];

    if (direction === 'decreasing') {
      if (value < midValue) {
        low = mid;
      } else {
        high = mid;
      }
    } else {
      if (value > midValue) {
        low = mid;
      } else {
        high = mid;
      }
    }
  }

  return Math.round((low + high) / 2);
}

/**
 * Calculate Circadian Age from wearable activity data
 */
export function calculateCircadianAge(input: WearableInput): WearableAgeResult {
  const { chronologicalAge, circadian, activity } = input;

  if (!circadian && !activity) {
    throw new Error('Circadian or activity metrics are required for Circadian Age calculation');
  }

  const contributions: WearableContribution[] = [];
  const ageEstimates: { metric: string; age: number; weight: number }[] = [];

  const expectedNorms = interpolateCircadianNorms(chronologicalAge);

  // 1. Relative Amplitude (primary marker if available)
  if (circadian?.relativeAmplitude !== undefined) {
    const raAge = findCircadianAge(circadian.relativeAmplitude, 'relativeAmplitude', 'decreasing');
    ageEstimates.push({ metric: 'ra', age: raAge, weight: 0.35 });

    contributions.push({
      metric: 'Relative Amplitude (RA)',
      category: 'circadian',
      value: circadian.relativeAmplitude,
      unit: 'ratio',
      percentile: calculateCircadianPercentile(circadian.relativeAmplitude, expectedNorms.relativeAmplitude, 0.15, true),
      status: getRAStatus(circadian.relativeAmplitude),
      ageImpact: raAge - chronologicalAge,
    });
  }

  // 2. Interdaily Stability (rhythm consistency across days)
  if (circadian?.interdailyStability !== undefined) {
    const isAge = findCircadianAge(circadian.interdailyStability, 'interdailyStability', 'decreasing');
    ageEstimates.push({ metric: 'is', age: isAge, weight: 0.25 });

    contributions.push({
      metric: 'Interdaily Stability (IS)',
      category: 'circadian',
      value: circadian.interdailyStability,
      unit: 'index',
      percentile: calculateCircadianPercentile(circadian.interdailyStability, expectedNorms.interdailyStability, 0.1, true),
      status: getISStatus(circadian.interdailyStability),
      ageImpact: isAge - chronologicalAge,
    });
  }

  // 3. Intradaily Variability (rhythm fragmentation within day)
  if (circadian?.intradailyVariability !== undefined) {
    const ivAge = findCircadianAge(circadian.intradailyVariability, 'intradailyVariability', 'increasing');
    ageEstimates.push({ metric: 'iv', age: ivAge, weight: 0.25 });

    contributions.push({
      metric: 'Intradaily Variability (IV)',
      category: 'circadian',
      value: circadian.intradailyVariability,
      unit: 'index',
      percentile: calculateCircadianPercentile(circadian.intradailyVariability, expectedNorms.intradailyVariability, 0.2, false),
      status: getIVStatus(circadian.intradailyVariability),
      ageImpact: ivAge - chronologicalAge,
    });
  }

  // 4. Activity levels as proxy if circadian metrics unavailable
  if (activity?.dailySteps && ageEstimates.length < 2) {
    const stepsAge = calculateStepsAge(activity.dailySteps, chronologicalAge);
    ageEstimates.push({ metric: 'steps', age: stepsAge, weight: 0.15 });

    contributions.push({
      metric: 'Daily Steps',
      category: 'activity',
      value: activity.dailySteps,
      unit: 'steps',
      percentile: getStepsPercentile(activity.dailySteps, chronologicalAge),
      status: getStepsStatus(activity.dailySteps),
      ageImpact: stepsAge - chronologicalAge,
    });
  }

  // 5. Acrophase timing (peak activity time)
  if (circadian?.acrophase !== undefined) {
    const acrophaseDeviation = Math.abs(circadian.acrophase - 14); // Optimal around 2 PM
    const acrophaseAge = chronologicalAge + (acrophaseDeviation > 3 ? acrophaseDeviation * 1.5 : 0);
    ageEstimates.push({ metric: 'acrophase', age: acrophaseAge, weight: 0.15 });

    contributions.push({
      metric: 'Activity Peak Time',
      category: 'circadian',
      value: circadian.acrophase,
      unit: 'hour',
      percentile: getAcrophasePercentile(circadian.acrophase),
      status: getAcrophaseStatus(circadian.acrophase),
      ageImpact: acrophaseAge - chronologicalAge,
    });
  }

  if (ageEstimates.length === 0) {
    throw new Error('Insufficient circadian or activity data for age calculation');
  }

  // Calculate weighted average
  const totalWeight = ageEstimates.reduce((sum, e) => sum + e.weight, 0);
  const weightedAge = ageEstimates.reduce((sum, e) => sum + e.age * e.weight, 0) / totalWeight;

  const biologicalAge = Math.round(weightedAge * 10) / 10;
  const ageDifference = Math.round((biologicalAge - chronologicalAge) * 10) / 10;

  // Interpretation
  let interpretation: 'younger' | 'ontrack' | 'older';
  if (ageDifference <= -3) {
    interpretation = 'younger';
  } else if (ageDifference >= 3) {
    interpretation = 'older';
  } else {
    interpretation = 'ontrack';
  }

  // Confidence score
  let confidenceScore = 40;
  if (circadian?.relativeAmplitude !== undefined) confidenceScore += 20;
  if (circadian?.interdailyStability !== undefined) confidenceScore += 15;
  if (circadian?.intradailyVariability !== undefined) confidenceScore += 15;
  if (input.daysOfData >= 14) confidenceScore += 10;
  else if (input.daysOfData >= 7) confidenceScore += 5;

  const recommendations = generateCircadianRecommendations(contributions, interpretation, circadian);

  return {
    clockName: CIRCADIAN_AGE_INFO.name,
    clockVersion: CIRCADIAN_AGE_INFO.version,
    biologicalAge,
    chronologicalAge,
    ageDifference,
    confidenceScore: Math.min(confidenceScore, 100),
    interpretation,
    componentAges: {
      circadianAge: biologicalAge,
    },
    contributions,
    recommendations,
  };
}

// Helper functions

function calculateCircadianPercentile(
  value: number,
  expected: number,
  stdDev: number,
  higherIsBetter: boolean
): number {
  const zScore = (value - expected) / stdDev;
  const adjustedZ = higherIsBetter ? zScore : -zScore;
  const percentile = 50 + 50 * Math.tanh(adjustedZ * 0.6);
  return Math.round(Math.max(1, Math.min(99, percentile)));
}

function getRAStatus(ra: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (ra >= 0.75) return 'optimal';
  if (ra >= 0.55) return 'suboptimal';
  return 'concerning';
}

function getISStatus(is: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (is >= 0.55) return 'optimal';
  if (is >= 0.40) return 'suboptimal';
  return 'concerning';
}

function getIVStatus(iv: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (iv <= 0.85) return 'optimal';
  if (iv <= 1.1) return 'suboptimal';
  return 'concerning';
}

function getStepsStatus(steps: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (steps >= 8000) return 'optimal';
  if (steps >= 5000) return 'suboptimal';
  return 'concerning';
}

function getStepsPercentile(steps: number, age: number): number {
  // Age-adjusted steps expectations
  const expectedSteps = Math.max(4000, 10000 - (age - 30) * 100);
  const percentile = 50 + 50 * Math.tanh((steps - expectedSteps) / 3000);
  return Math.round(Math.max(1, Math.min(99, percentile)));
}

function calculateStepsAge(steps: number, chronoAge: number): number {
  // Higher steps = younger biological age
  if (steps >= 10000) return chronoAge - 5;
  if (steps >= 8000) return chronoAge - 2;
  if (steps >= 5000) return chronoAge;
  if (steps >= 3000) return chronoAge + 3;
  return chronoAge + 7;
}

function getAcrophasePercentile(acrophase: number): number {
  // Optimal around 13-15 (1-3 PM)
  const deviation = Math.abs(acrophase - 14);
  if (deviation <= 1) return 85;
  if (deviation <= 2) return 65;
  if (deviation <= 3) return 45;
  return 25;
}

function getAcrophaseStatus(acrophase: number): 'optimal' | 'suboptimal' | 'concerning' {
  const deviation = Math.abs(acrophase - 14);
  if (deviation <= 2) return 'optimal';
  if (deviation <= 4) return 'suboptimal';
  return 'concerning';
}

function generateCircadianRecommendations(
  contributions: WearableContribution[],
  interpretation: 'younger' | 'ontrack' | 'older',
  circadian?: CircadianMetrics
): string[] {
  const recommendations: string[] = [];

  const raContrib = contributions.find(c => c.metric === 'Relative Amplitude (RA)');
  const isContrib = contributions.find(c => c.metric === 'Interdaily Stability (IS)');
  const ivContrib = contributions.find(c => c.metric === 'Intradaily Variability (IV)');

  if (raContrib?.status === 'concerning') {
    recommendations.push(
      'Low relative amplitude indicates weak circadian rhythm. Increase daytime activity and reduce nighttime light exposure.'
    );
  }

  if (isContrib?.status === 'concerning') {
    recommendations.push(
      'Irregular daily patterns accelerate aging. Maintain consistent sleep/wake and meal times, even on weekends.'
    );
  }

  if (ivContrib?.status === 'concerning') {
    recommendations.push(
      'Fragmented activity patterns suggest disrupted circadian function. Consolidate activity into daytime hours.'
    );
  }

  if (circadian?.acrophase !== undefined) {
    if (circadian.acrophase < 11) {
      recommendations.push(
        'Very early activity peak may indicate advanced circadian phase. Consider evening light exposure.'
      );
    } else if (circadian.acrophase > 17) {
      recommendations.push(
        'Delayed activity peak suggests delayed circadian phase. Get morning sunlight within 30 min of waking.'
      );
    }
  }

  if (interpretation === 'younger') {
    recommendations.push(
      'Strong circadian rhythms indicate healthy aging. Continue your regular activity and sleep patterns.'
    );
  }

  if (recommendations.length === 0) {
    recommendations.push(
      'Support circadian health: get morning sunlight, exercise during the day, dim lights at night, keep consistent schedules.'
    );
  }

  return recommendations;
}

/**
 * Get missing circadian metrics
 */
export function getMissingCircadianMetrics(input: WearableInput): string[] {
  const missing: string[] = [];

  const hasCircadian = input.circadian?.relativeAmplitude !== undefined ||
    input.circadian?.interdailyStability !== undefined ||
    input.circadian?.intradailyVariability !== undefined;

  const hasActivity = input.activity?.dailySteps !== undefined;

  if (!hasCircadian && !hasActivity) {
    missing.push('relativeAmplitude or dailySteps');
  }

  return missing;
}
