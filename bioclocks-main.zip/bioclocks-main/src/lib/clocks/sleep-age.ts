/**
 * Sleep-Based Biological Age Estimation
 *
 * Based on research showing sleep architecture and quality change predictably with age.
 *
 * References:
 * - Ohayon et al. (2004) "Meta-analysis of quantitative sleep parameters"
 * - Li et al. (2022) "Deep sleep and biological aging"
 * - Windred et al. (2024) "Sleep regularity and mortality risk"
 */

import {
  WearableInput,
  WearableAgeResult,
  WearableContribution,
  WearableClockInfo,
  SleepMetrics,
} from './wearable-types';

export const SLEEP_AGE_INFO: WearableClockInfo = {
  name: 'Sleep Age',
  version: '1.0.0',
  description:
    'Estimates biological age based on sleep quality, duration, and architecture. ' +
    'Sleep patterns are a sensitive marker of brain aging and metabolic health.',
  requiredMetrics: ['totalSleepTime', 'sleepEfficiency', 'chronologicalAge'],
  optionalMetrics: ['deepSleepMinutes', 'remSleepMinutes', 'wakeAfterSleepOnset', 'sleepOnsetLatency'],
  minimumDaysRequired: 7,
  supportedDevices: ['apple_watch', 'fitbit', 'oura', 'whoop', 'garmin', 'samsung', 'other'],
  publication: {
    authors: 'Ohayon MM, et al.',
    title: 'Meta-analysis of quantitative sleep parameters from childhood to old age',
    journal: 'Sleep',
    year: 2004,
    doi: '10.1093/sleep/27.7.1255',
  },
};

/**
 * Age-related changes in sleep parameters (based on meta-analyses)
 */
interface SleepNorm {
  sleepEfficiency: number;       // %
  totalSleepTime: number;        // minutes
  deepSleepPercent: number;      // % of TST
  remSleepPercent: number;       // % of TST
  waso: number;                  // minutes
  sleepOnsetLatency: number;     // minutes
}

const SLEEP_NORMS_BY_AGE: { [age: number]: SleepNorm } = {
  20: {
    sleepEfficiency: 95,
    totalSleepTime: 450,
    deepSleepPercent: 20,
    remSleepPercent: 22,
    waso: 10,
    sleepOnsetLatency: 10,
  },
  30: {
    sleepEfficiency: 93,
    totalSleepTime: 435,
    deepSleepPercent: 17,
    remSleepPercent: 21,
    waso: 15,
    sleepOnsetLatency: 12,
  },
  40: {
    sleepEfficiency: 90,
    totalSleepTime: 420,
    deepSleepPercent: 14,
    remSleepPercent: 20,
    waso: 22,
    sleepOnsetLatency: 14,
  },
  50: {
    sleepEfficiency: 87,
    totalSleepTime: 405,
    deepSleepPercent: 11,
    remSleepPercent: 19,
    waso: 30,
    sleepOnsetLatency: 16,
  },
  60: {
    sleepEfficiency: 84,
    totalSleepTime: 390,
    deepSleepPercent: 9,
    remSleepPercent: 18,
    waso: 40,
    sleepOnsetLatency: 18,
  },
  70: {
    sleepEfficiency: 80,
    totalSleepTime: 375,
    deepSleepPercent: 7,
    remSleepPercent: 17,
    waso: 50,
    sleepOnsetLatency: 20,
  },
  80: {
    sleepEfficiency: 76,
    totalSleepTime: 360,
    deepSleepPercent: 5,
    remSleepPercent: 16,
    waso: 60,
    sleepOnsetLatency: 22,
  },
};

/**
 * Interpolate sleep norms for a specific age
 */
function interpolateSleepNorms(age: number): SleepNorm {
  const ages = Object.keys(SLEEP_NORMS_BY_AGE).map(Number).sort((a, b) => a - b);

  if (age <= ages[0]) return SLEEP_NORMS_BY_AGE[ages[0]];
  if (age >= ages[ages.length - 1]) return SLEEP_NORMS_BY_AGE[ages[ages.length - 1]];

  let lowerAge = ages[0];
  let upperAge = ages[ages.length - 1];

  for (let i = 0; i < ages.length - 1; i++) {
    if (ages[i] <= age && ages[i + 1] > age) {
      lowerAge = ages[i];
      upperAge = ages[i + 1];
      break;
    }
  }

  const ratio = (age - lowerAge) / (upperAge - lowerAge);
  const lower = SLEEP_NORMS_BY_AGE[lowerAge];
  const upper = SLEEP_NORMS_BY_AGE[upperAge];

  return {
    sleepEfficiency: lower.sleepEfficiency + ratio * (upper.sleepEfficiency - lower.sleepEfficiency),
    totalSleepTime: lower.totalSleepTime + ratio * (upper.totalSleepTime - lower.totalSleepTime),
    deepSleepPercent: lower.deepSleepPercent + ratio * (upper.deepSleepPercent - lower.deepSleepPercent),
    remSleepPercent: lower.remSleepPercent + ratio * (upper.remSleepPercent - lower.remSleepPercent),
    waso: lower.waso + ratio * (upper.waso - lower.waso),
    sleepOnsetLatency: lower.sleepOnsetLatency + ratio * (upper.sleepOnsetLatency - lower.sleepOnsetLatency),
  };
}

/**
 * Find the age that best matches a given metric value
 */
function findMatchingAge(
  value: number,
  metricName: keyof SleepNorm,
  direction: 'increasing' | 'decreasing'
): number {
  const ages = Object.keys(SLEEP_NORMS_BY_AGE).map(Number).sort((a, b) => a - b);

  // Binary search
  let low = ages[0];
  let high = ages[ages.length - 1];

  while (high - low > 0.5) {
    const mid = (low + high) / 2;
    const midNorms = interpolateSleepNorms(mid);
    const midValue = midNorms[metricName];

    if (direction === 'decreasing') {
      // Value decreases with age (efficiency, deep sleep %)
      if (value < midValue) {
        low = mid;
      } else {
        high = mid;
      }
    } else {
      // Value increases with age (WASO, SOL)
      if (value > midValue) {
        low = mid;
      } else {
        high = mid;
      }
    }
  }

  return Math.round((low + high) / 2);
}

/**
 * Calculate Sleep Age from wearable data
 */
export function calculateSleepAge(input: WearableInput): WearableAgeResult {
  const { chronologicalAge, sleep } = input;

  if (!sleep) {
    throw new Error('Sleep metrics are required for Sleep Age calculation');
  }

  if (!sleep.totalSleepTime || !sleep.sleepEfficiency) {
    throw new Error('Total sleep time and sleep efficiency are required');
  }

  const contributions: WearableContribution[] = [];
  const ageEstimates: { metric: string; age: number; weight: number }[] = [];

  const expectedNorms = interpolateSleepNorms(chronologicalAge);

  // 1. Sleep Efficiency (primary marker)
  const efficiencyAge = findMatchingAge(sleep.sleepEfficiency, 'sleepEfficiency', 'decreasing');
  ageEstimates.push({ metric: 'efficiency', age: efficiencyAge, weight: 0.3 });

  contributions.push({
    metric: 'Sleep Efficiency',
    category: 'sleep',
    value: sleep.sleepEfficiency,
    unit: '%',
    percentile: calculateSleepPercentile(sleep.sleepEfficiency, expectedNorms.sleepEfficiency, 15, true),
    status: getSleepStatus(sleep.sleepEfficiency, 85, 90),
    ageImpact: efficiencyAge - chronologicalAge,
  });

  // 2. Deep Sleep (if available) - strongest aging marker
  if (sleep.deepSleepMinutes && sleep.totalSleepTime) {
    const deepSleepPercent = (sleep.deepSleepMinutes / sleep.totalSleepTime) * 100;
    const deepSleepAge = findMatchingAge(deepSleepPercent, 'deepSleepPercent', 'decreasing');
    ageEstimates.push({ metric: 'deepSleep', age: deepSleepAge, weight: 0.25 });

    contributions.push({
      metric: 'Deep Sleep',
      category: 'sleep',
      value: deepSleepPercent,
      unit: '% of sleep',
      percentile: calculateSleepPercentile(deepSleepPercent, expectedNorms.deepSleepPercent, 5, true),
      status: getSleepStatus(deepSleepPercent, 10, 15),
      ageImpact: deepSleepAge - chronologicalAge,
    });
  }

  // 3. REM Sleep (if available)
  if (sleep.remSleepMinutes && sleep.totalSleepTime) {
    const remSleepPercent = (sleep.remSleepMinutes / sleep.totalSleepTime) * 100;
    const remSleepAge = findMatchingAge(remSleepPercent, 'remSleepPercent', 'decreasing');
    ageEstimates.push({ metric: 'remSleep', age: remSleepAge, weight: 0.15 });

    contributions.push({
      metric: 'REM Sleep',
      category: 'sleep',
      value: remSleepPercent,
      unit: '% of sleep',
      percentile: calculateSleepPercentile(remSleepPercent, expectedNorms.remSleepPercent, 4, true),
      status: getSleepStatus(remSleepPercent, 15, 20),
      ageImpact: remSleepAge - chronologicalAge,
    });
  }

  // 4. WASO (if available)
  if (sleep.wakeAfterSleepOnset !== undefined) {
    const wasoAge = findMatchingAge(sleep.wakeAfterSleepOnset, 'waso', 'increasing');
    ageEstimates.push({ metric: 'waso', age: wasoAge, weight: 0.15 });

    contributions.push({
      metric: 'Wake After Sleep Onset',
      category: 'sleep',
      value: sleep.wakeAfterSleepOnset,
      unit: 'min',
      percentile: calculateSleepPercentile(sleep.wakeAfterSleepOnset, expectedNorms.waso, 15, false),
      status: getWasoStatus(sleep.wakeAfterSleepOnset),
      ageImpact: wasoAge - chronologicalAge,
    });
  }

  // 5. Sleep Duration (optimal is 7-8 hours; both short and long sleep associated with aging)
  const durationAge = calculateDurationAge(sleep.totalSleepTime, chronologicalAge);
  ageEstimates.push({ metric: 'duration', age: durationAge, weight: 0.15 });

  contributions.push({
    metric: 'Sleep Duration',
    category: 'sleep',
    value: sleep.totalSleepTime / 60,
    unit: 'hours',
    percentile: getDurationPercentile(sleep.totalSleepTime),
    status: getDurationStatus(sleep.totalSleepTime),
    ageImpact: durationAge - chronologicalAge,
  });

  // Calculate weighted average age
  const totalWeight = ageEstimates.reduce((sum, e) => sum + e.weight, 0);
  const weightedAge = ageEstimates.reduce((sum, e) => sum + e.age * e.weight, 0) / totalWeight;

  const biologicalAge = Math.round(weightedAge * 10) / 10;
  const ageDifference = Math.round((biologicalAge - chronologicalAge) * 10) / 10;

  // Interpretation
  let interpretation: 'younger' | 'ontrack' | 'older';
  if (ageDifference <= -3) {
    interpretation = 'younger';
  } else if (ageDifference >= 3) {
    interpretation = 'older';
  } else {
    interpretation = 'ontrack';
  }

  // Confidence score
  let confidenceScore = 50;
  if (sleep.deepSleepMinutes) confidenceScore += 15;
  if (sleep.remSleepMinutes) confidenceScore += 10;
  if (sleep.wakeAfterSleepOnset !== undefined) confidenceScore += 10;
  if (input.daysOfData >= 14) confidenceScore += 15;
  else if (input.daysOfData >= 7) confidenceScore += 8;

  // Recommendations
  const recommendations = generateSleepRecommendations(contributions, interpretation, sleep);

  return {
    clockName: SLEEP_AGE_INFO.name,
    clockVersion: SLEEP_AGE_INFO.version,
    biologicalAge,
    chronologicalAge,
    ageDifference,
    confidenceScore: Math.min(confidenceScore, 100),
    interpretation,
    componentAges: {
      sleepAge: biologicalAge,
    },
    contributions,
    recommendations,
  };
}

function calculateSleepPercentile(
  value: number,
  expected: number,
  stdDev: number,
  higherIsBetter: boolean
): number {
  const zScore = (value - expected) / stdDev;
  const adjustedZ = higherIsBetter ? zScore : -zScore;
  const percentile = 50 + 50 * Math.tanh(adjustedZ * 0.6);
  return Math.round(Math.max(1, Math.min(99, percentile)));
}

function getSleepStatus(value: number, poor: number, good: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (value >= good) return 'optimal';
  if (value >= poor) return 'suboptimal';
  return 'concerning';
}

function getWasoStatus(waso: number): 'optimal' | 'suboptimal' | 'concerning' {
  if (waso <= 20) return 'optimal';
  if (waso <= 40) return 'suboptimal';
  return 'concerning';
}

function getDurationStatus(minutes: number): 'optimal' | 'suboptimal' | 'concerning' {
  const hours = minutes / 60;
  if (hours >= 7 && hours <= 9) return 'optimal';
  if (hours >= 6 && hours <= 10) return 'suboptimal';
  return 'concerning';
}

function getDurationPercentile(minutes: number): number {
  const hours = minutes / 60;
  // Optimal around 7.5 hours
  const deviation = Math.abs(hours - 7.5);
  if (deviation <= 0.5) return 85;
  if (deviation <= 1) return 70;
  if (deviation <= 1.5) return 50;
  if (deviation <= 2) return 30;
  return 15;
}

function calculateDurationAge(minutes: number, chronoAge: number): number {
  const hours = minutes / 60;
  // U-shaped relationship: both short and long sleep add years
  const optimalHours = 7.5;
  const deviation = Math.abs(hours - optimalHours);

  // Each hour deviation from optimal adds ~2 years of biological age
  const ageAdjustment = deviation * 2;

  return chronoAge + ageAdjustment;
}

function generateSleepRecommendations(
  contributions: WearableContribution[],
  interpretation: 'younger' | 'ontrack' | 'older',
  sleep: SleepMetrics
): string[] {
  const recommendations: string[] = [];

  const efficiencyContrib = contributions.find(c => c.metric === 'Sleep Efficiency');
  const deepSleepContrib = contributions.find(c => c.metric === 'Deep Sleep');
  const durationContrib = contributions.find(c => c.metric === 'Sleep Duration');

  if (efficiencyContrib?.status === 'concerning') {
    recommendations.push(
      'Improve sleep efficiency by maintaining consistent sleep/wake times and avoiding screens before bed.'
    );
  }

  if (deepSleepContrib?.status === 'concerning') {
    recommendations.push(
      'Low deep sleep impacts recovery and memory. Exercise during the day and keep the bedroom cool (65-68°F).'
    );
  }

  if (durationContrib?.status === 'concerning') {
    const hours = sleep.totalSleepTime / 60;
    if (hours < 6) {
      recommendations.push(
        'Short sleep duration accelerates biological aging. Aim for 7-8 hours per night.'
      );
    } else if (hours > 9) {
      recommendations.push(
        'Excessive sleep may indicate underlying health issues. Consider consulting a healthcare provider.'
      );
    }
  }

  if (sleep.wakeAfterSleepOnset && sleep.wakeAfterSleepOnset > 30) {
    recommendations.push(
      'Frequent nighttime awakenings fragment sleep. Limit alcohol and caffeine, especially after noon.'
    );
  }

  if (interpretation === 'younger') {
    recommendations.push(
      'Excellent sleep quality! Your sleep patterns indicate healthy brain and metabolic aging.'
    );
  }

  if (recommendations.length === 0) {
    recommendations.push(
      'Maintain good sleep hygiene: consistent schedule, dark room, cool temperature, and wind-down routine.'
    );
  }

  return recommendations;
}

/**
 * Get missing sleep metrics
 */
export function getMissingSleepMetrics(input: WearableInput): string[] {
  const missing: string[] = [];

  if (!input.sleep?.totalSleepTime) missing.push('totalSleepTime');
  if (!input.sleep?.sleepEfficiency) missing.push('sleepEfficiency');

  return missing;
}
