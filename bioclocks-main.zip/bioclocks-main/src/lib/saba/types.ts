// SABA Study - Type Definitions
// Multi-audience dashboard types for the Sardinian Blue Zone Longevity Study

// =============================================================================
// ENROLLMENT & STUDY STATISTICS
// =============================================================================

export interface StudyStats {
  totalParticipants: number;
  centenarianParticipants: number;
  superAgerParticipants: number; // 80+ with exceptional health
  totalWearableDays: number;
  questionnairesCompleted: number;
  biomarkerSamplesAnalyzed: number;
  lastUpdated: string; // ISO date
}

export interface EnrollmentMilestone {
  date: string;
  label: string;
  count: number;
  type: 'enrollment' | 'centenarian' | 'milestone';
}

export interface EnrollmentTrend {
  date: string;
  cumulative: number;
  weekly: number;
}

// =============================================================================
// GEOGRAPHIC DATA
// =============================================================================

export interface CommuneData {
  name: string;
  province: string;
  isBlueZone: boolean;
  enrollmentCount: number; // Rounded to nearest 20 for privacy
  coordinates: { lat: number; lng: number };
  centenarianRate?: number; // per 10,000 population
}

export type RegionDensity = 'low' | 'medium' | 'high' | 'very-high';

// =============================================================================
// AGGREGATE FINDINGS (Privacy-Preserving)
// =============================================================================

export interface AggregateFinding {
  id: string;
  title: string;
  description: string;
  metric: string;
  comparisonGroup: string;
  significance: 'preliminary' | 'significant' | 'validated';
  publishedDate: string;
  category: 'lifestyle' | 'biomarker' | 'circadian' | 'social' | 'dietary';
}

export interface DemographicBreakdown {
  ageRange: string;
  maleCount: number; // Rounded to nearest 20
  femaleCount: number; // Rounded to nearest 20
  percentageOfTotal: number;
}

// =============================================================================
// SHAPE CLOCK TYPES
// =============================================================================

export interface ShapeClockResult {
  compositeAge: number;
  chronologicalAge: number;
  ageDifference: number;
  confidenceInterval: { lower: number; upper: number };
  contributingFactors: ShapeContributingFactor[];
  interpretation: 'younger' | 'ontrack' | 'older';
}

export interface ShapeContributingFactor {
  name: string;
  category: 'circadian' | 'hrv' | 'sleep' | 'activity' | 'questionnaire';
  contribution: number; // Years added or subtracted
  status: 'optimal' | 'moderate' | 'suboptimal';
  percentile?: number;
}

export interface ShapeValidationMetric {
  clockName: string;
  correlation: number; // r value
  meanAbsoluteError: number; // Years
  sampleSize: number;
  validationCohort: string;
  comparisonToClock?: {
    name: string;
    relativePredictivePower: number; // e.g., 0.85 means 85% as good
  };
}

// =============================================================================
// SUPER-AGER COHORT
// =============================================================================

export interface SuperAgerProfile {
  id: string; // Anonymized
  ageRange: string; // 5-year bands
  biologicalAgeGap: number; // Negative = younger
  keyCharacteristics: string[];
  hrv: {
    rmssd: number;
    percentileVsAgeMatched: number;
  };
  sleepEfficiency: number;
  activityLevel: 'low' | 'moderate' | 'high' | 'very-high';
  dietaryPattern: string;
}

export interface CohortComparison {
  metric: string;
  unit: string;
  sabaBlueZone: { mean: number; std: number; n: number };
  generalPopulation: { mean: number; std: number; n: number };
  pValue?: number;
  percentDifference: number;
}

// =============================================================================
// WEARABLE VALIDATION
// =============================================================================

export interface WearableValidation {
  metric: string;
  deviceType: string;
  goldStandard: string;
  correlation: number;
  blandAltmanBias: number;
  limitsOfAgreement: { lower: number; upper: number };
  sampleSize: number;
  publication?: string;
}

export interface PopulationNorm {
  metric: string;
  ageRange: string;
  sex: 'male' | 'female' | 'all';
  mean: number;
  percentile5: number;
  percentile25: number;
  percentile50: number;
  percentile75: number;
  percentile95: number;
  unit: string;
}

// =============================================================================
// RESEARCHER ACCESS PORTAL
// =============================================================================

export type AccessTier = 'public' | 'registered' | 'controlled' | 'collaborative';

export interface AccessTierInfo {
  tier: AccessTier;
  name: string;
  description: string;
  requirements: string[];
  dataAccess: string[];
  process: string[];
  estimatedTimeline: string;
  cost?: string;
}

export interface DataCatalogEntry {
  variableId: string;
  variableName: string;
  category: string;
  description: string;
  dataType: 'continuous' | 'categorical' | 'binary' | 'date' | 'text';
  sampleSize: number;
  completeness: number; // 0-100%
  tier: AccessTier;
  unit?: string;
  valueRange?: { min: number; max: number };
  categories?: string[];
}

export interface DataCategory {
  id: string;
  name: string;
  description: string;
  variableCount: number;
  icon: string;
}

export interface ResearchProject {
  id: string;
  title: string;
  institution: string;
  principalInvestigator: string;
  status: 'active' | 'completed' | 'pending';
  tier: AccessTier;
  startDate: string;
  publications?: number;
}

export interface ApplicationStatus {
  step: 'registration' | 'submission' | 'review' | 'approval' | 'access';
  completed: boolean;
  date?: string;
}

// =============================================================================
// PUBLICATIONS & CREDIBILITY
// =============================================================================

export interface Publication {
  id: string;
  title: string;
  authors: string;
  journal: string;
  year: number;
  doi: string;
  category: 'methodology' | 'validation' | 'findings' | 'review';
  impactFactor?: number;
  citations?: number;
}

export interface TeamMember {
  name: string;
  role: string;
  affiliation: string;
  expertise: string[];
  imageUrl?: string;
}

export interface AdvisoryBoardMember {
  name: string;
  title: string;
  affiliation: string;
  notableAchievements: string[];
}

// =============================================================================
// LIFESTYLE FACTORS (Blue Zone Specific)
// =============================================================================

export interface LifestyleFactor {
  id: string;
  name: string;
  category: 'diet' | 'physical' | 'social' | 'sleep' | 'stress';
  prevalenceInStudy: number; // 0-100%
  associatedAgeEffect: number; // Years younger (negative) or older (positive)
  confidenceInterval: { lower: number; upper: number };
  description: string;
}

export interface DietaryPattern {
  pattern: string;
  adherencePercentage: number;
  keyComponents: string[];
  biologicalAgeCorrelation: number;
}
