// SABA Study Database Connection
// Connects to the study PostgreSQL database on AWS RDS

import { Pool, PoolClient } from 'pg';

// Database configuration from environment variables
const dbConfig = {
  host: process.env.STUDY_APP_DB_HOST || 'ixarun-studydb-instance-1.ct2giqwiujxc.eu-central-1.rds.amazonaws.com',
  port: parseInt(process.env.STUDY_APP_DB_PORT || '5432'),
  database: process.env.STUDY_APP_DB_NAME || 'studydb2',
  user: process.env.STUDY_APP_DB_USERNAME || 'study_user',
  password: process.env.STUDY_APP_DB_PASSWORD,
  ssl: {
    rejectUnauthorized: false, // Required for AWS RDS
  },
  connectionTimeoutMillis: 10000,
  idleTimeoutMillis: 30000,
  max: 10, // Maximum pool size
};

// Singleton pool instance
let pool: Pool | null = null;

export function getPool(): Pool {
  if (!pool) {
    pool = new Pool(dbConfig);

    // Handle pool errors
    pool.on('error', (err) => {
      console.error('Unexpected error on idle client', err);
    });
  }
  return pool;
}

export async function query<T = Record<string, unknown>>(
  text: string,
  params?: unknown[]
): Promise<T[]> {
  const pool = getPool();
  const start = Date.now();

  try {
    const result = await pool.query(text, params);
    const duration = Date.now() - start;
    console.log('Executed query', { text: text.substring(0, 50), duration, rows: result.rowCount });
    return result.rows as T[];
  } catch (error) {
    console.error('Database query error:', error);
    throw error;
  }
}

export async function getClient(): Promise<PoolClient> {
  const pool = getPool();
  return pool.connect();
}

// Check if database is configured
export function isDatabaseConfigured(): boolean {
  return !!process.env.STUDY_APP_DB_PASSWORD;
}

// Close pool (for cleanup)
export async function closePool(): Promise<void> {
  if (pool) {
    await pool.end();
    pool = null;
  }
}
