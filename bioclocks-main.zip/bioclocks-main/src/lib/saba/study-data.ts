// SABA Study - Sardinian Aging Biomarkers Analysis
// A next-generation biobank for longevity research
// Part of e.INS Spoke 01: A New Route to Preventive Medicine | Funded by NextGenerationEU

// =============================================================================
// COHORT STATISTICS
// =============================================================================

export const cohortStats = {
  // Current digital cohort (September 2025 onwards)
  totalParticipants: 1247,
  targetParticipants: 20000,
  targetYear: 2026,
  ageRange: { min: 18, max: 88 },
  meanAge: 41.6,
  ageStdDev: 14.0,
  demographics: {
    female: { count: 672, percentage: 53.9 },
    male: { count: 550, percentage: 44.1 },
    other: { count: 25, percentage: 2.0 },
  },
  superAgers: {
    count: 132,
    percentage: 10.6,
    definition: 'Participants 60+ showing younger biological markers',
  },
  wearableHours: 95000,
  questionnaireHours: 2500,
  medianTrackingDays: 33,
  studyStartDate: '2025-09-01',
  infrastructureMonths: 6, // Infrastructure built over 6 months

  // Historical foundation (since 2001)
  historicalSuperAgers: 10000,
  historicalStartYear: 2001,
  historicalYears: 24,

  // Geographic distribution
  sardiniaPercentage: 90,
  italyControlPercentage: 10,
};

// =============================================================================
// PAGE COPY
// =============================================================================

export const pageCopy = {
  hero: {
    title: 'SABA — Sardinian Aging Biomarkers Analysis',
    subtitle: `A next-generation biobank for longevity research. SABA collects continuous wearable data, validated questionnaires, and biological samples from Sardinia's Blue Zone — building on two decades of super ager research to understand what determines extreme longevity at a resolution never achieved before.`,
    funding: 'Part of e.INS Spoke 01: A New Route to Preventive Medicine | Funded by NextGenerationEU',
  },
  whySardinia: {
    title: 'Why Sardinia?',
    paragraphs: [
      `Sardinia's Blue Zone has the highest documented concentration of super agers in the world. Since 2001, over 10,000 individuals have been tracked here — but never with continuous digital monitoring.`,
      `SABA changes that. Launched in September 2025, we capture real-time physiological data alongside validated measures of stress, social connection, and purpose — the factors epidemiologists have long suspected drive longevity but never quantified at this resolution.`,
    ],
    objective: `Our objective: decode what determines extreme longevity at the micro level, then apply those insights globally through Nuraxi's World Model for human health.`,
  },
  whatWeAreBuilding: {
    title: 'What We\'re Building',
    paragraphs: [
      `SABA is not a traditional observational study — it's a next-generation biobank designed for AI training.`,
      `Every data point collected feeds into the SHAPE Clock, our framework for estimating biological age from non-invasive inputs. SABA's high-resolution Sardinian data serves as ground truth, validated against the world's most documented longevity population.`,
      `The insights extracted here — on social connection, circadian health, stress resilience, and purpose — become transferable to populations worldwide through Nuraxi's federated health AI, trained on 50+ million longitudinal patient records.`,
    ],
    tagline: 'Sardinia teaches. The world learns.',
  },
  keyFindings: {
    title: 'Key Findings',
    intro: `Quantifying What Has Never Been Measured`,
    introDescription: `For the first time, we are systematically capturing the factors behind extreme longevity: social interaction frequency, sense of purpose, and psychosocial resilience — translated into computable biomarkers actionable at the individual level.`,
  },
  dataCollection: {
    title: 'How We Collect Data',
    intro: 'Multi-modal data capture designed for World Model training:',
  },
  ctaCards: {
    science: {
      title: 'SHAPE Clock Methodology',
      description: 'How we estimate biological age from non-invasive inputs — and what Sardinian super agers reveal about healthy aging trajectories.',
    },
    research: {
      title: 'Collaborate With Us',
      description: 'Request data access or explore partnership opportunities for institutional and commercial research.',
    },
  },
};

// =============================================================================
// KEY FINDINGS
// =============================================================================

export const activityFindings = {
  sabaAvgSteps: 10264,
  comparisons: [
    { name: 'SABA Cohort', steps: 10264, advantage: 0 },
    { name: 'UK Biobank', steps: 8000, advantage: 28 },
    { name: 'All of Us', steps: 7000, advantage: 47 },
    { name: 'US Average', steps: 6500, advantage: 58 },
  ],
  activityGroups: {
    lowActive: { threshold: '<7,500 steps', avgHR: 65.7, sampleSize: 101 },
    highlyActive: { threshold: '≥10,000 steps', avgHR: 61.5, sampleSize: 191 },
    difference: 4.2,
    tStat: 4.23,
    pValue: '<0.001',
  },
  meetingGoals: 48.4, // % meeting activity goals
};

export const lonelinessFindings = {
  lowLoneliness: { avgHR: 62.6 },
  highLoneliness: { avgHR: 65.4 },
  difference: 2.8,
  correlation: 0.125,
  pValue: 0.013,
};

export const stressFindings = {
  levels: [
    { level: 'Low', percentage: 29, avgHR: 61.4 },
    { level: 'Moderate', percentage: 59.6, avgHR: 63.7 },
    { level: 'High', percentage: 11.4, avgHR: 64.9 },
  ],
  totalDifference: 3.5,
  correlation: 0.150,
  pValue: 0.003,
};

export const psychosocialTriad = {
  stressLoneliness: { correlation: 0.494, pValue: '<0.001', strength: 'strong' },
  stressHealth: { correlation: -0.261, pValue: '<0.001', strength: 'moderate' },
  lonelinessHealth: { correlation: -0.196, pValue: '<0.001', strength: 'moderate' },
};

// =============================================================================
// SHAPE CLOCK FRAMEWORK
// =============================================================================

export const shapeFramework = {
  name: 'SHAPE Clock',
  fullName: 'Strategies for Healthy And Prolonged Existence',
  description: 'Traditional biological age clocks require expensive lab tests. SHAPE estimates biological age using only non-invasive inputs: wearable data (HRV, sleep, activity), validated questionnaires (stress, social connection, chronotype), and basic health assessments. This makes continuous, scalable biological age tracking possible for the first time.',
  measures: [
    { name: 'Cardiovascular fitness', description: 'via resting HR and HRV patterns', icon: 'Heart' },
    { name: 'Circadian health', description: 'via sleep quality and chronotype', icon: 'Moon' },
    { name: 'Psychosocial wellbeing', description: 'via stress and loneliness scores', icon: 'Users' },
    { name: 'Activity patterns', description: 'via daily step counts and movement', icon: 'Activity' },
  ],
};

// =============================================================================
// DATA COLLECTION METHODS
// =============================================================================

export const dataCollectionMethods = [
  { name: 'Wearables', description: 'Heart rate, HRV, sleep architecture, daily activity', icon: 'Watch' },
  { name: 'Biological Samples', description: 'Nuraxi blood panel for longevity biomarkers', icon: 'Droplet' },
  { name: 'Validated Scales', description: 'Stress (PSS-10), Loneliness (UCLA), Chronotype (rMEQ)', icon: 'ClipboardList' },
  { name: 'Health Perception', description: 'Self-rated health status', icon: 'Heart' },
  { name: 'Social Clocks', description: 'Interaction frequency and relationship quality', icon: 'Users' },
];

// =============================================================================
// BIO AGE SCATTER DATA (Simulated based on cohort)
// =============================================================================

export function generateBioAgeScatterData() {
  const data: Array<{
    chronologicalAge: number;
    biologicalAge: number;
    isSuperAger: boolean;
  }> = [];

  // Generate ~395 data points based on actual age distribution
  // Mean age 41.6, std dev 14.0, range 18-88

  for (let i = 0; i < 395; i++) {
    // Generate age using approximation of actual distribution
    let chronAge: number;
    const rand = Math.random();

    if (rand < 0.106) {
      // 10.6% are 60+
      chronAge = 60 + Math.random() * 28; // 60-88
    } else {
      // Rest distributed around mean of 41.6
      chronAge = 18 + Math.random() * 42; // 18-60
    }

    chronAge = Math.round(chronAge);

    // Bio age calculation with noise
    let bioAge: number;
    const noise = (Math.random() - 0.5) * 15; // ±7.5 years noise

    if (chronAge >= 60) {
      // Super agers: bio age 5-15 years younger
      const superAgerBonus = 5 + Math.random() * 10;
      bioAge = chronAge - superAgerBonus + noise * 0.5;
    } else {
      // Regular aging with some variation
      bioAge = chronAge + noise;
    }

    // Clamp bio age to reasonable range
    bioAge = Math.max(18, Math.min(95, Math.round(bioAge * 10) / 10));

    data.push({
      chronologicalAge: chronAge,
      biologicalAge: bioAge,
      isSuperAger: chronAge >= 60 && bioAge < chronAge - 5,
    });
  }

  return data;
}

// =============================================================================
// RESEARCHER PORTAL DATA
// =============================================================================

export const dataAvailable = [
  'Continuous biometric data (HR, HRV, sleep, steps) — 30,000+ hours',
  'Validated questionnaires (PSS-10, UCLA Loneliness, rMEQ chronotype)',
  'Demographic and health self-assessments',
  'Longitudinal tracking (median 33 days per participant)',
];

export const ipAndFuture = {
  knowHow: 'Validated methodologies for non-invasive biological age estimation',
  shapeClock: 'A proprietary framework for continuous healthspan tracking',
  nora: 'An AI health assistant translating longevity science into personalized guidance',
  futureText: 'The study continues independently beyond initial funding, with plans to expand the cohort and integrate additional biological data.',
};

// =============================================================================
// FOOTER DATA
// =============================================================================

export const footerData = {
  mainText: `SABA is an industrial research project funded by the European Union through NextGenerationEU, under the PNRR Ecosystem of Innovation e.INS — Spoke 01: A New Route to Preventive Medicine (CUP: J83C21000320007).`,
  spokeLeader: 'Spoke Leader: Universit\u00e0 degli Studi di Sassari',
  infrastructure: 'Research infrastructure developed by Nuraxi',
  links: ['About', 'Contact', 'Privacy Policy'],
  institutions: ['EU NextGenerationEU', 'Italian Ministry', 'UNISS', 'Nuraxi'],
  // Legacy tagline for backwards compatibility
  tagline: 'Part of the e.INS Innovation Ecosystem — Spoke 01: Preventive Medicine',
};
