'use client';

import { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'en' | 'it';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Translations
const translations: Record<Language, Record<string, string>> = {
  en: {
    // Navigation
    'nav.public': 'Public',
    'nav.science': 'Science',
    'nav.research': 'Research',
    'nav.sabaStudy': 'SABA Study',

    // Hero
    'hero.title': 'SABA — Sardinian Aging Biomarkers Analysis',
    'hero.subtitle': "A next-generation biobank for longevity research. SABA collects continuous wearable data, validated questionnaires, and biological samples from Sardinia's Blue Zone — building on two decades of super ager research to understand what determines extreme longevity at a resolution never achieved before.",
    'hero.funding': 'Part of e.INS Spoke 01: A New Route to Preventive Medicine | Funded by NextGenerationEU',

    // Study at a Glance
    'glance.title': 'Study at a Glance',
    'glance.participants': 'Participants Enrolled',
    'glance.participantsTarget': 'Target: {target} by end of {year}',
    'glance.wearableHours': 'Wearable Hours',
    'glance.wearableHoursSubtitle': 'Hours of continuous health monitoring',
    'glance.superAgers': 'Super Agers',
    'glance.superAgersSubtitle': 'Participants 60+ showing younger biological markers',
    'glance.infrastructure': 'Infrastructure Built',
    'glance.infrastructureSubtitle': 'Recruitment operations live since September 2025',
    'glance.lastUpdated': 'Last updated',
    'glance.liveSync': 'LIVE SYNC',

    // Why Sardinia
    'whySardinia.title': 'Why Sardinia?',
    'whySardinia.p1': "Sardinia's Blue Zone has the highest documented concentration of super agers in the world. Since 2001, over 10,000 individuals have been tracked here — but never with continuous digital monitoring.",
    'whySardinia.p2': "SABA changes that. Launched in September 2025, we capture real-time physiological data alongside validated measures of stress, social connection, and purpose — the factors epidemiologists have long suspected drive longevity but never quantified at this resolution.",
    'whySardinia.objective': "Our objective: decode what determines extreme longevity at the micro level, then apply those insights globally through Nuraxi's World Model for human health.",
    'whySardinia.blueZone': 'Blue Zone Definition:',
    'whySardinia.blueZoneDesc': 'Regions identified by demographers as having the highest concentration of people living to 100+ years, first discovered in Sardinia by Gianni Pes and Michel Poulain.',

    // What We're Building
    'building.title': "What We're Building",
    'building.p1': "SABA is not a traditional observational study — it's a next-generation biobank designed for AI training.",
    'building.p2': "Every data point collected feeds into the SHAPE Clock, our framework for estimating biological age from non-invasive inputs. SABA's high-resolution Sardinian data serves as ground truth, validated against the world's most documented longevity population.",
    'building.p3': "The insights extracted here — on social connection, circadian health, stress resilience, and purpose — become transferable to populations worldwide through Nuraxi's federated health AI, trained on 50+ million longitudinal patient records.",
    'building.tagline': 'Sardinia teaches. The world learns.',

    // Key Findings
    'findings.title': 'Key Findings',
    'findings.intro': 'Quantifying What Has Never Been Measured',
    'findings.introDesc': 'For the first time, we are systematically capturing the factors behind extreme longevity: social interaction frequency, sense of purpose, and psychosocial resilience — translated into computable biomarkers actionable at the individual level.',
    'findings.moreSteps': 'more daily steps',
    'findings.stepsComparison': 'Sardinian cohort averages {steps} steps/day vs 6,500 US average',
    'findings.lonelinessImpact': 'loneliness impacts heart health',
    'findings.lonelinessDesc': 'Higher loneliness correlates with elevated resting heart rate',
    'findings.lowLoneliness': 'Low loneliness',
    'findings.highLoneliness': 'High loneliness',
    'findings.stressDifference': 'difference across stress levels',
    'findings.stressDesc': 'Stress directly measurable in cardiovascular markers',
    'findings.statSignificant': 'statistically significant',

    // Data Collection
    'dataCollection.title': 'How We Collect Data',
    'dataCollection.intro': 'Multi-modal data capture designed for World Model training:',
    'dataCollection.wearables': 'Wearables',
    'dataCollection.wearablesDesc': 'Heart rate, HRV, sleep architecture, daily activity',
    'dataCollection.biological': 'Biological Samples',
    'dataCollection.biologicalDesc': 'Nuraxi blood panel for longevity biomarkers',
    'dataCollection.scales': 'Validated Scales',
    'dataCollection.scalesDesc': 'Stress (PSS-10), Loneliness (UCLA), Chronotype (rMEQ)',
    'dataCollection.health': 'Health Perception',
    'dataCollection.healthDesc': 'Self-rated health status',
    'dataCollection.social': 'Social Clocks',
    'dataCollection.socialDesc': 'Interaction frequency and relationship quality',

    // CTA Cards
    'cta.scienceTitle': 'SHAPE Clock Methodology',
    'cta.scienceDesc': 'How we estimate biological age from non-invasive inputs — and what Sardinian super agers reveal about healthy aging trajectories.',
    'cta.researchTitle': 'Collaborate With Us',
    'cta.researchDesc': 'Request data access or explore partnership opportunities for institutional and commercial research.',

    // Footer
    'footer.mainText': 'SABA is an industrial research project funded by the European Union through NextGenerationEU, under the PNRR Ecosystem of Innovation e.INS — Spoke 01: A New Route to Preventive Medicine (CUP: J83C21000320007).',
    'footer.spokeLeader': 'Spoke Leader: Università degli Studi di Sassari',
    'footer.infrastructure': 'Research infrastructure developed by Nuraxi',

    // Science Page
    'science.shapeTitle': 'Introducing the SHAPE Clock',
    'science.shapeFull': 'Strategies for Healthy And Prolonged Existence',
    'science.shapeDesc': 'Traditional biological age clocks require expensive lab tests. SHAPE estimates biological age using only non-invasive inputs: wearable data (HRV, sleep, activity), validated questionnaires (stress, social connection, chronotype), and basic health assessments. This makes continuous, scalable biological age tracking possible for the first time.',
    'science.whatMeasures': 'What SHAPE Measures',
    'science.cardioFitness': 'Cardiovascular fitness',
    'science.cardioDesc': 'via resting HR and HRV patterns',
    'science.circadian': 'Circadian health',
    'science.circadianDesc': 'via sleep quality and chronotype',
    'science.psychosocial': 'Psychosocial wellbeing',
    'science.psychosocialDesc': 'via stress and loneliness scores',
    'science.activity': 'Activity patterns',
    'science.activityDesc': 'via daily step counts and movement',
    'science.bioVsChrono': 'Biological Age vs Chronological Age',
    'science.regularParticipants': 'Regular participants',
    'science.superAgersLegend': 'Super Agers (60+ with younger bio markers)',
    'science.scatterDesc': 'Points below the diagonal line indicate biological age younger than chronological age. Super agers show biological markers 5-15 years younger than their chronological age.',
    'science.participants60plus': 'participants aged 60+ in our cohort',
    'science.yearsYounger': '5-15 years',
    'science.youngerMarkers': 'younger biological markers in super agers',
    'science.validatedCorrelations': 'Validated Correlations',
    'science.correlationsDesc': 'Preliminary analysis reveals statistically significant relationships between lifestyle factors and cardiovascular health markers.',
    'science.finding1Title': 'Finding 1: Activity → Cardiovascular Fitness',
    'science.finding1Conclusion': 'Higher daily activity directly correlates with improved cardiovascular fitness.',
    'science.finding2Title': 'Finding 2: Social Connection → Heart Health',
    'science.finding2Conclusion': 'Social isolation has measurable physiological impact independent of physical activity.',
    'science.finding3Title': 'Finding 3: Stress → Cardiovascular Markers',
    'science.finding3Conclusion': 'Stress levels directly reflected in resting heart rate elevation.',
    'science.finding4Title': 'Finding 4: The Psychosocial Triad',
    'science.stressLoneliness': 'Stress ↔ Loneliness',
    'science.stressHealth': 'Stress ↔ Self-Rated Health',
    'science.lonelinessHealth': 'Loneliness ↔ Self-Rated Health',
    'science.strong': 'strong',
    'science.finding4Conclusion': 'These three factors form an interconnected system — interventions must address all three.',
    'science.cohortUnique': 'What Makes This Cohort Unique',
    'science.cohortConclusion': "The Sardinian cohort demonstrates significantly higher baseline activity levels, potentially contributing to the region's longevity characteristics.",
    'science.ipTitle': 'IP & Future Direction',
    'science.ipIntro': "SABA is not just an observational study. It's an infrastructure for collecting, analyzing, and commercializing longevity data. Key outputs include:",
    'science.ctaPublic': 'Public Dashboard',
    'science.ctaPublicDesc': 'View the study overview and key findings for general audiences',
    'science.ctaResearch': 'Researcher Portal',
    'science.ctaResearchDesc': 'Request data access and explore collaboration opportunities',

    // Research Page
    'research.title': 'Collaborate With Us',
    'research.intro': "SABA welcomes collaboration from academic researchers and institutional partners. Our dataset includes wearable biometrics, validated psychological assessments, and lifestyle data from Sardinia's Blue Zone population.",
    'research.dataAvailable': 'Data Available',
    'research.login': 'Existing Researchers — Login',
    'research.requestAccess': 'Request Access',
    'research.email': 'Email',
    'research.password': 'Password',
    'research.name': 'Name',
    'research.institution': 'Institution',
    'research.interest': 'Research Interest',
    'research.loginBtn': 'Log In',
    'research.submitBtn': 'Submit Inquiry',
    'research.forgotPassword': 'Forgot password?',
    'research.loginNote': 'Login is for approved researchers only.',
    'research.requestNote': 'Applications reviewed within 2 weeks. Priority given to academic collaborations with clear scientific objectives.',
    'research.ctaPublic': 'Public Dashboard',
    'research.ctaPublicDesc': 'View the study overview and key findings',
    'research.ctaScience': 'Scientific Showcase',
    'research.ctaScienceDesc': 'Explore methodology and validated findings',
  },
  it: {
    // Navigation
    'nav.public': 'Pubblico',
    'nav.science': 'Scienza',
    'nav.research': 'Ricerca',
    'nav.sabaStudy': 'Studio SABA',

    // Hero
    'hero.title': 'SABA — Sardinian Aging Biomarkers Analysis',
    'hero.subtitle': "Una biobanca di nuova generazione per la ricerca sulla longevità. SABA raccoglie dati continui da dispositivi indossabili, questionari validati e campioni biologici dalla Zona Blu della Sardegna — basandosi su due decenni di ricerca sui super agers per comprendere cosa determina la longevità estrema con una risoluzione mai raggiunta prima.",
    'hero.funding': "Parte di e.INS Spoke 01: Una Nuova Via per la Medicina Preventiva | Finanziato da NextGenerationEU",

    // Study at a Glance
    'glance.title': 'Lo Studio in Sintesi',
    'glance.participants': 'Partecipanti Iscritti',
    'glance.participantsTarget': 'Obiettivo: {target} entro fine {year}',
    'glance.wearableHours': 'Ore di Monitoraggio',
    'glance.wearableHoursSubtitle': 'Ore di monitoraggio continuo della salute',
    'glance.superAgers': 'Super Agers',
    'glance.superAgersSubtitle': 'Partecipanti 60+ con marcatori biologici più giovani',
    'glance.infrastructure': 'Infrastruttura Costruita',
    'glance.infrastructureSubtitle': 'Operazioni di reclutamento attive da settembre 2025',
    'glance.lastUpdated': 'Ultimo aggiornamento',
    'glance.liveSync': 'SYNC LIVE',

    // Why Sardinia
    'whySardinia.title': 'Perché la Sardegna?',
    'whySardinia.p1': "La Zona Blu della Sardegna ha la più alta concentrazione documentata di super agers al mondo. Dal 2001, oltre 10.000 individui sono stati monitorati qui — ma mai con un monitoraggio digitale continuo.",
    'whySardinia.p2': "SABA cambia tutto questo. Lanciato a settembre 2025, catturiamo dati fisiologici in tempo reale insieme a misure validate di stress, connessione sociale e scopo — i fattori che gli epidemiologi hanno a lungo sospettato guidare la longevità ma mai quantificato a questa risoluzione.",
    'whySardinia.objective': "Il nostro obiettivo: decodificare cosa determina la longevità estrema a livello micro, poi applicare queste intuizioni globalmente attraverso il World Model di Nuraxi per la salute umana.",
    'whySardinia.blueZone': 'Definizione di Zona Blu:',
    'whySardinia.blueZoneDesc': 'Regioni identificate dai demografi come aventi la più alta concentrazione di persone che vivono fino a 100+ anni, scoperta per la prima volta in Sardegna da Gianni Pes e Michel Poulain.',

    // What We're Building
    'building.title': 'Cosa Stiamo Costruendo',
    'building.p1': "SABA non è uno studio osservazionale tradizionale — è una biobanca di nuova generazione progettata per l'addestramento dell'IA.",
    'building.p2': "Ogni dato raccolto alimenta lo SHAPE Clock, il nostro framework per stimare l'età biologica da input non invasivi. I dati sardi ad alta risoluzione di SABA servono come verità di base, validati contro la popolazione di longevità più documentata al mondo.",
    'building.p3': "Le intuizioni estratte qui — sulla connessione sociale, la salute circadiana, la resilienza allo stress e lo scopo — diventano trasferibili alle popolazioni di tutto il mondo attraverso l'IA sanitaria federata di Nuraxi, addestrata su oltre 50 milioni di record longitudinali di pazienti.",
    'building.tagline': 'La Sardegna insegna. Il mondo impara.',

    // Key Findings
    'findings.title': 'Risultati Chiave',
    'findings.intro': 'Quantificare Ciò Che Non È Mai Stato Misurato',
    'findings.introDesc': "Per la prima volta, stiamo catturando sistematicamente i fattori dietro la longevità estrema: frequenza di interazione sociale, senso di scopo e resilienza psicosociale — tradotti in biomarcatori computabili e azionabili a livello individuale.",
    'findings.moreSteps': 'passi giornalieri in più',
    'findings.stepsComparison': 'La coorte sarda registra in media {steps} passi/giorno vs 6.500 media USA',
    'findings.lonelinessImpact': 'la solitudine impatta la salute del cuore',
    'findings.lonelinessDesc': 'Una maggiore solitudine è correlata a una frequenza cardiaca a riposo elevata',
    'findings.lowLoneliness': 'Bassa solitudine',
    'findings.highLoneliness': 'Alta solitudine',
    'findings.stressDifference': 'differenza tra i livelli di stress',
    'findings.stressDesc': 'Lo stress è direttamente misurabile nei marcatori cardiovascolari',
    'findings.statSignificant': 'statisticamente significativo',

    // Data Collection
    'dataCollection.title': 'Come Raccogliamo i Dati',
    'dataCollection.intro': 'Acquisizione dati multimodale progettata per il training del World Model:',
    'dataCollection.wearables': 'Dispositivi Indossabili',
    'dataCollection.wearablesDesc': 'Frequenza cardiaca, HRV, architettura del sonno, attività quotidiana',
    'dataCollection.biological': 'Campioni Biologici',
    'dataCollection.biologicalDesc': 'Pannello ematico Nuraxi per biomarcatori di longevità',
    'dataCollection.scales': 'Scale Validate',
    'dataCollection.scalesDesc': 'Stress (PSS-10), Solitudine (UCLA), Cronotipo (rMEQ)',
    'dataCollection.health': 'Percezione della Salute',
    'dataCollection.healthDesc': 'Stato di salute auto-riferito',
    'dataCollection.social': 'Orologi Sociali',
    'dataCollection.socialDesc': 'Frequenza di interazione e qualità delle relazioni',

    // CTA Cards
    'cta.scienceTitle': 'Metodologia SHAPE Clock',
    'cta.scienceDesc': "Come stimiamo l'età biologica da input non invasivi — e cosa rivelano i super agers sardi sulle traiettorie di invecchiamento sano.",
    'cta.researchTitle': 'Collabora Con Noi',
    'cta.researchDesc': "Richiedi l'accesso ai dati o esplora opportunità di partnership per la ricerca istituzionale e commerciale.",

    // Footer
    'footer.mainText': "SABA è un progetto di ricerca industriale finanziato dall'Unione Europea attraverso NextGenerationEU, nell'ambito dell'Ecosistema di Innovazione PNRR e.INS — Spoke 01: Una Nuova Via per la Medicina Preventiva (CUP: J83C21000320007).",
    'footer.spokeLeader': 'Spoke Leader: Università degli Studi di Sassari',
    'footer.infrastructure': 'Infrastruttura di ricerca sviluppata da Nuraxi',

    // Science Page
    'science.shapeTitle': 'Introduzione allo SHAPE Clock',
    'science.shapeFull': 'Strategies for Healthy And Prolonged Existence',
    'science.shapeDesc': "Gli orologi tradizionali dell'età biologica richiedono costosi test di laboratorio. SHAPE stima l'età biologica usando solo input non invasivi: dati da dispositivi indossabili (HRV, sonno, attività), questionari validati (stress, connessione sociale, cronotipo) e valutazioni sanitarie di base. Questo rende possibile per la prima volta un tracciamento continuo e scalabile dell'età biologica.",
    'science.whatMeasures': 'Cosa Misura SHAPE',
    'science.cardioFitness': 'Fitness cardiovascolare',
    'science.cardioDesc': 'tramite FC a riposo e pattern HRV',
    'science.circadian': 'Salute circadiana',
    'science.circadianDesc': 'tramite qualità del sonno e cronotipo',
    'science.psychosocial': 'Benessere psicosociale',
    'science.psychosocialDesc': 'tramite punteggi di stress e solitudine',
    'science.activity': 'Pattern di attività',
    'science.activityDesc': 'tramite conteggio passi e movimento quotidiano',
    'science.bioVsChrono': 'Età Biologica vs Età Cronologica',
    'science.regularParticipants': 'Partecipanti regolari',
    'science.superAgersLegend': 'Super Agers (60+ con marcatori biologici più giovani)',
    'science.scatterDesc': "I punti sotto la linea diagonale indicano un'età biologica inferiore a quella cronologica. I super agers mostrano marcatori biologici 5-15 anni più giovani della loro età cronologica.",
    'science.participants60plus': 'partecipanti di 60+ anni nella nostra coorte',
    'science.yearsYounger': '5-15 anni',
    'science.youngerMarkers': 'marcatori biologici più giovani nei super agers',
    'science.validatedCorrelations': 'Correlazioni Validate',
    'science.correlationsDesc': "L'analisi preliminare rivela relazioni statisticamente significative tra fattori dello stile di vita e marcatori di salute cardiovascolare.",
    'science.finding1Title': 'Risultato 1: Attività → Fitness Cardiovascolare',
    'science.finding1Conclusion': "Una maggiore attività quotidiana correla direttamente con un miglior fitness cardiovascolare.",
    'science.finding2Title': 'Risultato 2: Connessione Sociale → Salute del Cuore',
    'science.finding2Conclusion': "L'isolamento sociale ha un impatto fisiologico misurabile indipendente dall'attività fisica.",
    'science.finding3Title': 'Risultato 3: Stress → Marcatori Cardiovascolari',
    'science.finding3Conclusion': "I livelli di stress si riflettono direttamente nell'elevazione della frequenza cardiaca a riposo.",
    'science.finding4Title': 'Risultato 4: La Triade Psicosociale',
    'science.stressLoneliness': 'Stress ↔ Solitudine',
    'science.stressHealth': 'Stress ↔ Salute Auto-Riferita',
    'science.lonelinessHealth': 'Solitudine ↔ Salute Auto-Riferita',
    'science.strong': 'forte',
    'science.finding4Conclusion': 'Questi tre fattori formano un sistema interconnesso — gli interventi devono affrontarli tutti e tre.',
    'science.cohortUnique': 'Cosa Rende Unica Questa Coorte',
    'science.cohortConclusion': 'La coorte sarda dimostra livelli di attività basale significativamente più elevati, contribuendo potenzialmente alle caratteristiche di longevità della regione.',
    'science.ipTitle': 'IP & Direzione Futura',
    'science.ipIntro': "SABA non è solo uno studio osservazionale. È un'infrastruttura per raccogliere, analizzare e commercializzare dati sulla longevità. I risultati chiave includono:",
    'science.ctaPublic': 'Dashboard Pubblica',
    'science.ctaPublicDesc': 'Visualizza la panoramica dello studio e i risultati chiave per il pubblico generale',
    'science.ctaResearch': 'Portale Ricercatori',
    'science.ctaResearchDesc': "Richiedi l'accesso ai dati ed esplora opportunità di collaborazione",

    // Research Page
    'research.title': 'Collabora Con Noi',
    'research.intro': "SABA accoglie collaborazioni da ricercatori accademici e partner istituzionali. Il nostro dataset include biometria da dispositivi indossabili, valutazioni psicologiche validate e dati sullo stile di vita dalla popolazione della Zona Blu della Sardegna.",
    'research.dataAvailable': 'Dati Disponibili',
    'research.login': 'Ricercatori Esistenti — Accedi',
    'research.requestAccess': 'Richiedi Accesso',
    'research.email': 'Email',
    'research.password': 'Password',
    'research.name': 'Nome',
    'research.institution': 'Istituzione',
    'research.interest': 'Interesse di Ricerca',
    'research.loginBtn': 'Accedi',
    'research.submitBtn': 'Invia Richiesta',
    'research.forgotPassword': 'Password dimenticata?',
    'research.loginNote': "L'accesso è riservato ai ricercatori approvati.",
    'research.requestNote': 'Le candidature vengono esaminate entro 2 settimane. Priorità data alle collaborazioni accademiche con obiettivi scientifici chiari.',
    'research.ctaPublic': 'Dashboard Pubblica',
    'research.ctaPublicDesc': 'Visualizza la panoramica dello studio e i risultati chiave',
    'research.ctaScience': 'Showcase Scientifico',
    'research.ctaScienceDesc': 'Esplora la metodologia e i risultati validati',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  const t = (key: string): string => {
    return translations[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
