// SABA Study - Mock Data
// Placeholder data for the Sardinian Blue Zone Longevity Study dashboards

import type {
  StudyStats,
  EnrollmentMilestone,
  EnrollmentTrend,
  CommuneData,
  AggregateFinding,
  DemographicBreakdown,
  ShapeClockResult,
  ShapeValidationMetric,
  SuperAgerProfile,
  CohortComparison,
  WearableValidation,
  PopulationNorm,
  AccessTierInfo,
  DataCatalogEntry,
  DataCategory,
  ResearchProject,
  Publication,
  TeamMember,
  AdvisoryBoardMember,
  LifestyleFactor,
  DietaryPattern,
} from './types';

// =============================================================================
// STUDY STATISTICS
// =============================================================================

export const studyStats: StudyStats = {
  totalParticipants: 2840,
  centenarianParticipants: 47,
  superAgerParticipants: 312,
  totalWearableDays: 847520,
  questionnairesCompleted: 2680,
  biomarkerSamplesAnalyzed: 8420,
  lastUpdated: '2025-12-30T08:00:00Z',
};

export const enrollmentMilestones: EnrollmentMilestone[] = [
  { date: '2023-06-15', label: 'Study Launch', count: 0, type: 'milestone' },
  { date: '2023-08-22', label: 'First Centenarian Enrolled', count: 156, type: 'centenarian' },
  { date: '2023-11-10', label: '500 Participants', count: 500, type: 'milestone' },
  { date: '2024-02-28', label: '1,000 Participants', count: 1000, type: 'milestone' },
  { date: '2024-06-15', label: '10th Centenarian', count: 1456, type: 'centenarian' },
  { date: '2024-08-20', label: '2,000 Participants', count: 2000, type: 'milestone' },
  { date: '2024-11-05', label: '25th Centenarian', count: 2320, type: 'centenarian' },
  { date: '2025-03-12', label: 'SHAPE Clock v1.0 Release', count: 2580, type: 'milestone' },
  { date: '2025-12-30', label: 'Current', count: 2840, type: 'enrollment' },
];

export const enrollmentTrends: EnrollmentTrend[] = generateEnrollmentTrends();

function generateEnrollmentTrends(): EnrollmentTrend[] {
  const trends: EnrollmentTrend[] = [];
  const startDate = new Date('2023-06-01');
  const endDate = new Date('2025-12-30');
  let cumulative = 0;

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 7)) {
    // Simulate varying enrollment rates
    const weeklyBase = 25 + Math.sin(d.getTime() / 10000000000) * 10;
    const weekly = Math.max(5, Math.round(weeklyBase + Math.random() * 15));
    cumulative += weekly;

    trends.push({
      date: d.toISOString().split('T')[0],
      cumulative: Math.min(cumulative, 2840),
      weekly,
    });
  }

  return trends;
}

// =============================================================================
// GEOGRAPHIC DATA - Sardinian Communes (Real coordinates from SABA study)
// =============================================================================

export const communeData: CommuneData[] = [
  // Traditional Blue Zone (Ogliastra & Barbagia regions)
  { name: 'Oliena', province: 'Nuoro', isBlueZone: true, enrollmentCount: 185, coordinates: { lat: 40.2763, lng: 9.4021 }, centenarianRate: 31 },
  { name: 'Villagrande Strisaili', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 168, coordinates: { lat: 39.9833, lng: 9.5167 }, centenarianRate: 42 },
  { name: 'Arzana', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 156, coordinates: { lat: 39.9167, lng: 9.5333 }, centenarianRate: 38 },
  { name: 'Talana', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 112, coordinates: { lat: 40.0333, lng: 9.4833 }, centenarianRate: 45 },
  { name: 'Baunei', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 134, coordinates: { lat: 40.0333, lng: 9.6667 }, centenarianRate: 35 },
  { name: 'Urzulei', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 98, coordinates: { lat: 40.1000, lng: 9.5000 }, centenarianRate: 41 },
  { name: 'Seulo', province: 'Sud Sardegna', isBlueZone: true, enrollmentCount: 76, coordinates: { lat: 39.8667, lng: 9.2333 }, centenarianRate: 52 },
  { name: 'Perdasdefogu', province: 'Ogliastra', isBlueZone: true, enrollmentCount: 94, coordinates: { lat: 39.6833, lng: 9.4333 }, centenarianRate: 36 },
  { name: 'Orgosolo', province: 'Nuoro', isBlueZone: true, enrollmentCount: 192, coordinates: { lat: 40.2000, lng: 9.3500 }, centenarianRate: 28 },
  { name: 'Fonni', province: 'Nuoro', isBlueZone: true, enrollmentCount: 148, coordinates: { lat: 40.1167, lng: 9.2500 }, centenarianRate: 33 },

  // Major urban centers (AVIS Sardegna recruitment sites)
  { name: 'Cagliari', province: 'Cagliari', isBlueZone: false, enrollmentCount: 425, coordinates: { lat: 39.2238, lng: 9.1217 }, centenarianRate: 12 },
  { name: 'Quartu Sant\'Elena', province: 'Cagliari', isBlueZone: false, enrollmentCount: 186, coordinates: { lat: 39.2414, lng: 9.1836 }, centenarianRate: 11 },
  { name: 'Sassari', province: 'Sassari', isBlueZone: false, enrollmentCount: 278, coordinates: { lat: 40.7259, lng: 8.5594 }, centenarianRate: 14 },
  { name: 'Olbia', province: 'Sassari', isBlueZone: false, enrollmentCount: 156, coordinates: { lat: 40.9236, lng: 9.4964 }, centenarianRate: 11 },
  { name: 'Alghero', province: 'Sassari', isBlueZone: false, enrollmentCount: 134, coordinates: { lat: 40.5583, lng: 8.3191 }, centenarianRate: 13 },
  { name: 'Oristano', province: 'Oristano', isBlueZone: false, enrollmentCount: 168, coordinates: { lat: 39.9061, lng: 8.5884 }, centenarianRate: 15 },

  // Additional Sardinian towns from SABA recruitment
  { name: 'Sanluri', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 78, coordinates: { lat: 39.5630, lng: 8.8998 }, centenarianRate: 16 },
  { name: 'Carbonia', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 92, coordinates: { lat: 39.1644, lng: 8.5229 }, centenarianRate: 14 },
  { name: 'Iglesias', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 86, coordinates: { lat: 39.3127, lng: 8.5360 }, centenarianRate: 15 },
  { name: 'Guspini', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 64, coordinates: { lat: 39.5393, lng: 8.6273 }, centenarianRate: 17 },
  { name: 'Villacidro', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 72, coordinates: { lat: 39.4584, lng: 8.7394 }, centenarianRate: 16 },
  { name: 'San Gavino Monreale', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 58, coordinates: { lat: 39.5497, lng: 8.7913 }, centenarianRate: 15 },
  { name: 'Muravera', province: 'Sud Sardegna', isBlueZone: false, enrollmentCount: 48, coordinates: { lat: 39.4208, lng: 9.5757 }, centenarianRate: 18 },
  { name: 'Sinnai', province: 'Cagliari', isBlueZone: false, enrollmentCount: 82, coordinates: { lat: 39.3014, lng: 9.2025 }, centenarianRate: 13 },
  { name: 'Selargius', province: 'Cagliari', isBlueZone: false, enrollmentCount: 94, coordinates: { lat: 39.2598, lng: 9.1628 }, centenarianRate: 12 },
  { name: 'Capoterra', province: 'Cagliari', isBlueZone: false, enrollmentCount: 68, coordinates: { lat: 39.1789, lng: 8.9710 }, centenarianRate: 11 },
];

// =============================================================================
// AGGREGATE FINDINGS
// =============================================================================

export const aggregateFindings: AggregateFinding[] = [
  {
    id: 'finding-001',
    title: 'Blue Zone HRV Advantage',
    description: 'Participants from traditional Blue Zone communes show significantly higher heart rate variability compared to age-matched controls from urban areas.',
    metric: '23% higher RMSSD',
    comparisonGroup: 'Age-matched urban Sardinians',
    significance: 'validated',
    publishedDate: '2025-06-15',
    category: 'biomarker',
  },
  {
    id: 'finding-002',
    title: 'Mediterranean Diet & Biological Age',
    description: 'High adherence to traditional Sardinian Mediterranean diet correlates with younger biological age as measured by SHAPE Clock.',
    metric: '4.2 years younger biological age',
    comparisonGroup: 'Low diet adherence group',
    significance: 'significant',
    publishedDate: '2025-08-22',
    category: 'dietary',
  },
  {
    id: 'finding-003',
    title: 'Sleep Regularity in Centenarians',
    description: 'Centenarian participants maintain remarkably consistent sleep-wake cycles with minimal variability across seasons.',
    metric: '92% sleep efficiency',
    comparisonGroup: 'Population average (78%)',
    significance: 'validated',
    publishedDate: '2025-04-10',
    category: 'circadian',
  },
  {
    id: 'finding-004',
    title: 'Social Integration Effect',
    description: 'Strong multigenerational family ties and daily social interactions correlate with improved biomarkers of aging.',
    metric: '2.8 years younger',
    comparisonGroup: 'Low social integration cohort',
    significance: 'significant',
    publishedDate: '2025-09-05',
    category: 'social',
  },
  {
    id: 'finding-005',
    title: 'Natural Activity Patterns',
    description: 'Traditional occupational activities (shepherding, farming) maintain cardiovascular fitness without structured exercise.',
    metric: '8,400 daily steps average (80+ cohort)',
    comparisonGroup: 'General population 80+ (3,200 steps)',
    significance: 'validated',
    publishedDate: '2025-07-18',
    category: 'lifestyle',
  },
];

export const demographicBreakdown: DemographicBreakdown[] = [
  { ageRange: '18-29', maleCount: 80, femaleCount: 100, percentageOfTotal: 6.3 },
  { ageRange: '30-39', maleCount: 120, femaleCount: 140, percentageOfTotal: 9.2 },
  { ageRange: '40-49', maleCount: 160, femaleCount: 180, percentageOfTotal: 12.0 },
  { ageRange: '50-59', maleCount: 200, femaleCount: 220, percentageOfTotal: 14.8 },
  { ageRange: '60-69', maleCount: 280, femaleCount: 300, percentageOfTotal: 20.4 },
  { ageRange: '70-79', maleCount: 260, femaleCount: 300, percentageOfTotal: 19.7 },
  { ageRange: '80-89', maleCount: 140, femaleCount: 180, percentageOfTotal: 11.3 },
  { ageRange: '90-99', maleCount: 60, femaleCount: 80, percentageOfTotal: 4.9 },
  { ageRange: '100+', maleCount: 20, femaleCount: 40, percentageOfTotal: 2.1 },
];

// =============================================================================
// SHAPE CLOCK DATA
// =============================================================================

export const sampleShapeResult: ShapeClockResult = {
  compositeAge: 58.3,
  chronologicalAge: 65,
  ageDifference: -6.7,
  confidenceInterval: { lower: 56.1, upper: 60.5 },
  interpretation: 'younger',
  contributingFactors: [
    { name: 'Circadian Rhythm Stability', category: 'circadian', contribution: -2.1, status: 'optimal', percentile: 85 },
    { name: 'Heart Rate Variability', category: 'hrv', contribution: -1.8, status: 'optimal', percentile: 78 },
    { name: 'Sleep Quality', category: 'sleep', contribution: -1.4, status: 'optimal', percentile: 72 },
    { name: 'Physical Activity', category: 'activity', contribution: -0.9, status: 'moderate', percentile: 65 },
    { name: 'Lifestyle Questionnaire', category: 'questionnaire', contribution: -0.5, status: 'moderate', percentile: 58 },
  ],
};

export const shapeValidationMetrics: ShapeValidationMetric[] = [
  {
    clockName: 'SHAPE Clock v1.0',
    correlation: 0.91,
    meanAbsoluteError: 3.8,
    sampleSize: 2340,
    validationCohort: 'SABA Sardinian Cohort',
  },
  {
    clockName: 'SHAPE Clock v1.0',
    correlation: 0.87,
    meanAbsoluteError: 4.2,
    sampleSize: 1560,
    validationCohort: 'External Italian Cohort',
    comparisonToClock: { name: 'PhenoAge', relativePredictivePower: 0.94 },
  },
  {
    clockName: 'SHAPE Clock v1.0',
    correlation: 0.84,
    meanAbsoluteError: 4.6,
    sampleSize: 890,
    validationCohort: 'European Aging Study',
    comparisonToClock: { name: 'GrimAge', relativePredictivePower: 0.89 },
  },
];

export const clockComparisonData = generateClockComparisonScatter();

function generateClockComparisonScatter() {
  const data = [];
  for (let i = 0; i < 150; i++) {
    const chronAge = 30 + Math.random() * 70;
    const noise = (Math.random() - 0.5) * 12;
    const bioAge = chronAge + noise - (chronAge > 70 ? 3 : 0); // Blue Zone effect for older participants
    data.push({
      chronologicalAge: Math.round(chronAge * 10) / 10,
      biologicalAge: Math.round(bioAge * 10) / 10,
      cohort: chronAge > 60 && Math.random() > 0.6 ? 'Blue Zone' : 'Comparison',
    });
  }
  return data;
}

// =============================================================================
// SUPER-AGER DATA
// =============================================================================

export const superAgerProfiles: SuperAgerProfile[] = [
  {
    id: 'SA-001',
    ageRange: '100-104',
    biologicalAgeGap: -12.4,
    keyCharacteristics: ['Active shepherd until age 92', 'Daily wine consumption (cannonau)', 'Strong family bonds'],
    hrv: { rmssd: 32, percentileVsAgeMatched: 95 },
    sleepEfficiency: 88,
    activityLevel: 'moderate',
    dietaryPattern: 'Traditional Sardinian Mediterranean',
  },
  {
    id: 'SA-002',
    ageRange: '95-99',
    biologicalAgeGap: -8.7,
    keyCharacteristics: ['Daily walking 5+ km', 'Vegetable gardening', 'Regular social gatherings'],
    hrv: { rmssd: 38, percentileVsAgeMatched: 92 },
    sleepEfficiency: 91,
    activityLevel: 'high',
    dietaryPattern: 'Traditional Sardinian Mediterranean',
  },
  {
    id: 'SA-003',
    ageRange: '85-89',
    biologicalAgeGap: -11.2,
    keyCharacteristics: ['Community elder role', 'Traditional food preparation', 'No chronic medications'],
    hrv: { rmssd: 45, percentileVsAgeMatched: 88 },
    sleepEfficiency: 94,
    activityLevel: 'very-high',
    dietaryPattern: 'Traditional Sardinian Mediterranean',
  },
];

export const cohortComparisons: CohortComparison[] = [
  { metric: 'Resting Heart Rate', unit: 'bpm', sabaBlueZone: { mean: 58, std: 8, n: 1240 }, generalPopulation: { mean: 72, std: 12, n: 5000 }, pValue: 0.001, percentDifference: -19.4 },
  { metric: 'HRV (RMSSD)', unit: 'ms', sabaBlueZone: { mean: 42, std: 15, n: 1240 }, generalPopulation: { mean: 34, std: 18, n: 5000 }, pValue: 0.001, percentDifference: 23.5 },
  { metric: 'Sleep Efficiency', unit: '%', sabaBlueZone: { mean: 89, std: 6, n: 1180 }, generalPopulation: { mean: 78, std: 12, n: 5000 }, pValue: 0.001, percentDifference: 14.1 },
  { metric: 'Daily Steps (70+)', unit: 'steps', sabaBlueZone: { mean: 7200, std: 2100, n: 680 }, generalPopulation: { mean: 4100, std: 2800, n: 3000 }, pValue: 0.001, percentDifference: 75.6 },
  { metric: 'Circadian Amplitude', unit: 'AU', sabaBlueZone: { mean: 0.82, std: 0.12, n: 1100 }, generalPopulation: { mean: 0.68, std: 0.18, n: 4500 }, pValue: 0.001, percentDifference: 20.6 },
  { metric: 'CRP Levels', unit: 'mg/L', sabaBlueZone: { mean: 1.2, std: 0.8, n: 980 }, generalPopulation: { mean: 2.8, std: 2.1, n: 4000 }, pValue: 0.001, percentDifference: -57.1 },
];

// =============================================================================
// WEARABLE VALIDATION
// =============================================================================

export const wearableValidations: WearableValidation[] = [
  { metric: 'Heart Rate', deviceType: 'Oura Ring Gen 3', goldStandard: 'ECG Holter', correlation: 0.996, blandAltmanBias: 0.8, limitsOfAgreement: { lower: -3.2, upper: 4.8 }, sampleSize: 420, publication: 'JMIR 2024' },
  { metric: 'HRV (RMSSD)', deviceType: 'Oura Ring Gen 3', goldStandard: 'ECG Analysis', correlation: 0.98, blandAltmanBias: 2.1, limitsOfAgreement: { lower: -8.5, upper: 12.7 }, sampleSize: 420, publication: 'Sensors 2024' },
  { metric: 'Sleep Stages', deviceType: 'Oura Ring Gen 3', goldStandard: 'Polysomnography', correlation: 0.89, blandAltmanBias: 12, limitsOfAgreement: { lower: -28, upper: 52 }, sampleSize: 180, publication: 'Sleep Medicine 2024' },
  { metric: 'Daily Steps', deviceType: 'Research Accelerometer', goldStandard: 'Manual Count', correlation: 0.994, blandAltmanBias: 45, limitsOfAgreement: { lower: -180, upper: 270 }, sampleSize: 95 },
];

export const populationNorms: PopulationNorm[] = [
  { metric: 'HRV (RMSSD)', ageRange: '60-69', sex: 'all', mean: 28, percentile5: 12, percentile25: 20, percentile50: 27, percentile75: 35, percentile95: 52, unit: 'ms' },
  { metric: 'HRV (RMSSD)', ageRange: '70-79', sex: 'all', mean: 24, percentile5: 10, percentile25: 17, percentile50: 23, percentile75: 30, percentile95: 45, unit: 'ms' },
  { metric: 'HRV (RMSSD)', ageRange: '80-89', sex: 'all', mean: 21, percentile5: 8, percentile25: 14, percentile50: 20, percentile75: 26, percentile95: 38, unit: 'ms' },
  { metric: 'HRV (RMSSD)', ageRange: '90+', sex: 'all', mean: 18, percentile5: 6, percentile25: 12, percentile50: 17, percentile75: 23, percentile95: 32, unit: 'ms' },
  { metric: 'Sleep Efficiency', ageRange: '60-69', sex: 'all', mean: 85, percentile5: 68, percentile25: 78, percentile50: 86, percentile75: 92, percentile95: 96, unit: '%' },
  { metric: 'Sleep Efficiency', ageRange: '70-79', sex: 'all', mean: 82, percentile5: 62, percentile25: 74, percentile50: 83, percentile75: 90, percentile95: 95, unit: '%' },
  { metric: 'Sleep Efficiency', ageRange: '80+', sex: 'all', mean: 78, percentile5: 55, percentile25: 68, percentile50: 79, percentile75: 88, percentile95: 94, unit: '%' },
];

// =============================================================================
// RESEARCHER ACCESS PORTAL
// =============================================================================

export const accessTiers: AccessTierInfo[] = [
  {
    tier: 'public',
    name: 'Public Access',
    description: 'Aggregate statistics, summary findings, and study protocols',
    requirements: ['None'],
    dataAccess: ['Aggregate statistics', 'Summary findings', 'Study protocols', 'Published manuscripts'],
    process: ['Browse publicly available content'],
    estimatedTimeline: 'Immediate',
    cost: 'Free',
  },
  {
    tier: 'registered',
    name: 'Registered Access',
    description: 'Detailed phenotype summaries and methodology documentation',
    requirements: ['Create account', 'Acknowledge data use terms', 'Academic or research affiliation'],
    dataAccess: ['Detailed phenotype summaries', 'Methodology documentation', 'Data dictionary', 'Summary statistics by subgroup'],
    process: ['Complete registration form', 'Verify email', 'Accept terms of use'],
    estimatedTimeline: '24-48 hours',
    cost: 'Free',
  },
  {
    tier: 'controlled',
    name: 'Controlled Access',
    description: 'Individual-level phenotypes and derived SHAPE metrics',
    requirements: ['Application with research proposal', 'Institutional affiliation', 'IRB approval (if applicable)', 'Data Access Committee review'],
    dataAccess: ['Individual-level phenotypes', 'Derived SHAPE Clock metrics', 'Wearable summary data', 'Questionnaire responses', 'Linked health outcomes'],
    process: ['Submit research proposal', 'DAC scientific review', 'Execute Data Use Agreement', 'Complete data security training'],
    estimatedTimeline: '4-8 weeks',
    cost: '€3,000',
  },
  {
    tier: 'collaborative',
    name: 'Collaborative Partnership',
    description: 'Full data access including raw wearable streams and biospecimen linkage',
    requirements: ['Formal collaboration proposal', 'Institutional sign-off', 'Material Transfer Agreement', 'Joint project development'],
    dataAccess: ['Raw wearable data streams', 'Biospecimen linkage', 'Genomic data (if applicable)', 'Priority access to new data releases', 'Co-authorship opportunities'],
    process: ['Submit collaboration proposal', 'Scientific review', 'Negotiate terms', 'Execute MTA and DUA', 'Joint project planning'],
    estimatedTimeline: '3-6 months',
    cost: 'Negotiated',
  },
];

// Data categories based on actual SABA study questionnaires (25 surveys, 528 questions)
export const dataCategories: DataCategory[] = [
  { id: 'demographics', name: 'Basic Information', description: 'Age, sex, location, socioeconomic factors (Informazioni di Base)', variableCount: 32, icon: 'Users' },
  { id: 'medical', name: 'Medical History', description: 'Personal & family medical history, screening, medications', variableCount: 52, icon: 'Heart' },
  { id: 'psychology', name: 'Psychological Wellbeing', description: 'Stress PSS-10, cognitive function, psychological wellbeing', variableCount: 111, icon: 'Brain' },
  { id: 'social', name: 'Social & Community', description: 'Social connection, loneliness, community involvement, spirituality', variableCount: 58, icon: 'Users' },
  { id: 'lifestyle', name: 'Lifestyle Factors', description: 'Physical activity WHO GPAQ, diet & nutrition, substance use', variableCount: 88, icon: 'Activity' },
  { id: 'circadian', name: 'Circadian & Sleep', description: 'Circadian rhythm rMEQ, daily inputs, sleep patterns', variableCount: 13, icon: 'Moon' },
  { id: 'wearables', name: 'Wearable Metrics', description: 'HRV, sleep stages, activity, circadian patterns from Oura', variableCount: 156, icon: 'Watch' },
  { id: 'personality', name: 'Personality & Traits', description: 'IPIP-NEO-30 personality, character strengths VIA, autonomy', variableCount: 54, icon: 'Sparkles' },
  { id: 'environment', name: 'Environmental Context', description: 'Environmental exposure, life context, digital fatigue', variableCount: 25, icon: 'MapPin' },
  { id: 'childhood', name: 'Early Life Factors', description: 'Early childhood factors, trauma, life structure', variableCount: 87, icon: 'Baby' },
  { id: 'derived', name: 'Derived Measures', description: 'SHAPE Clock, biological age, risk scores', variableCount: 45, icon: 'Calculator' },
  { id: 'biomarkers', name: 'Biomarkers', description: 'Blood chemistry, inflammation, metabolic markers', variableCount: 84, icon: 'Droplets' },
];

export const sampleDataCatalog: DataCatalogEntry[] = [
  { variableId: 'demo_age', variableName: 'Chronological Age', category: 'Demographics', description: 'Age at enrollment in years', dataType: 'continuous', sampleSize: 2840, completeness: 100, tier: 'registered', unit: 'years', valueRange: { min: 18, max: 108 } },
  { variableId: 'demo_sex', variableName: 'Biological Sex', category: 'Demographics', description: 'Biological sex at birth', dataType: 'categorical', sampleSize: 2840, completeness: 100, tier: 'registered', categories: ['Male', 'Female'] },
  { variableId: 'hrv_rmssd', variableName: 'HRV RMSSD', category: 'Wearables', description: 'Root mean square of successive RR interval differences', dataType: 'continuous', sampleSize: 2680, completeness: 94.4, tier: 'controlled', unit: 'ms', valueRange: { min: 4, max: 120 } },
  { variableId: 'sleep_eff', variableName: 'Sleep Efficiency', category: 'Wearables', description: 'Percentage of time in bed spent asleep', dataType: 'continuous', sampleSize: 2650, completeness: 93.3, tier: 'controlled', unit: '%', valueRange: { min: 45, max: 99 } },
  { variableId: 'shape_age', variableName: 'SHAPE Biological Age', category: 'Derived', description: 'Composite biological age from SHAPE Clock algorithm', dataType: 'continuous', sampleSize: 2340, completeness: 82.4, tier: 'controlled', unit: 'years', valueRange: { min: 22, max: 95 } },
  { variableId: 'diet_med', variableName: 'Mediterranean Diet Score', category: 'Questionnaires', description: '14-point Mediterranean diet adherence score', dataType: 'continuous', sampleSize: 2680, completeness: 94.4, tier: 'registered', unit: 'points', valueRange: { min: 0, max: 14 } },
];

export const activeResearchProjects: ResearchProject[] = [
  { id: 'proj-001', title: 'Circadian Rhythms in Sardinian Centenarians', institution: 'University of Cagliari', principalInvestigator: 'Dr. Maria Ferrara', status: 'active', tier: 'collaborative', startDate: '2024-09-01', publications: 1 },
  { id: 'proj-002', title: 'Mediterranean Diet and Epigenetic Aging', institution: 'Harvard T.H. Chan School', principalInvestigator: 'Prof. David Chen', status: 'active', tier: 'controlled', startDate: '2024-11-15' },
  { id: 'proj-003', title: 'Social Networks and Longevity Outcomes', institution: 'University of Rome', principalInvestigator: 'Dr. Alessandro Moretti', status: 'active', tier: 'controlled', startDate: '2025-02-01' },
  { id: 'proj-004', title: 'SHAPE Clock External Validation', institution: 'Karolinska Institutet', principalInvestigator: 'Prof. Anna Lindqvist', status: 'completed', tier: 'collaborative', startDate: '2024-06-01', publications: 2 },
  { id: 'proj-005', title: 'Wearable Biomarkers of Healthy Aging', institution: 'Stanford Prevention Research', principalInvestigator: 'Dr. Michael Snyder', status: 'pending', tier: 'collaborative', startDate: '2025-03-01' },
];

// =============================================================================
// PUBLICATIONS & TEAM
// =============================================================================

export const publications: Publication[] = [
  { id: 'pub-001', title: 'SHAPE Clock: A Non-Invasive Biological Age Estimator from Wearable Data', authors: 'SABA Study Consortium', journal: 'Nature Aging', year: 2025, doi: '10.1038/s43587-025-0001', category: 'methodology', impactFactor: 16.8, citations: 45 },
  { id: 'pub-002', title: 'Circadian Rhythm Patterns in the Sardinian Blue Zone', authors: 'Ferrara M, et al.', journal: 'Cell Reports Medicine', year: 2025, doi: '10.1016/j.xcrm.2025.001', category: 'findings', impactFactor: 14.3, citations: 28 },
  { id: 'pub-003', title: 'Validation of Consumer Wearables for Biological Age Assessment', authors: 'SABA Study Consortium', journal: 'JMIR mHealth and uHealth', year: 2024, doi: '10.2196/jmir.2024.54321', category: 'validation', impactFactor: 5.4, citations: 67 },
  { id: 'pub-004', title: 'The SABA Study Protocol: Methods and Baseline Characteristics', authors: 'SABA Study Consortium', journal: 'BMJ Open', year: 2024, doi: '10.1136/bmjopen-2024-001', category: 'methodology', impactFactor: 3.0, citations: 34 },
  { id: 'pub-005', title: 'Heart Rate Variability Correlates of Exceptional Longevity', authors: 'Chen D, Ferrara M, et al.', journal: 'Circulation Research', year: 2025, doi: '10.1161/CIRCRESAHA.125.001', category: 'findings', impactFactor: 20.1, citations: 12 },
];

export const teamMembers: TeamMember[] = [
  { name: 'Dr. Gianni Pes', role: 'Principal Investigator', affiliation: 'University of Sassari', expertise: ['Epidemiology', 'Blue Zone Research', 'Longevity'] },
  { name: 'Dr. Michel Poulain', role: 'Co-Principal Investigator', affiliation: 'Université catholique de Louvain', expertise: ['Demography', 'Longevity Validation', 'Population Studies'] },
  { name: 'Dr. Maria Ferrara', role: 'Scientific Director', affiliation: 'University of Cagliari', expertise: ['Circadian Biology', 'Sleep Medicine', 'Biomarkers'] },
  { name: 'Dr. Paolo Mura', role: 'Data Science Lead', affiliation: 'SABA Study', expertise: ['Machine Learning', 'Biological Clocks', 'Wearable Analytics'] },
  { name: 'Dr. Laura Manca', role: 'Clinical Director', affiliation: 'Hospital of Nuoro', expertise: ['Geriatric Medicine', 'Clinical Trials', 'Participant Care'] },
];

export const advisoryBoard: AdvisoryBoardMember[] = [
  { name: 'Prof. Steve Horvath', title: 'Professor of Human Genetics', affiliation: 'Altos Labs / UCLA', notableAchievements: ['Developer of Horvath Clock', 'Pioneer in epigenetic aging'] },
  { name: 'Prof. Morgan Levine', title: 'Founding Principal Investigator', affiliation: 'Altos Labs', notableAchievements: ['Developer of PhenoAge', 'Biological age methodology'] },
  { name: 'Prof. Dan Buettner', title: 'Blue Zones Founder', affiliation: 'Blue Zones LLC', notableAchievements: ['Identified original Blue Zones', 'National Geographic Fellow'] },
  { name: 'Prof. Nir Barzilai', title: 'Director, Institute for Aging Research', affiliation: 'Albert Einstein College of Medicine', notableAchievements: ['SuperAgers study', 'TAME trial PI'] },
];

// =============================================================================
// LIFESTYLE FACTORS
// =============================================================================

export const lifestyleFactors: LifestyleFactor[] = [
  { id: 'diet-med', name: 'Mediterranean Diet Adherence', category: 'diet', prevalenceInStudy: 78, associatedAgeEffect: -3.2, confidenceInterval: { lower: -4.1, upper: -2.3 }, description: 'High consumption of vegetables, legumes, olive oil; moderate wine' },
  { id: 'activity-natural', name: 'Natural Movement', category: 'physical', prevalenceInStudy: 65, associatedAgeEffect: -2.8, confidenceInterval: { lower: -3.5, upper: -2.1 }, description: 'Daily walking, gardening, shepherding instead of structured exercise' },
  { id: 'social-family', name: 'Multigenerational Family Ties', category: 'social', prevalenceInStudy: 82, associatedAgeEffect: -2.1, confidenceInterval: { lower: -2.9, upper: -1.3 }, description: 'Living with or near extended family, daily intergenerational contact' },
  { id: 'sleep-regular', name: 'Regular Sleep Schedule', category: 'sleep', prevalenceInStudy: 71, associatedAgeEffect: -1.8, confidenceInterval: { lower: -2.5, upper: -1.1 }, description: 'Consistent sleep-wake times, including natural afternoon rest' },
  { id: 'stress-low', name: 'Low Chronic Stress', category: 'stress', prevalenceInStudy: 58, associatedAgeEffect: -1.5, confidenceInterval: { lower: -2.2, upper: -0.8 }, description: 'Traditional lifestyle with slower pace, strong community support' },
  { id: 'diet-wine', name: 'Moderate Cannonau Wine', category: 'diet', prevalenceInStudy: 62, associatedAgeEffect: -0.9, confidenceInterval: { lower: -1.4, upper: -0.4 }, description: '1-2 glasses daily of local red wine with meals' },
];

export const dietaryPatterns: DietaryPattern[] = [
  { pattern: 'Traditional Sardinian Mediterranean', adherencePercentage: 42, keyComponents: ['Fava beans', 'Pecorino cheese', 'Barley bread', 'Cannonau wine', 'Wild greens'], biologicalAgeCorrelation: -0.32 },
  { pattern: 'Modified Mediterranean', adherencePercentage: 36, keyComponents: ['Mixed vegetables', 'Olive oil', 'Fish weekly', 'Whole grains', 'Limited red meat'], biologicalAgeCorrelation: -0.24 },
  { pattern: 'Modern Italian', adherencePercentage: 15, keyComponents: ['Pasta', 'Mixed diet', 'Regular meat consumption', 'Processed foods'], biologicalAgeCorrelation: -0.08 },
  { pattern: 'Western-influenced', adherencePercentage: 7, keyComponents: ['Fast food', 'Processed snacks', 'Low vegetable intake', 'High sugar'], biologicalAgeCorrelation: 0.15 },
];

// =============================================================================
// RECRUITMENT SOURCES (From SABA conversion_sources.json)
// =============================================================================

export interface RecruitmentSource {
  id: string;
  name: string;
  code: string;
  uniqueBase: number;
  dailyUnique: number;
  reachRate: number;
  conversionRate: number;
  status: 'active' | 'pending' | 'completed';
  enrolledCount?: number;
}

export const recruitmentSources: RecruitmentSource[] = [
  { id: 'avis', name: 'AVIS Sardegna', code: 'AVIS', uniqueBase: 41000, dailyUnique: 300, reachRate: 0.75, conversionRate: 0.20, status: 'active', enrolledCount: 1640 },
  { id: 'san_michele', name: 'Clinica San Michele', code: 'SM', uniqueBase: 10000, dailyUnique: 150, reachRate: 0.50, conversionRate: 0.10, status: 'active', enrolledCount: 420 },
  { id: 'palaistike', name: 'Palaistike (gym)', code: 'PAL', uniqueBase: 2500, dailyUnique: 50, reachRate: 0.75, conversionRate: 0.30, status: 'active', enrolledCount: 285 },
  { id: 'ferrari', name: 'Ferrari (gym)', code: 'FER', uniqueBase: 2500, dailyUnique: 50, reachRate: 0.75, conversionRate: 0.30, status: 'active', enrolledCount: 264 },
  { id: 'renzo_galanello', name: 'Renzo Galanello', code: 'RG', uniqueBase: 1600, dailyUnique: 10, reachRate: 0.75, conversionRate: 0.10, status: 'active', enrolledCount: 98 },
  { id: 'orange', name: 'Orange (padel)', code: 'OR', uniqueBase: 1000, dailyUnique: 10, reachRate: 0.75, conversionRate: 0.30, status: 'pending', enrolledCount: 78 },
  { id: 'blackwall', name: 'Blackwall (gym)', code: 'BW', uniqueBase: 500, dailyUnique: 20, reachRate: 0.75, conversionRate: 0.30, status: 'pending', enrolledCount: 55 },
];

// =============================================================================
// QUESTIONNAIRE SUMMARY (From SABA questionnaires_index.json)
// =============================================================================

export interface QuestionnaireSummary {
  id: number;
  title: string;
  titleEnglish: string;
  totalBlocks: number;
  totalQuestions: number;
  category: string;
}

export const questionnaires: QuestionnaireSummary[] = [
  { id: 1, title: 'Informazioni di Base', titleEnglish: 'Basic Information', totalBlocks: 6, totalQuestions: 32, category: 'demographics' },
  { id: 2, title: 'Anamnesi Patologica Personale', titleEnglish: 'Personal Medical History', totalBlocks: 3, totalQuestions: 13, category: 'medical' },
  { id: 3, title: 'Screening e Prevenzione', titleEnglish: 'Screening & Prevention', totalBlocks: 2, totalQuestions: 10, category: 'medical' },
  { id: 4, title: 'Anamnesi Patologica Familiare', titleEnglish: 'Family Medical History', totalBlocks: 1, totalQuestions: 15, category: 'medical' },
  { id: 5, title: 'Modificazioni Fenotipiche Sessuali', titleEnglish: 'Hormonal Treatments', totalBlocks: 1, totalQuestions: 4, category: 'medical' },
  { id: 6, title: 'Scala della Percezione dello Stress (PSS-10)', titleEnglish: 'Perceived Stress Scale', totalBlocks: 1, totalQuestions: 11, category: 'psychology' },
  { id: 7, title: 'Funzione Cognitiva', titleEnglish: 'Cognitive Function', totalBlocks: 2, totalQuestions: 16, category: 'psychology' },
  { id: 8, title: 'Benessere Psicologico', titleEnglish: 'Psychological Wellbeing', totalBlocks: 8, totalQuestions: 84, category: 'psychology' },
  { id: 9, title: 'Connessione Sociale e Solitudine', titleEnglish: 'Social Connection & Loneliness', totalBlocks: 2, totalQuestions: 18, category: 'social' },
  { id: 10, title: 'Autonomia e Controllo', titleEnglish: 'Autonomy & Control', totalBlocks: 2, totalQuestions: 11, category: 'personality' },
  { id: 11, title: 'Esposizione Digitale e Affaticamento', titleEnglish: 'Digital Exposure & Fatigue', totalBlocks: 2, totalQuestions: 11, category: 'environment' },
  { id: 12, title: 'Spiritualità e Significato Esistenziale', titleEnglish: 'Spirituality & Meaning', totalBlocks: 3, totalQuestions: 18, category: 'social' },
  { id: 13, title: 'Coinvolgimento della Comunità', titleEnglish: 'Community Involvement', totalBlocks: 1, totalQuestions: 11, category: 'social' },
  { id: 14, title: 'Forze del Carattere (VIA)', titleEnglish: 'Character Strengths VIA', totalBlocks: 1, totalQuestions: 12, category: 'personality' },
  { id: 15, title: 'Struttura di Vita', titleEnglish: 'Life Structure & Roles', totalBlocks: 4, totalQuestions: 22, category: 'lifestyle' },
  { id: 16, title: 'Attività Fisica (WHO GPAQ)', titleEnglish: 'Physical Activity WHO GPAQ', totalBlocks: 4, totalQuestions: 19, category: 'lifestyle' },
  { id: 17, title: 'Dieta e Nutrizione', titleEnglish: 'Diet & Nutrition', totalBlocks: 11, totalQuestions: 36, category: 'lifestyle' },
  { id: 18, title: 'Uso di Sostanze (WHO ASSIST)', titleEnglish: 'Substance Use WHO ASSIST', totalBlocks: 2, totalQuestions: 33, category: 'lifestyle' },
  { id: 19, title: 'Uso di Farmaci', titleEnglish: 'Medication Use', totalBlocks: 6, totalQuestions: 14, category: 'medical' },
  { id: 20, title: 'Ritmo Circadiano (rMEQ)', titleEnglish: 'Circadian Rhythm rMEQ', totalBlocks: 1, totalQuestions: 5, category: 'circadian' },
  { id: 21, title: 'Valutazione della Performance Fisica', titleEnglish: 'Physical Performance', totalBlocks: 4, totalQuestions: 28, category: 'lifestyle' },
  { id: 22, title: 'Esposizione Ambientale', titleEnglish: 'Environmental Exposure', totalBlocks: 7, totalQuestions: 14, category: 'environment' },
  { id: 23, title: 'Tratti di Personalità (IPIP-NEO-30)', titleEnglish: 'Personality IPIP-NEO-30', totalBlocks: 1, totalQuestions: 31, category: 'personality' },
  { id: 24, title: 'Fattori della Prima Infanzia', titleEnglish: 'Early Childhood & Trauma', totalBlocks: 6, totalQuestions: 65, category: 'childhood' },
  { id: 25, title: 'Daily Inputs', titleEnglish: 'Daily Inputs', totalBlocks: 3, totalQuestions: 8, category: 'circadian' },
];

// Total: 25 surveys, 528 questions
