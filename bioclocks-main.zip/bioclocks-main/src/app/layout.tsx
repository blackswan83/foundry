import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'BioClock - Biological Age Calculator',
  description: 'Calculate your biological age using validated scientific clocks based on blood biomarkers. Powered by PhenoAge and KDM algorithms.',
  keywords: ['biological age', 'PhenoAge', 'aging clock', 'blood biomarkers', 'health assessment'],
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="font-sans antialiased">
        {children}
      </body>
    </html>
  );
}
