// API Route: GET /api/saba/stats
// Returns live study statistics from the database

import { NextResponse } from 'next/server';
import { getStudyStats } from '@/lib/saba/queries';
import { isDatabaseConfigured } from '@/lib/saba/db';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    const stats = await getStudyStats();

    return NextResponse.json({
      success: true,
      data: stats,
      source: isDatabaseConfigured() ? 'database' : 'mock',
    });
  } catch (error) {
    console.error('Error fetching study stats:', error);

    // Return mock data on error
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch stats from database',
      data: {
        totalParticipants: 2840,
        centenarianParticipants: 47,
        superAgerParticipants: 312,
        totalWearableDays: 847520,
        questionnairesCompleted: 2680,
        biomarkerSamplesAnalyzed: 8420,
        terraLinkedCount: 0,
        lastUpdated: new Date().toISOString(),
      },
      source: 'mock',
    });
  }
}
