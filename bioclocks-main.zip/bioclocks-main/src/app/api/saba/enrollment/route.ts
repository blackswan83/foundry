// API Route: GET /api/saba/enrollment
// Returns enrollment timeline data from the database

import { NextResponse } from 'next/server';
import { getEnrollmentByDate } from '@/lib/saba/queries';
import { isDatabaseConfigured } from '@/lib/saba/db';

export const dynamic = 'force-dynamic';
export const revalidate = 0;

export async function GET() {
  try {
    const enrollment = await getEnrollmentByDate();

    // Transform to match frontend expected format
    const trends = enrollment.map((row) => ({
      date: row.enrollment_date,
      cumulative: Number(row.cumulative_enrollments),
      weekly: Number(row.daily_enrollments),
    }));

    return NextResponse.json({
      success: true,
      data: trends,
      source: isDatabaseConfigured() ? 'database' : 'mock',
    });
  } catch (error) {
    console.error('Error fetching enrollment data:', error);

    // Return empty array on error (component will fall back to mock)
    return NextResponse.json({
      success: false,
      error: 'Failed to fetch enrollment from database',
      data: [],
      source: 'mock',
    });
  }
}
