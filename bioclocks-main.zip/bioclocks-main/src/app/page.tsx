'use client';

import { useState } from 'react';
import Image from 'next/image';
import Header from '@/components/Header';
import ClockCard, { ClockType } from '@/components/ClockCard';
import History from '@/components/History';
import About from '@/components/About';
import { HistoryEntry } from '@/lib/clocks/types';

type Tab = 'dashboard' | 'history' | 'about';

interface ClockConfig {
  id: ClockType;
  name: string;
  description: string;
  category: 'blood' | 'wearable';
  requiredData: string[];
}

const AVAILABLE_CLOCKS: ClockConfig[] = [
  {
    id: 'phenoage',
    name: 'PhenoAge',
    description: 'Levine 2018 algorithm using 9 blood biomarkers to estimate phenotypic age based on mortality risk.',
    category: 'blood',
    requiredData: ['Albumin', 'Creatinine', 'Glucose', 'CRP', 'WBC', 'Lymphocyte %', 'MCV', 'RDW', 'ALP'],
  },
  {
    id: 'kdm',
    name: 'KDM Biological Age',
    description: 'Klemera-Doubal method using weighted biomarker regression for biological age estimation.',
    category: 'blood',
    requiredData: ['Albumin', 'Creatinine', 'Glucose', 'CRP', 'ALP', 'BUN', 'Cholesterol', 'Blood Pressure'],
  },
  {
    id: 'linage2',
    name: 'linAge2',
    description: 'NHANES-validated PCA + Cox model using 50+ biomarkers for comprehensive mortality-adjusted biological age.',
    category: 'blood',
    requiredData: ['Albumin', 'Creatinine', 'Glucose', 'CRP', 'WBC', 'Lymphocyte %', 'RDW', 'HbA1c', 'HDL'],
  },
  {
    id: 'hrv',
    name: 'HRV Age',
    description: 'Heart rate variability-based age estimation reflecting autonomic nervous system health.',
    category: 'wearable',
    requiredData: ['RMSSD', 'SDNN', 'Resting HR'],
  },
  {
    id: 'sleep',
    name: 'Sleep Age',
    description: 'Sleep quality and architecture analysis to estimate brain and metabolic aging.',
    category: 'wearable',
    requiredData: ['Total Sleep', 'Sleep Efficiency', 'Deep Sleep %', 'REM %'],
  },
  {
    id: 'circadian',
    name: 'Circadian Age',
    description: 'Activity rhythm analysis based on CosinorAge methodology for circadian health assessment.',
    category: 'wearable',
    requiredData: ['Daily Steps', 'Activity Patterns', 'Sleep Regularity'],
  },
];

interface ClockResult {
  biologicalAge: number;
  chronologicalAge: number;
  ageDifference: number;
}

export default function Home() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');
  const [addedClocks, setAddedClocks] = useState<Set<ClockType>>(new Set<ClockType>(['phenoage']));
  const [clockResults, setClockResults] = useState<Partial<Record<ClockType, ClockResult>>>({});
  const [pendingHistoryEntry, setPendingHistoryEntry] = useState<HistoryEntry | null>(null);

  // Simulated data availability (in real app, would check actual data)
  const hasData: Record<ClockType, boolean> = {
    phenoage: true, // Demo: user has blood test data
    kdm: true,
    linage2: true,
    hrv: true,      // Demo: user has wearable data
    sleep: true,
    circadian: true,
  };

  const handleToggleClock = (id: ClockType) => {
    setAddedClocks((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleCalculate = (id: ClockType) => {
    // Demo calculation - in real app, would call actual clock functions
    const chronoAge = 45;
    const demoResults: Record<ClockType, ClockResult> = {
      phenoage: { biologicalAge: 42.3, chronologicalAge: chronoAge, ageDifference: -2.7 },
      kdm: { biologicalAge: 43.8, chronologicalAge: chronoAge, ageDifference: -1.2 },
      linage2: { biologicalAge: 42.9, chronologicalAge: chronoAge, ageDifference: -2.1 },
      hrv: { biologicalAge: 41.5, chronologicalAge: chronoAge, ageDifference: -3.5 },
      sleep: { biologicalAge: 44.2, chronologicalAge: chronoAge, ageDifference: -0.8 },
      circadian: { biologicalAge: 43.1, chronologicalAge: chronoAge, ageDifference: -1.9 },
    };

    setClockResults((prev) => ({
      ...prev,
      [id]: demoResults[id],
    }));
  };

  const handleHistoryEntrySaved = () => {
    setPendingHistoryEntry(null);
  };

  // Calculate composite age from all calculated clocks
  const calculatedClocks = Object.entries(clockResults).filter(([id]) => addedClocks.has(id as ClockType));
  const compositeAge = calculatedClocks.length > 0
    ? calculatedClocks.reduce((sum, [, r]) => sum + r.biologicalAge, 0) / calculatedClocks.length
    : null;

  return (
    <div className="min-h-screen">
      <Header activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main content with top padding for fixed header */}
      <main className="pt-36 sm:pt-28 pb-8">
        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="max-w-6xl mx-auto px-4 sm:px-6">
            {/* Hero Section */}
            <div className="text-center mb-10">
              <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-3">
                Biological Age Clocks
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Select the clocks you want to add to your dashboard. Each clock uses different
                biomarkers to estimate your biological age.
              </p>
            </div>

            {/* Composite Age Display (if any clocks calculated) */}
            {compositeAge && (
              <div className="max-w-md mx-auto mb-10 p-6 rounded-2xl bg-white/30 backdrop-blur-md border border-white/40 text-center">
                <p className="text-sm text-muted-foreground mb-2">Your Composite Biological Age</p>
                <p className="text-5xl font-bold text-primary mb-2">{compositeAge.toFixed(1)}</p>
                <p className="text-sm text-muted-foreground">
                  Based on {calculatedClocks.length} clock{calculatedClocks.length !== 1 ? 's' : ''}
                </p>
              </div>
            )}

            {/* Clock Categories */}
            <div className="space-y-10">
              {/* Blood Biomarker Clocks */}
              <section>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-3 h-3 rounded-full bg-red-500"></div>
                  <h2 className="text-xl font-semibold text-foreground">Blood Biomarker Clocks</h2>
                </div>
                <p className="text-muted-foreground mb-6">
                  These clocks analyze your blood test results to estimate biological age.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {AVAILABLE_CLOCKS.filter((c) => c.category === 'blood').map((clock) => (
                    <ClockCard
                      key={clock.id}
                      {...clock}
                      isAdded={addedClocks.has(clock.id)}
                      hasData={hasData[clock.id]}
                      result={clockResults[clock.id]}
                      onToggle={handleToggleClock}
                      onCalculate={handleCalculate}
                    />
                  ))}
                </div>
              </section>

              {/* Wearable Clocks */}
              <section>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-3 h-3 rounded-full bg-blue-500"></div>
                  <h2 className="text-xl font-semibold text-foreground">Wearable-Based Clocks</h2>
                </div>
                <p className="text-muted-foreground mb-6">
                  These clocks use data from your smartwatch or fitness tracker.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {AVAILABLE_CLOCKS.filter((c) => c.category === 'wearable').map((clock) => (
                    <ClockCard
                      key={clock.id}
                      {...clock}
                      isAdded={addedClocks.has(clock.id)}
                      hasData={hasData[clock.id]}
                      result={clockResults[clock.id]}
                      onToggle={handleToggleClock}
                      onCalculate={handleCalculate}
                    />
                  ))}
                </div>
              </section>
            </div>

            {/* Quick Stats */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-12">
              <div className="p-4 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 text-center">
                <div className="text-2xl font-bold text-primary">{AVAILABLE_CLOCKS.length}</div>
                <div className="text-xs text-muted-foreground">Available Clocks</div>
              </div>
              <div className="p-4 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 text-center">
                <div className="text-2xl font-bold text-primary">{addedClocks.size}</div>
                <div className="text-xs text-muted-foreground">Added to Dashboard</div>
              </div>
              <div className="p-4 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 text-center">
                <div className="text-2xl font-bold text-primary">{calculatedClocks.length}</div>
                <div className="text-xs text-muted-foreground">Calculated</div>
              </div>
              <div className="p-4 rounded-xl bg-white/20 backdrop-blur-sm border border-white/30 text-center">
                <div className="text-2xl font-bold text-primary">100%</div>
                <div className="text-xs text-muted-foreground">Private & Secure</div>
              </div>
            </div>
          </div>
        )}

        {/* History Tab */}
        {activeTab === 'history' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">Your History</h2>
              <p className="text-muted-foreground">
                Track your biological age over time and monitor your progress.
              </p>
            </div>
            <History
              newEntry={pendingHistoryEntry}
              onEntrySaved={handleHistoryEntrySaved}
            />
          </div>
        )}

        {/* About Tab */}
        {activeTab === 'about' && (
          <div className="max-w-4xl mx-auto px-4 sm:px-6">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-foreground mb-2">About Biological Age Clocks</h2>
              <p className="text-muted-foreground">
                Learn about the science behind biological age clocks and important usage information.
              </p>
            </div>
            <About />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/20 mt-8">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Image
                src="/images/nora-logo-header-light-warmSand.svg"
                alt="Nora"
                width={75}
                height={20}
                className="opacity-60"
              />
              <span className="text-sm text-muted-foreground">Biological Age Clocks</span>
            </div>
            <div className="flex items-center gap-6 text-sm">
              <button
                onClick={() => setActiveTab('about')}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                About & Disclaimers
              </button>
              <a
                href="https://nora.nuraxi.ai"
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:opacity-80 transition-opacity"
              >
                Visit Nora
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
