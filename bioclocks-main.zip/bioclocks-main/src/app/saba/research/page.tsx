'use client';

import Link from 'next/link';
import { useState } from 'react';
import { NuraxiHeader } from '@/components/saba/NuraxiHeader';
import { useLanguage } from '@/lib/saba/language-context';
import { dataAvailable, footerData, cohortStats } from '@/lib/saba/study-data';

export default function SABAResearcherPortal() {
  const { t } = useLanguage();
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [requestName, setRequestName] = useState('');
  const [requestInstitution, setRequestInstitution] = useState('');
  const [requestEmail, setRequestEmail] = useState('');
  const [requestInterest, setRequestInterest] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Login attempt:', { email: loginEmail });
    alert('Login functionality coming soon. This is a demo interface.');
  };

  const handleRequestAccess = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Access request:', { name: requestName, institution: requestInstitution, email: requestEmail, interest: requestInterest });
    alert('Thank you for your interest. Applications are reviewed within 2 weeks.');
  };

  return (
    <div className="min-h-screen bg-[#f5f3ed]">
      {/* Header - Nuraxi floating pill style */}
      <NuraxiHeader activePage="research" />

      {/* Add padding for fixed header */}
      <div className="pt-20">
        <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Section 1: Introduction */}
        <section className="mb-12">
          <h1 className="font-serif text-4xl text-[#2d3748] mb-4 text-center">{t('research.title')}</h1>
          <p className="text-lg text-[#718096] max-w-3xl mx-auto text-center">
            {t('research.intro')}
          </p>
        </section>

        {/* Section 2: Data Available */}
        <section className="mb-12">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">{t('research.dataAvailable')}</h2>
          <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
            <ul className="space-y-3">
              {dataAvailable.map((item, idx) => (
                <li key={idx} className="flex items-start gap-3">
                  <span className="w-2 h-2 rounded-full bg-[#7fa8b8] mt-2 flex-shrink-0" />
                  <span className="text-[#4a5568]">{item}</span>
                </li>
              ))}
            </ul>
            <div className="mt-6 pt-6 border-t border-[#e5e0d8] grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-[#2d3748]">{cohortStats.totalParticipants}</div>
                <div className="text-xs text-[#a0aec0]">Participants</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#2d3748]">{cohortStats.wearableHours.toLocaleString()}+</div>
                <div className="text-xs text-[#a0aec0]">Wearable hours</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#2d3748]">{cohortStats.medianTrackingDays}</div>
                <div className="text-xs text-[#a0aec0]">Median tracking days</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-[#2d3748]">25</div>
                <div className="text-xs text-[#a0aec0]">Validated surveys</div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: Two-Column Layout */}
        <section className="mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Left Column: Login */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-xl text-[#2d3748] mb-4">{t('research.login')}</h3>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label htmlFor="login-email" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.email')}
                  </label>
                  <input
                    type="email"
                    id="login-email"
                    value={loginEmail}
                    onChange={(e) => setLoginEmail(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent"
                    placeholder="you@institution.edu"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="login-password" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.password')}
                  </label>
                  <input
                    type="password"
                    id="login-password"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent"
                    placeholder="Enter password"
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2 px-4 bg-[#2d3748] text-white rounded-lg font-medium hover:bg-[#1a202c] transition-colors"
                >
                  {t('research.loginBtn')}
                </button>
                <a href="#" className="block text-sm text-[#7fa8b8] hover:text-[#5a8a9a] text-center">
                  {t('research.forgotPassword')}
                </a>
              </form>
              <p className="mt-4 text-xs text-[#a0aec0] text-center">
                {t('research.loginNote')}
              </p>
            </div>

            {/* Right Column: Request Access */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-xl text-[#2d3748] mb-4">{t('research.requestAccess')}</h3>
              <form onSubmit={handleRequestAccess} className="space-y-4">
                <div>
                  <label htmlFor="request-name" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.name')}
                  </label>
                  <input
                    type="text"
                    id="request-name"
                    value={requestName}
                    onChange={(e) => setRequestName(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent"
                    placeholder="Dr. Jane Smith"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="request-institution" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.institution')}
                  </label>
                  <input
                    type="text"
                    id="request-institution"
                    value={requestInstitution}
                    onChange={(e) => setRequestInstitution(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent"
                    placeholder="University of Example"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="request-email" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.email')}
                  </label>
                  <input
                    type="email"
                    id="request-email"
                    value={requestEmail}
                    onChange={(e) => setRequestEmail(e.target.value)}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent"
                    placeholder="you@institution.edu"
                    required
                  />
                </div>
                <div>
                  <label htmlFor="request-interest" className="block text-sm font-medium text-[#4a5568] mb-1">
                    {t('research.interest')}
                  </label>
                  <textarea
                    id="request-interest"
                    value={requestInterest}
                    onChange={(e) => setRequestInterest(e.target.value)}
                    rows={3}
                    className="w-full px-4 py-2 rounded-lg border border-[#e5e0d8] bg-[#faf8f5] text-[#2d3748] focus:outline-none focus:ring-2 focus:ring-[#7fa8b8] focus:border-transparent resize-none"
                    placeholder="Briefly describe your research question and how SABA data would help..."
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2 px-4 bg-[#d97459] text-white rounded-lg font-medium hover:bg-[#c4634a] transition-colors"
                >
                  {t('research.submitBtn')}
                </button>
              </form>
              <p className="mt-4 text-xs text-[#a0aec0] text-center">
                {t('research.requestNote')}
              </p>
            </div>
          </div>
        </section>

        {/* CTA Links */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link
            href="/saba"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              &larr; {t('research.ctaPublic')}
            </h3>
            <p className="text-sm text-[#718096]">
              {t('research.ctaPublicDesc')}
            </p>
          </Link>
          <Link
            href="/saba/science"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              &larr; {t('research.ctaScience')}
            </h3>
            <p className="text-sm text-[#718096]">
              {t('research.ctaScienceDesc')}
            </p>
          </Link>
        </section>
      </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-[#e5e0d8] bg-white/50">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <p className="text-sm text-[#718096] text-center mb-4 max-w-3xl mx-auto">
            {t('footer.mainText')}
          </p>
          <div className="text-center text-sm text-[#4a5568] mb-4 space-y-1">
            <p>{t('footer.spokeLeader')}</p>
            <p>{t('footer.infrastructure')}</p>
          </div>
          <div className="flex justify-center gap-6 mb-6">
            {footerData.links.map((link) => (
              <a key={link} href="#" className="text-sm text-[#4a5568] hover:text-[#2d3748]">
                {link}
              </a>
            ))}
          </div>
        </div>
        {/* Institutional logos band */}
        <div className="w-full">
          <img
            src="/images/institutional-band.png"
            alt="Finanziato dall'Unione europea NextGenerationEU | Ministero dell'Università e della Ricerca | Italia Domani | UNISS"
            className="w-full h-auto"
          />
        </div>
      </footer>
    </div>
  );
}
