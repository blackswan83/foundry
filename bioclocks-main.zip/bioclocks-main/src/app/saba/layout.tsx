'use client';

import { LanguageProvider } from '@/lib/saba/language-context';

export default function SabaLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return <LanguageProvider>{children}</LanguageProvider>;
}
