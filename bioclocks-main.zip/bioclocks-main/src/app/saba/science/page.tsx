'use client';

import Link from 'next/link';
import { useMemo } from 'react';
import { Heart, Moon, Users, Activity } from 'lucide-react';
import { NuraxiHeader } from '@/components/saba/NuraxiHeader';
import { useLanguage } from '@/lib/saba/language-context';
import {
  cohortStats,
  shapeFramework,
  activityFindings,
  lonelinessFindings,
  stressFindings,
  psychosocialTriad,
  ipAndFuture,
  footerData,
  generateBioAgeScatterData,
} from '@/lib/saba/study-data';

export default function SABAScientificShowcase() {
  const { t } = useLanguage();
  const scatterData = useMemo(() => generateBioAgeScatterData(), []);

  return (
    <div className="min-h-screen bg-[#f5f3ed]">
      {/* Header - Nuraxi floating pill style */}
      <NuraxiHeader activePage="science" />

      {/* Add padding for fixed header */}
      <div className="pt-20">
        <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Section 1: SHAPE Framework */}
        <section className="mb-16">
          <div className="text-center mb-8">
            <h1 className="font-serif text-4xl text-[#2d3748] mb-2">{t('science.shapeTitle')}</h1>
            <p className="text-lg text-[#7fa8b8] font-medium">{t('science.shapeFull')}</p>
          </div>

          <div className="bg-white rounded-xl p-8 border border-[#e5e0d8] mb-8">
            <p className="text-[#4a5568] text-lg leading-relaxed mb-8">
              {t('science.shapeDesc')}
            </p>

            <h3 className="font-serif text-xl text-[#2d3748] mb-6">{t('science.whatMeasures')}</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {shapeFramework.measures.map((measure) => (
                <div key={measure.name} className="p-4 bg-[#f5f0e8] rounded-lg">
                  <div className="w-10 h-10 rounded-lg bg-white flex items-center justify-center mb-3">
                    {measure.icon === 'Heart' && <Heart className="w-5 h-5 text-[#d97459]" />}
                    {measure.icon === 'Moon' && <Moon className="w-5 h-5 text-[#7fa8b8]" />}
                    {measure.icon === 'Users' && <Users className="w-5 h-5 text-[#9f7aea]" />}
                    {measure.icon === 'Activity' && <Activity className="w-5 h-5 text-[#48bb78]" />}
                  </div>
                  <h4 className="font-medium text-[#2d3748] mb-1">{measure.name}</h4>
                  <p className="text-sm text-[#718096]">{measure.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Section 2: Bio Age vs Chrono Age Scatter Plot */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">
            {t('science.bioVsChrono')}
          </h2>
          <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
            <div className="relative h-[400px] mb-4">
              <ScatterPlot data={scatterData} />
            </div>
            <div className="flex items-center justify-center gap-8 text-sm">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#7fa8b8]" />
                <span className="text-[#718096]">{t('science.regularParticipants')}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full bg-[#d97459]" />
                <span className="text-[#718096]">{t('science.superAgersLegend')}</span>
              </div>
            </div>
            <p className="text-center text-sm text-[#a0aec0] mt-4">
              {t('science.scatterDesc')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
            <div className="bg-[#f5f0e8] rounded-lg p-4">
              <div className="text-2xl font-bold text-[#2d3748]">{cohortStats.superAgers.count}</div>
              <div className="text-sm text-[#718096]">{t('science.participants60plus')}</div>
            </div>
            <div className="bg-[#f5f0e8] rounded-lg p-4">
              <div className="text-2xl font-bold text-[#2d3748]">{t('science.yearsYounger')}</div>
              <div className="text-sm text-[#718096]">{t('science.youngerMarkers')}</div>
            </div>
          </div>
        </section>

        {/* Section 3: Validated Correlations */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-2 text-center">{t('science.validatedCorrelations')}</h2>
          <p className="text-center text-[#718096] mb-8">
            {t('science.correlationsDesc')}
          </p>

          <div className="space-y-6">
            {/* Finding 1: Activity */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-lg text-[#2d3748] mb-4">{t('science.finding1Title')}</h3>
              <div className="overflow-x-auto mb-4">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#e5e0d8]">
                      <th className="text-left py-2 text-[#718096] font-medium">Group</th>
                      <th className="text-right py-2 text-[#718096] font-medium">Avg Resting HR</th>
                      <th className="text-right py-2 text-[#718096] font-medium">Sample Size</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-[#e5e0d8]/50">
                      <td className="py-2 text-[#4a5568]">Low Active ({activityFindings.activityGroups.lowActive.threshold})</td>
                      <td className="py-2 text-right font-medium text-[#2d3748]">{activityFindings.activityGroups.lowActive.avgHR} bpm</td>
                      <td className="py-2 text-right text-[#718096]">n={activityFindings.activityGroups.lowActive.sampleSize}</td>
                    </tr>
                    <tr>
                      <td className="py-2 text-[#4a5568]">Highly Active ({activityFindings.activityGroups.highlyActive.threshold})</td>
                      <td className="py-2 text-right font-medium text-[#48bb78]">{activityFindings.activityGroups.highlyActive.avgHR} bpm</td>
                      <td className="py-2 text-right text-[#718096]">n={activityFindings.activityGroups.highlyActive.sampleSize}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="px-3 py-1 bg-[#f5f0e8] rounded-full text-[#4a5568]">
                  Difference: <strong>{activityFindings.activityGroups.difference} bpm</strong>
                </span>
                <span className="text-[#718096]">t={activityFindings.activityGroups.tStat}, p{activityFindings.activityGroups.pValue}</span>
              </div>
              <p className="text-sm text-[#718096] mt-3 italic">
                {t('science.finding1Conclusion')}
              </p>
            </div>

            {/* Finding 2: Social Connection */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-lg text-[#2d3748] mb-4">{t('science.finding2Title')}</h3>
              <div className="overflow-x-auto mb-4">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#e5e0d8]">
                      <th className="text-left py-2 text-[#718096] font-medium">Loneliness Level</th>
                      <th className="text-right py-2 text-[#718096] font-medium">Avg Resting HR</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-[#e5e0d8]/50">
                      <td className="py-2 text-[#4a5568]">Low</td>
                      <td className="py-2 text-right font-medium text-[#48bb78]">{lonelinessFindings.lowLoneliness.avgHR} bpm</td>
                    </tr>
                    <tr>
                      <td className="py-2 text-[#4a5568]">High</td>
                      <td className="py-2 text-right font-medium text-[#e53e3e]">{lonelinessFindings.highLoneliness.avgHR} bpm</td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="px-3 py-1 bg-[#f5f0e8] rounded-full text-[#4a5568]">
                  Correlation: <strong>r={lonelinessFindings.correlation}</strong>
                </span>
                <span className="text-[#718096]">p={lonelinessFindings.pValue}</span>
              </div>
              <p className="text-sm text-[#718096] mt-3 italic">
                {t('science.finding2Conclusion')}
              </p>
            </div>

            {/* Finding 3: Stress */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-lg text-[#2d3748] mb-4">{t('science.finding3Title')}</h3>
              <div className="overflow-x-auto mb-4">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-[#e5e0d8]">
                      <th className="text-left py-2 text-[#718096] font-medium">Stress Level</th>
                      <th className="text-right py-2 text-[#718096] font-medium">% of Cohort</th>
                      <th className="text-right py-2 text-[#718096] font-medium">Avg Resting HR</th>
                    </tr>
                  </thead>
                  <tbody>
                    {stressFindings.levels.map((level, idx) => (
                      <tr key={level.level} className={idx < stressFindings.levels.length - 1 ? 'border-b border-[#e5e0d8]/50' : ''}>
                        <td className="py-2 text-[#4a5568]">{level.level}</td>
                        <td className="py-2 text-right text-[#718096]">{level.percentage}%</td>
                        <td className={`py-2 text-right font-medium ${
                          idx === 0 ? 'text-[#48bb78]' : idx === 1 ? 'text-[#ecc94b]' : 'text-[#e53e3e]'
                        }`}>{level.avgHR} bpm</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <div className="flex items-center gap-4 text-sm">
                <span className="px-3 py-1 bg-[#f5f0e8] rounded-full text-[#4a5568]">
                  Correlation: <strong>r={stressFindings.correlation}</strong>
                </span>
                <span className="text-[#718096]">p={stressFindings.pValue}</span>
              </div>
              <p className="text-sm text-[#718096] mt-3 italic">
                {t('science.finding3Conclusion')}
              </p>
            </div>

            {/* Finding 4: Psychosocial Triad */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
              <h3 className="font-serif text-lg text-[#2d3748] mb-4">{t('science.finding4Title')}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="p-4 bg-[#f5f0e8] rounded-lg text-center">
                  <div className="text-sm text-[#718096] mb-1">{t('science.stressLoneliness')}</div>
                  <div className="text-xl font-bold text-[#d97459]">r={psychosocialTriad.stressLoneliness.correlation}</div>
                  <div className="text-xs text-[#a0aec0]">p{psychosocialTriad.stressLoneliness.pValue} ({t('science.strong')})</div>
                </div>
                <div className="p-4 bg-[#f5f0e8] rounded-lg text-center">
                  <div className="text-sm text-[#718096] mb-1">{t('science.stressHealth')}</div>
                  <div className="text-xl font-bold text-[#7fa8b8]">r={psychosocialTriad.stressHealth.correlation}</div>
                  <div className="text-xs text-[#a0aec0]">p{psychosocialTriad.stressHealth.pValue}</div>
                </div>
                <div className="p-4 bg-[#f5f0e8] rounded-lg text-center">
                  <div className="text-sm text-[#718096] mb-1">{t('science.lonelinessHealth')}</div>
                  <div className="text-xl font-bold text-[#7fa8b8]">r={psychosocialTriad.lonelinessHealth.correlation}</div>
                  <div className="text-xs text-[#a0aec0]">p{psychosocialTriad.lonelinessHealth.pValue}</div>
                </div>
              </div>
              <p className="text-sm text-[#718096] italic">
                {t('science.finding4Conclusion')}
              </p>
            </div>
          </div>
        </section>

        {/* Section 4: Cohort Comparison */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">{t('science.cohortUnique')}</h2>
          <div className="bg-white rounded-xl p-6 border border-[#e5e0d8]">
            <div className="overflow-x-auto mb-4">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-[#e5e0d8]">
                    <th className="text-left py-3 text-[#718096] font-medium">Metric</th>
                    <th className="text-right py-3 text-[#d97459] font-medium">SABA Cohort</th>
                    <th className="text-right py-3 text-[#718096] font-medium">UK Biobank</th>
                    <th className="text-right py-3 text-[#718096] font-medium">All of Us</th>
                    <th className="text-right py-3 text-[#718096] font-medium">US Average</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-[#e5e0d8]/50">
                    <td className="py-3 text-[#4a5568]">Avg Daily Steps</td>
                    <td className="py-3 text-right font-bold text-[#d97459]">10,264</td>
                    <td className="py-3 text-right text-[#718096]">~8,000</td>
                    <td className="py-3 text-right text-[#718096]">~7,000</td>
                    <td className="py-3 text-right text-[#718096]">~6,500</td>
                  </tr>
                  <tr>
                    <td className="py-3 text-[#4a5568]">% Meeting Activity Goals</td>
                    <td className="py-3 text-right font-bold text-[#d97459]">{activityFindings.meetingGoals}%</td>
                    <td className="py-3 text-right text-[#718096]">~30%</td>
                    <td className="py-3 text-right text-[#718096]">~25%</td>
                    <td className="py-3 text-right text-[#718096]">~20%</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-sm text-[#718096] italic">
              {t('science.cohortConclusion')}
            </p>
          </div>
        </section>

        {/* Section 5: IP & Future Direction */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">{t('science.ipTitle')}</h2>
          <div className="bg-white rounded-xl p-8 border border-[#e5e0d8]">
            <p className="text-[#4a5568] mb-6">
              {t('science.ipIntro')}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
              <div className="p-4 bg-[#f5f0e8] rounded-lg">
                <h4 className="font-medium text-[#2d3748] mb-2">Know-how</h4>
                <p className="text-sm text-[#718096]">{ipAndFuture.knowHow}</p>
              </div>
              <div className="p-4 bg-[#f5f0e8] rounded-lg">
                <h4 className="font-medium text-[#2d3748] mb-2">SHAPE Clock</h4>
                <p className="text-sm text-[#718096]">{ipAndFuture.shapeClock}</p>
              </div>
              <div className="p-4 bg-[#f5f0e8] rounded-lg">
                <h4 className="font-medium text-[#2d3748] mb-2">Nora</h4>
                <p className="text-sm text-[#718096]">{ipAndFuture.nora}</p>
              </div>
            </div>
            <p className="text-sm text-[#718096] italic">
              {ipAndFuture.futureText}
            </p>
          </div>
        </section>

        {/* CTA Links */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Link
            href="/saba"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              &larr; {t('science.ctaPublic')}
            </h3>
            <p className="text-sm text-[#718096]">
              {t('science.ctaPublicDesc')}
            </p>
          </Link>
          <Link
            href="/saba/research"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              {t('science.ctaResearch')} &rarr;
            </h3>
            <p className="text-sm text-[#718096]">
              {t('science.ctaResearchDesc')}
            </p>
          </Link>
        </section>
      </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-[#e5e0d8] bg-white/50">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <p className="text-sm text-[#718096] text-center mb-4 max-w-3xl mx-auto">
            {t('footer.mainText')}
          </p>
          <div className="text-center text-sm text-[#4a5568] mb-4 space-y-1">
            <p>{t('footer.spokeLeader')}</p>
            <p>{t('footer.infrastructure')}</p>
          </div>
          <div className="flex justify-center gap-6 mb-6">
            {footerData.links.map((link) => (
              <a key={link} href="#" className="text-sm text-[#4a5568] hover:text-[#2d3748]">
                {link}
              </a>
            ))}
          </div>
        </div>
        {/* Institutional logos band */}
        <div className="w-full">
          <img
            src="/images/institutional-band.png"
            alt="Finanziato dall'Unione europea NextGenerationEU | Ministero dell'Università e della Ricerca | Italia Domani | UNISS"
            className="w-full h-auto"
          />
        </div>
      </footer>
    </div>
  );
}

// Simple Scatter Plot Component
interface ScatterPlotProps {
  data: Array<{
    chronologicalAge: number;
    biologicalAge: number;
    isSuperAger: boolean;
  }>;
}

function ScatterPlot({ data }: ScatterPlotProps) {
  const minAge = 18;
  const maxAge = 95;
  const range = maxAge - minAge;

  return (
    <svg viewBox="0 0 500 400" className="w-full h-full">
      {/* Grid lines */}
      {[20, 40, 60, 80].map((age) => {
        const pos = ((age - minAge) / range) * 450 + 40;
        return (
          <g key={age}>
            <line x1={pos} y1="10" x2={pos} y2="360" stroke="#e5e0d8" strokeWidth="1" />
            <text x={pos} y="380" textAnchor="middle" fontSize="10" fill="#a0aec0">{age}</text>
            <line x1="40" y1={360 - ((age - minAge) / range) * 340} x2="490" y2={360 - ((age - minAge) / range) * 340} stroke="#e5e0d8" strokeWidth="1" />
            <text x="30" y={365 - ((age - minAge) / range) * 340} textAnchor="end" fontSize="10" fill="#a0aec0">{age}</text>
          </g>
        );
      })}

      {/* Axis labels */}
      <text x="265" y="398" textAnchor="middle" fontSize="11" fill="#718096">Chronological Age</text>
      <text x="12" y="185" textAnchor="middle" fontSize="11" fill="#718096" transform="rotate(-90, 12, 185)">Biological Age</text>

      {/* Diagonal line (bio = chrono) */}
      <line
        x1="40"
        y1="360"
        x2="490"
        y2="20"
        stroke="#a0aec0"
        strokeWidth="1"
        strokeDasharray="4,4"
      />

      {/* Data points */}
      {data.map((point, i) => {
        const x = ((point.chronologicalAge - minAge) / range) * 450 + 40;
        const y = 360 - ((point.biologicalAge - minAge) / range) * 340;
        return (
          <circle
            key={i}
            cx={x}
            cy={y}
            r={point.isSuperAger ? 4 : 3}
            fill={point.isSuperAger ? '#d97459' : '#7fa8b8'}
            opacity={point.isSuperAger ? 0.9 : 0.5}
          />
        );
      })}
    </svg>
  );
}
