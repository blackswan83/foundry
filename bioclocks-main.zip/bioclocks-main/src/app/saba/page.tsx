'use client';

import Link from 'next/link';
import { Users, Watch, Calendar, Activity, ClipboardList, Heart, Droplet } from 'lucide-react';
import { NuraxiHeader } from '@/components/saba/NuraxiHeader';
import { SabaMap } from '@/components/saba/SabaMap';
import { useLanguage } from '@/lib/saba/language-context';
import {
  cohortStats,
  activityFindings,
  lonelinessFindings,
  stressFindings,
  footerData,
} from '@/lib/saba/study-data';

// Calculate participant distribution from study data
const sardiniaParticipants = Math.round(cohortStats.totalParticipants * (cohortStats.sardiniaPercentage / 100));
const italyControlParticipants = cohortStats.totalParticipants - sardiniaParticipants;

export default function SABAPublicDashboard() {
  const { t } = useLanguage();

  // Data collection methods with translations
  const dataCollectionMethods = [
    { name: t('dataCollection.wearables'), description: t('dataCollection.wearablesDesc'), icon: 'Watch' },
    { name: t('dataCollection.biological'), description: t('dataCollection.biologicalDesc'), icon: 'Droplet' },
    { name: t('dataCollection.scales'), description: t('dataCollection.scalesDesc'), icon: 'ClipboardList' },
    { name: t('dataCollection.health'), description: t('dataCollection.healthDesc'), icon: 'Heart' },
    { name: t('dataCollection.social'), description: t('dataCollection.socialDesc'), icon: 'Users' },
  ];

  return (
    <div className="min-h-screen bg-[#f5f3ed]">
      {/* Header - Nuraxi floating pill style */}
      <NuraxiHeader activePage="public" />

      {/* Add padding for fixed header */}
      <div className="pt-20">
        <main className="max-w-6xl mx-auto px-6 py-12">
        {/* Hero */}
        <section className="text-center mb-16">
          <h1 className="font-serif text-4xl md:text-5xl text-[#2d3748] mb-4">
            {t('hero.title')}
          </h1>
          <p className="text-lg text-[#718096] max-w-3xl mx-auto mb-4">
            {t('hero.subtitle')}
          </p>
          <p className="text-sm text-[#a0aec0] max-w-xl mx-auto">
            {t('hero.funding')}
          </p>
        </section>

        {/* Section 1: Study at a Glance */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">{t('glance.title')}</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard
              icon={<Users className="w-5 h-5" />}
              value={cohortStats.totalParticipants.toLocaleString()}
              label={t('glance.participants')}
              subtitle={t('glance.participantsTarget')
                .replace('{target}', cohortStats.targetParticipants.toLocaleString())
                .replace('{year}', cohortStats.targetYear.toString())}
              color="blue"
            />
            <StatCard
              icon={<Watch className="w-5 h-5" />}
              value={`${(cohortStats.wearableHours / 1000).toFixed(0)}K+`}
              label={t('glance.wearableHours')}
              subtitle={t('glance.wearableHoursSubtitle')}
              color="teal"
            />
            <StatCard
              icon={<Activity className="w-5 h-5" />}
              value={`${cohortStats.superAgers.percentage}%`}
              label={t('glance.superAgers')}
              subtitle={t('glance.superAgersSubtitle')}
              color="coral"
            />
            <StatCard
              icon={<Calendar className="w-5 h-5" />}
              value={`${cohortStats.infrastructureMonths} ${t('glance.infrastructure').toLowerCase().includes('mesi') ? 'mesi' : 'months'}`}
              label={t('glance.infrastructure')}
              subtitle={t('glance.infrastructureSubtitle')}
              color="slate"
            />
          </div>
          {/* Live sync indicator */}
          <div className="flex items-center justify-center gap-2 mt-4">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500"></span>
            </span>
            <span className="text-xs text-[#718096]">
              {t('glance.lastUpdated')}: 31 December 2025, 9:00am — <span className="font-medium text-green-600">{t('glance.liveSync')}</span>
            </span>
          </div>
        </section>

        {/* Section 2: Map + Context */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="flex justify-center">
              <SabaMap
                width={480}
                height={400}
                sardiniaParticipants={sardiniaParticipants}
                italyControlParticipants={italyControlParticipants}
                enableWorldView={true}
              />
            </div>
            <div>
              <h2 className="font-serif text-2xl text-[#2d3748] mb-4">{t('whySardinia.title')}</h2>
              <div className="space-y-4 text-[#4a5568]">
                <p>{t('whySardinia.p1')}</p>
                <p>{t('whySardinia.p2')}</p>
                <p className="font-medium text-[#2d3748]">
                  {t('whySardinia.objective')}
                </p>
              </div>
              <div className="mt-6 p-4 bg-[#7fa8b8]/10 rounded-lg border border-[#7fa8b8]/30">
                <p className="text-sm text-[#3d6a7a]">
                  <strong>{t('whySardinia.blueZone')}</strong> {t('whySardinia.blueZoneDesc')}
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Section 3: What We're Building */}
        <section className="mb-16">
          <div className="bg-white rounded-xl p-8 border border-[#e5e0d8] shadow-sm">
            <h2 className="font-serif text-2xl text-[#2d3748] mb-6 text-center">{t('building.title')}</h2>
            <div className="space-y-4 text-[#4a5568] max-w-4xl mx-auto">
              <p>{t('building.p1')}</p>
              <p>{t('building.p2')}</p>
              <p>{t('building.p3')}</p>
            </div>
            <p className="text-center mt-8 text-xl font-serif text-[#2d3748] italic">
              {t('building.tagline')}
            </p>
          </div>
        </section>

        {/* Section 4: Key Finding Highlights */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-2 text-center">{t('findings.title')}</h2>
          <p className="text-lg text-[#7fa8b8] font-medium text-center mb-2">{t('findings.intro')}</p>
          <p className="text-sm text-[#718096] text-center max-w-3xl mx-auto mb-8">
            {t('findings.introDesc')}
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Activity Advantage */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8] shadow-sm">
              <div className="text-3xl font-bold text-[#2d3748] mb-1">+58%</div>
              <div className="text-sm font-medium text-[#d97459] mb-3">{t('findings.moreSteps')}</div>
              <p className="text-sm text-[#718096] mb-4">
                {t('findings.stepsComparison').replace('{steps}', activityFindings.sabaAvgSteps.toLocaleString())}
              </p>
              <div className="space-y-2">
                {activityFindings.comparisons.map((comp) => (
                  <div key={comp.name} className="flex items-center gap-2">
                    <div
                      className="h-2 rounded-full bg-[#7fa8b8]"
                      style={{ width: `${(comp.steps / 10264) * 100}%` }}
                    />
                    <span className="text-xs text-[#718096] whitespace-nowrap">
                      {comp.name}: {comp.steps.toLocaleString()}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Social Connection */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8] shadow-sm">
              <div className="text-3xl font-bold text-[#2d3748] mb-1">+{lonelinessFindings.difference} bpm</div>
              <div className="text-sm font-medium text-[#d97459] mb-3">{t('findings.lonelinessImpact')}</div>
              <p className="text-sm text-[#718096] mb-4">
                {t('findings.lonelinessDesc')}
              </p>
              <div className="flex gap-4 mb-3">
                <div className="flex-1 text-center p-3 bg-[#f0f7f4] rounded-lg">
                  <div className="text-lg font-bold text-[#2d3748]">{lonelinessFindings.lowLoneliness.avgHR}</div>
                  <div className="text-xs text-[#718096]">{t('findings.lowLoneliness')}</div>
                </div>
                <div className="flex-1 text-center p-3 bg-[#fef2f0] rounded-lg">
                  <div className="text-lg font-bold text-[#2d3748]">{lonelinessFindings.highLoneliness.avgHR}</div>
                  <div className="text-xs text-[#718096]">{t('findings.highLoneliness')}</div>
                </div>
              </div>
              <p className="text-xs text-[#a0aec0] text-center">p={lonelinessFindings.pValue} — {t('findings.statSignificant')}</p>
            </div>

            {/* Stress-Heart Connection */}
            <div className="bg-white rounded-xl p-6 border border-[#e5e0d8] shadow-sm">
              <div className="text-3xl font-bold text-[#2d3748] mb-1">{stressFindings.totalDifference} bpm</div>
              <div className="text-sm font-medium text-[#d97459] mb-3">{t('findings.stressDifference')}</div>
              <p className="text-sm text-[#718096] mb-4">
                {t('findings.stressDesc')}
              </p>
              <div className="space-y-2">
                {stressFindings.levels.map((level, idx) => (
                  <div key={level.level} className="flex items-center justify-between text-sm">
                    <span className="text-[#4a5568]">
                      {level.level} ({level.percentage}%)
                    </span>
                    <span
                      className={`font-medium ${
                        idx === 0 ? 'text-green-600' : idx === 1 ? 'text-amber-600' : 'text-red-600'
                      }`}
                    >
                      {level.avgHR} bpm
                    </span>
                  </div>
                ))}
              </div>
              <p className="text-xs text-[#a0aec0] text-center mt-3">p={stressFindings.pValue} — {t('findings.statSignificant')}</p>
            </div>
          </div>
        </section>

        {/* Section 5: Data Collection Methods */}
        <section className="mb-16">
          <h2 className="font-serif text-2xl text-[#2d3748] mb-2 text-center">{t('dataCollection.title')}</h2>
          <p className="text-sm text-[#718096] text-center mb-6">{t('dataCollection.intro')}</p>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {dataCollectionMethods.map((method) => (
              <div
                key={method.name}
                className="bg-white rounded-xl p-5 border border-[#e5e0d8] text-center hover:border-[#d9c9a3] transition-colors"
              >
                <div className="w-10 h-10 mx-auto mb-3 rounded-full bg-[#f5f0e8] flex items-center justify-center">
                  {method.icon === 'Watch' && <Watch className="w-5 h-5 text-[#7fa8b8]" />}
                  {method.icon === 'Droplet' && <Droplet className="w-5 h-5 text-[#d97459]" />}
                  {method.icon === 'ClipboardList' && <ClipboardList className="w-5 h-5 text-[#7fa8b8]" />}
                  {method.icon === 'Heart' && <Heart className="w-5 h-5 text-[#7fa8b8]" />}
                  {method.icon === 'Users' && <Users className="w-5 h-5 text-[#7fa8b8]" />}
                </div>
                <h3 className="font-medium text-[#2d3748] mb-1 text-sm">{method.name}</h3>
                <p className="text-xs text-[#718096]">{method.description}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA Links */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
          <Link
            href="/saba/science"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              {t('cta.scienceTitle')} &rarr;
            </h3>
            <p className="text-sm text-[#718096]">
              {t('cta.scienceDesc')}
            </p>
          </Link>
          <Link
            href="/saba/research"
            className="bg-white rounded-xl p-6 border border-[#e5e0d8] hover:border-[#7fa8b8] transition-colors group"
          >
            <h3 className="font-serif text-lg text-[#2d3748] mb-2 group-hover:text-[#7fa8b8]">
              {t('cta.researchTitle')} &rarr;
            </h3>
            <p className="text-sm text-[#718096]">
              {t('cta.researchDesc')}
            </p>
          </Link>
        </section>
      </main>
      </div>

      {/* Footer - Full institutional attribution */}
      <footer className="border-t border-[#e5e0d8] bg-white/50">
        <div className="max-w-6xl mx-auto px-6 py-8">
          <p className="text-sm text-[#718096] text-center mb-4 max-w-3xl mx-auto">
            {t('footer.mainText')}
          </p>
          <div className="text-center text-sm text-[#4a5568] mb-4 space-y-1">
            <p>{t('footer.spokeLeader')}</p>
            <p>{t('footer.infrastructure')}</p>
          </div>
          <div className="flex justify-center gap-6 mb-6">
            {footerData.links.map((link) => (
              <a key={link} href="#" className="text-sm text-[#4a5568] hover:text-[#2d3748]">
                {link}
              </a>
            ))}
          </div>
        </div>
        {/* Institutional logos band */}
        <div className="w-full">
          <img
            src="/images/institutional-band.png"
            alt="Finanziato dall'Unione europea NextGenerationEU | Ministero dell'Università e della Ricerca | Italia Domani | UNISS"
            className="w-full h-auto"
          />
        </div>
      </footer>
    </div>
  );
}

// Stat Card Component
interface StatCardProps {
  icon: React.ReactNode;
  value: string;
  label: string;
  subtitle: string;
  color: 'blue' | 'teal' | 'coral' | 'slate';
}

function StatCard({ icon, value, label, subtitle, color }: StatCardProps) {
  const colorClasses = {
    blue: 'bg-blue-50 text-blue-600',
    teal: 'bg-teal-50 text-teal-600',
    coral: 'bg-orange-50 text-orange-600',
    slate: 'bg-slate-50 text-slate-600',
  };

  return (
    <div className="bg-white rounded-xl p-5 border border-[#e5e0d8] shadow-sm">
      <div className={`w-10 h-10 rounded-lg ${colorClasses[color]} flex items-center justify-center mb-3`}>
        {icon}
      </div>
      <div className="text-2xl font-bold text-[#2d3748] mb-1">{value}</div>
      <div className="text-sm font-medium text-[#4a5568] mb-1">{label}</div>
      <div className="text-xs text-[#a0aec0]">{subtitle}</div>
    </div>
  );
}
