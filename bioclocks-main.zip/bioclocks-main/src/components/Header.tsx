'use client';

import Image from 'next/image';
import { User } from 'lucide-react';

interface HeaderProps {
  activeTab: 'dashboard' | 'history' | 'about';
  onTabChange: (tab: 'dashboard' | 'history' | 'about') => void;
}

export default function Header({ activeTab, onTabChange }: HeaderProps) {
  return (
    <div className="fixed top-0 left-0 right-0 z-50 pointer-events-none">
      {/* Gradient overlay for fade effect - matches Nora */}
      <div className="h-32 bg-gradient-to-b from-scroll-gradient-top from-50% to-transparent w-full"></div>

      {/* Header container */}
      <div className="absolute top-0 left-0 right-0 flex justify-between items-center py-6 px-4 sm:px-6 pointer-events-auto">
        {/* Left side - Logo */}
        <div className="flex items-center gap-4">
          <Image
            src="/images/nora-logo-header-light-warmSand.svg"
            alt="Nora"
            width={120}
            height={32}
            priority
          />
        </div>

        {/* Center - Navigation tabs */}
        <nav className="hidden sm:flex items-center gap-1 bg-white/10 backdrop-blur-md rounded-full p-1 border border-white/20">
          <button
            onClick={() => onTabChange('dashboard')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
              activeTab === 'dashboard'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground hover:bg-white/20'
            }`}
          >
            Clocks
          </button>
          <button
            onClick={() => onTabChange('history')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
              activeTab === 'history'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground hover:bg-white/20'
            }`}
          >
            History
          </button>
          <button
            onClick={() => onTabChange('about')}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
              activeTab === 'about'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground hover:bg-white/20'
            }`}
          >
            About
          </button>
        </nav>

        {/* Right - User button */}
        <div className="flex items-center">
          <button
            className="w-10 h-10 rounded-full bg-white/10 backdrop-blur-md border border-primary flex items-center justify-center text-primary hover:bg-white/20 transition-colors"
            aria-label="User menu"
          >
            <User className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Mobile navigation - bottom of gradient */}
      <div className="sm:hidden absolute top-20 left-0 right-0 flex justify-center pointer-events-auto">
        <nav className="flex items-center gap-1 bg-white/10 backdrop-blur-md rounded-full p-1 border border-white/20">
          <button
            onClick={() => onTabChange('dashboard')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
              activeTab === 'dashboard'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground'
            }`}
          >
            Clocks
          </button>
          <button
            onClick={() => onTabChange('history')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
              activeTab === 'history'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground'
            }`}
          >
            History
          </button>
          <button
            onClick={() => onTabChange('about')}
            className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all duration-200 ${
              activeTab === 'about'
                ? 'bg-primary text-primary-foreground shadow-md'
                : 'text-foreground/70 hover:text-foreground'
            }`}
          >
            About
          </button>
        </nav>
      </div>
    </div>
  );
}
