'use client';

import { Info } from 'lucide-react';
import { BiomarkerInfo } from '@/lib/clocks/types';
import { cn } from '@/lib/utils';

interface BiomarkerInputProps {
  biomarker: BiomarkerInfo;
  value: string;
  onChange: (value: string) => void;
  unitSystem: 'us' | 'si';
  sex: 'male' | 'female';
  required?: boolean;
  error?: string;
}

export default function BiomarkerInput({
  biomarker,
  value,
  onChange,
  unitSystem,
  sex,
  required = false,
  error,
}: BiomarkerInputProps) {
  const unit = unitSystem === 'us' ? biomarker.usUnit : biomarker.siUnit;
  const range = biomarker.referenceRanges[sex];

  // Convert reference range for SI display
  let displayMin = range.min;
  let displayMax = range.max;

  if (unitSystem === 'si' && biomarker.conversionFactor !== 1) {
    displayMin = range.min * biomarker.conversionFactor;
    displayMax = range.max * biomarker.conversionFactor;
  }

  // Format reference range display
  const formatRef = (val: number) => {
    if (val >= 100) return Math.round(val);
    if (val >= 10) return val.toFixed(1);
    return val.toFixed(2);
  };

  return (
    <div className="group">
      <div className="flex items-center justify-between mb-1.5">
        <label className="input-label flex items-center gap-1.5">
          {biomarker.name}
          {required && <span className="text-red-500">*</span>}
          <span className="relative has-tooltip">
            <Info className="w-3.5 h-3.5 text-slate-400 cursor-help" />
            <span className="tooltip -top-2 left-6 w-48">
              {biomarker.description}
            </span>
          </span>
        </label>
        <span className="text-xs text-slate-400">
          Ref: {formatRef(displayMin)} - {formatRef(displayMax)}
        </span>
      </div>
      <div className="relative">
        <input
          type="number"
          step="any"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          placeholder={`Enter ${biomarker.abbreviation}`}
          className={cn(
            'input-field pr-16',
            error && 'border-red-300 focus:border-red-500 focus:ring-red-500/20'
          )}
        />
        <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-slate-400">
          {unit}
        </span>
      </div>
      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}
    </div>
  );
}
