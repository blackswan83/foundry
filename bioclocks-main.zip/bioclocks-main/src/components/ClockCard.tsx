'use client';

import { Activity, Heart, Moon, Sun, Droplets, Plus, Check, ChevronRight, LineChart } from 'lucide-react';

export type ClockType = 'phenoage' | 'kdm' | 'linage2' | 'hrv' | 'sleep' | 'circadian';

export interface ClockCardProps {
  id: ClockType;
  name: string;
  description: string;
  category: 'blood' | 'wearable';
  requiredData: string[];
  isAdded: boolean;
  hasData: boolean;
  result?: {
    biologicalAge: number;
    chronologicalAge: number;
    ageDifference: number;
  };
  onToggle: (id: ClockType) => void;
  onCalculate: (id: ClockType) => void;
}

const CLOCK_ICONS: Record<ClockType, typeof Activity> = {
  phenoage: Droplets,
  kdm: Droplets,
  linage2: LineChart,
  hrv: Heart,
  sleep: Moon,
  circadian: Sun,
};

const CATEGORY_COLORS = {
  blood: {
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    text: 'text-red-600',
    badge: 'bg-red-500/20 text-red-700',
  },
  wearable: {
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    text: 'text-blue-600',
    badge: 'bg-blue-500/20 text-blue-700',
  },
};

export default function ClockCard({
  id,
  name,
  description,
  category,
  requiredData,
  isAdded,
  hasData,
  result,
  onToggle,
  onCalculate,
}: ClockCardProps) {
  const Icon = CLOCK_ICONS[id];
  const colors = CATEGORY_COLORS[category];

  return (
    <div
      className={`relative rounded-2xl border backdrop-blur-md transition-all duration-300 overflow-hidden ${
        isAdded
          ? 'bg-white/40 border-primary/30 shadow-lg'
          : 'bg-white/20 border-white/30 hover:bg-white/30'
      }`}
    >
      {/* Category badge */}
      <div className="absolute top-3 right-3">
        <span className={`text-xs font-medium px-2 py-1 rounded-full ${colors.badge}`}>
          {category === 'blood' ? 'Blood Test' : 'Wearable'}
        </span>
      </div>

      <div className="p-5">
        {/* Icon and title */}
        <div className="flex items-start gap-4 mb-4">
          <div className={`w-12 h-12 rounded-xl ${colors.bg} ${colors.border} border flex items-center justify-center`}>
            <Icon className={`w-6 h-6 ${colors.text}`} />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-lg font-semibold text-foreground truncate">{name}</h3>
            <p className="text-sm text-muted-foreground line-clamp-2">{description}</p>
          </div>
        </div>

        {/* Required data */}
        <div className="mb-4">
          <p className="text-xs text-muted-foreground mb-2">Required data:</p>
          <div className="flex flex-wrap gap-1">
            {requiredData.slice(0, 3).map((data) => (
              <span
                key={data}
                className="text-xs px-2 py-0.5 rounded-full bg-white/30 text-foreground/70"
              >
                {data}
              </span>
            ))}
            {requiredData.length > 3 && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-white/30 text-foreground/70">
                +{requiredData.length - 3} more
              </span>
            )}
          </div>
        </div>

        {/* Result display (if calculated) */}
        {result && (
          <div className="mb-4 p-3 rounded-xl bg-white/30 border border-white/40">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Biological Age</span>
              <span className={`text-2xl font-bold ${
                result.ageDifference < -2
                  ? 'text-semantic-success'
                  : result.ageDifference > 2
                  ? 'text-semantic-error'
                  : 'text-semantic-warning'
              }`}>
                {result.biologicalAge.toFixed(1)}
              </span>
            </div>
            <div className="flex items-center justify-between mt-1">
              <span className="text-xs text-muted-foreground">vs chronological: {result.chronologicalAge}</span>
              <span className={`text-sm font-medium ${
                result.ageDifference < 0 ? 'text-semantic-success' : 'text-semantic-error'
              }`}>
                {result.ageDifference > 0 ? '+' : ''}{result.ageDifference.toFixed(1)} years
              </span>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onToggle(id)}
            className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl font-medium text-sm transition-all duration-200 ${
              isAdded
                ? 'bg-primary/20 text-primary border border-primary/30'
                : 'bg-white/30 text-foreground hover:bg-white/50 border border-white/40'
            }`}
          >
            {isAdded ? (
              <>
                <Check className="w-4 h-4" />
                Added to Dashboard
              </>
            ) : (
              <>
                <Plus className="w-4 h-4" />
                Add to Dashboard
              </>
            )}
          </button>

          {isAdded && hasData && (
            <button
              onClick={() => onCalculate(id)}
              className="flex items-center justify-center gap-1 py-2.5 px-4 rounded-xl font-medium text-sm bg-primary text-primary-foreground hover:opacity-90 transition-opacity"
            >
              Calculate
              <ChevronRight className="w-4 h-4" />
            </button>
          )}
        </div>

        {isAdded && !hasData && (
          <p className="text-xs text-muted-foreground text-center mt-2">
            Missing required data. Connect your {category === 'blood' ? 'lab results' : 'wearable device'}.
          </p>
        )}
      </div>
    </div>
  );
}
