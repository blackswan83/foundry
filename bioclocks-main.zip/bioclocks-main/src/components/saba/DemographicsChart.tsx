'use client';

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { Users } from 'lucide-react';
import type { DemographicBreakdown } from '@/lib/saba/types';

interface DemographicsChartProps {
  demographics: DemographicBreakdown[];
}

export default function DemographicsChart({ demographics }: DemographicsChartProps) {
  const chartData = demographics.map((d) => ({
    ageRange: d.ageRange,
    male: d.maleCount,
    female: d.femaleCount,
    total: d.maleCount + d.femaleCount,
    percentage: d.percentageOfTotal,
  }));

  const totalMale = demographics.reduce((sum, d) => sum + d.maleCount, 0);
  const totalFemale = demographics.reduce((sum, d) => sum + d.femaleCount, 0);
  const percentFemale = ((totalFemale / (totalMale + totalFemale)) * 100).toFixed(1);

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Users className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Demographic Distribution</h3>
            <p className="text-sm text-muted-foreground">Participants by age and sex</p>
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500" />
            <span className="text-muted-foreground">Male ({totalMale})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-pink-500" />
            <span className="text-muted-foreground">Female ({totalFemale})</span>
          </div>
        </div>
      </div>

      <div className="h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart
            data={chartData}
            layout="horizontal"
            margin={{ top: 10, right: 10, left: 10, bottom: 10 }}
          >
            <XAxis
              dataKey="ageRange"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: 'hsl(33 27% 26%)' }}
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: 'hsl(33 27% 26%)' }}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                border: 'none',
                borderRadius: '12px',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                padding: '12px 16px',
              }}
              cursor={{ fill: 'rgba(0, 0, 0, 0.05)' }}
              formatter={(value: number, name: string) => [
                `${value} participants`,
                name === 'male' ? 'Male' : 'Female',
              ]}
              labelFormatter={(label) => `Age ${label}`}
            />
            <Bar
              dataKey="male"
              stackId="gender"
              fill="hsl(217 91% 60%)"
              radius={[0, 0, 0, 0]}
            />
            <Bar
              dataKey="female"
              stackId="gender"
              fill="hsl(330 81% 60%)"
              radius={[4, 4, 0, 0]}
            />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4 mt-4 pt-4 border-t border-white/20">
        <div className="text-center">
          <p className="text-xl font-bold text-foreground">
            {percentFemale}%
          </p>
          <p className="text-xs text-muted-foreground">Female participants</p>
        </div>
        <div className="text-center">
          <p className="text-xl font-bold text-foreground">
            72.5
          </p>
          <p className="text-xs text-muted-foreground">Median age (years)</p>
        </div>
        <div className="text-center">
          <p className="text-xl font-bold text-success">
            18-108
          </p>
          <p className="text-xs text-muted-foreground">Age range</p>
        </div>
      </div>

      {/* Privacy note */}
      <p className="text-xs text-muted-foreground text-center mt-4 italic">
        All counts shown in 5-year age bands and rounded to nearest 20 for privacy protection.
      </p>
    </div>
  );
}
