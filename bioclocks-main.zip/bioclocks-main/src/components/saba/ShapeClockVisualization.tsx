'use client';

import { useState } from 'react';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  Legend,
  ZAxis,
} from 'recharts';
import { Activity, TrendingDown, Info } from 'lucide-react';
import type { ShapeClockResult, ShapeValidationMetric } from '@/lib/saba/types';

interface ShapeClockVisualizationProps {
  scatterData: Array<{
    chronologicalAge: number;
    biologicalAge: number;
    cohort: string;
  }>;
  validationMetrics: ShapeValidationMetric[];
  sampleResult?: ShapeClockResult;
}

export default function ShapeClockVisualization({
  scatterData,
  validationMetrics,
  sampleResult,
}: ShapeClockVisualizationProps) {
  const [showBlueZoneOnly, setShowBlueZoneOnly] = useState(false);

  const filteredData = showBlueZoneOnly
    ? scatterData.filter((d) => d.cohort === 'Blue Zone')
    : scatterData;

  const blueZoneData = scatterData.filter((d) => d.cohort === 'Blue Zone');
  const comparisonData = scatterData.filter((d) => d.cohort === 'Comparison');

  const primaryValidation = validationMetrics[0];

  return (
    <div className="card p-6">
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary/20 to-purple-500/20 flex items-center justify-center">
            <Activity className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-foreground">SHAPE Clock</h3>
            <p className="text-sm text-muted-foreground">
              Non-invasive biological age from wearable + questionnaire data
            </p>
          </div>
        </div>

        {/* Toggle */}
        <div className="flex items-center gap-2">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={showBlueZoneOnly}
              onChange={(e) => setShowBlueZoneOnly(e.target.checked)}
              className="sr-only"
            />
            <div className={`w-10 h-6 rounded-full transition-colors ${showBlueZoneOnly ? 'bg-success' : 'bg-gray-300'}`}>
              <div className={`w-4 h-4 mt-1 rounded-full bg-white shadow-sm transition-transform ${showBlueZoneOnly ? 'translate-x-5' : 'translate-x-1'}`} />
            </div>
            <span className="text-sm text-muted-foreground">Blue Zone only</span>
          </label>
        </div>
      </div>

      {/* Main scatter plot */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="h-80 bg-white/30 rounded-xl p-4 border border-white/40">
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart margin={{ top: 20, right: 20, bottom: 20, left: 20 }}>
                <XAxis
                  type="number"
                  dataKey="chronologicalAge"
                  name="Chronological Age"
                  domain={[20, 110]}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 11, fill: 'hsl(33 27% 26%)' }}
                  label={{ value: 'Chronological Age (years)', position: 'bottom', fontSize: 12, fill: 'hsl(33 27% 26%)' }}
                />
                <YAxis
                  type="number"
                  dataKey="biologicalAge"
                  name="Biological Age"
                  domain={[20, 110]}
                  axisLine={false}
                  tickLine={false}
                  tick={{ fontSize: 11, fill: 'hsl(33 27% 26%)' }}
                  label={{ value: 'SHAPE Biological Age', angle: -90, position: 'insideLeft', fontSize: 12, fill: 'hsl(33 27% 26%)' }}
                />
                <ZAxis range={[40, 40]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: 'none',
                    borderRadius: '12px',
                    boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                    padding: '12px 16px',
                  }}
                  formatter={(value: number, name: string) => [
                    `${value.toFixed(1)} years`,
                    name === 'chronologicalAge' ? 'Chronological' : 'Biological',
                  ]}
                />
                {/* Reference line y=x (perfect correlation) */}
                <ReferenceLine
                  segment={[{ x: 20, y: 20 }, { x: 110, y: 110 }]}
                  stroke="hsl(0 84% 50%)"
                  strokeDasharray="5 5"
                  strokeWidth={2}
                />
                {/* Comparison cohort */}
                {!showBlueZoneOnly && (
                  <Scatter
                    name="Comparison"
                    data={comparisonData}
                    fill="hsl(25 38% 67%)"
                    opacity={0.5}
                  />
                )}
                {/* Blue Zone cohort */}
                <Scatter
                  name="Blue Zone"
                  data={blueZoneData}
                  fill="hsl(142 69% 45%)"
                  opacity={0.8}
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          {/* Legend */}
          <div className="flex items-center justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-success" />
              <span className="text-sm text-muted-foreground">Blue Zone Participants</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-primary/50" />
              <span className="text-sm text-muted-foreground">Comparison Regions</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-0.5 bg-red-500" style={{ borderStyle: 'dashed' }} />
              <span className="text-sm text-muted-foreground">y = x (no age difference)</span>
            </div>
          </div>
        </div>

        {/* Validation metrics */}
        <div className="space-y-4">
          {/* Primary metrics */}
          <div className="p-4 rounded-xl bg-success-light/50 border border-green-200">
            <h4 className="text-sm font-medium text-green-800 mb-3 flex items-center gap-2">
              <TrendingDown className="w-4 h-4" />
              Blue Zone Advantage
            </h4>
            <div className="space-y-3">
              <div>
                <p className="text-3xl font-bold text-success">-4.2</p>
                <p className="text-xs text-green-700">years younger biological age (mean)</p>
              </div>
              <div className="pt-3 border-t border-green-200">
                <p className="text-sm text-green-800">
                  Blue Zone participants show <span className="font-semibold">significantly younger</span> biological age compared to chronological age
                </p>
              </div>
            </div>
          </div>

          {/* Validation stats */}
          <div className="p-4 rounded-xl bg-white/30 border border-white/40">
            <h4 className="text-sm font-medium text-foreground mb-3">Validation Metrics</h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Correlation (r)</span>
                <span className="font-semibold text-foreground">{primaryValidation.correlation.toFixed(2)}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">MAE</span>
                <span className="font-semibold text-foreground">{primaryValidation.meanAbsoluteError} years</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Sample Size</span>
                <span className="font-semibold text-foreground">n = {primaryValidation.sampleSize.toLocaleString()}</span>
              </div>
            </div>
          </div>

          {/* Info note */}
          <div className="p-3 rounded-lg bg-blue-50 border border-blue-100 flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-blue-700">
              Points below the red line indicate younger biological age than chronological age
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
