'use client';

import { useEffect, useState } from 'react';
import { Users, Calendar, Clock } from 'lucide-react';

interface EnrollmentCounterProps {
  totalParticipants: number;
  centenarianParticipants: number;
  lastUpdated: string;
}

function AnimatedNumber({ value, duration = 2000 }: { value: number; duration?: number }) {
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const startTime = Date.now();
    const startValue = 0;

    const animate = () => {
      const now = Date.now();
      const progress = Math.min((now - startTime) / duration, 1);
      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - progress, 4);
      const current = Math.round(startValue + (value - startValue) * easeOutQuart);
      setDisplayValue(current);

      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [value, duration]);

  return <span>{displayValue.toLocaleString()}</span>;
}

export default function EnrollmentCounter({
  totalParticipants,
  centenarianParticipants,
  lastUpdated,
}: EnrollmentCounterProps) {
  const formattedDate = new Date(lastUpdated).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <div className="card p-8 text-center">
      {/* Main counter */}
      <div className="mb-6">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-primary/10 mb-4">
          <Users className="w-8 h-8 text-primary" />
        </div>
        <div className="text-6xl font-bold text-foreground mb-2">
          <AnimatedNumber value={totalParticipants} />
          <span className="text-primary">+</span>
        </div>
        <p className="text-lg text-muted-foreground">
          Sardinian participants contributing to longevity science
        </p>
      </div>

      {/* Centenarian highlight */}
      <div className="inline-flex items-center gap-3 px-5 py-3 rounded-xl bg-success-light border border-green-200">
        <span className="text-2xl font-bold text-success">
          <AnimatedNumber value={centenarianParticipants} duration={2500} />
        </span>
        <span className="text-sm text-green-700">
          centenarians enrolled
        </span>
      </div>

      {/* Last updated */}
      <div className="flex items-center justify-center gap-2 mt-6 text-sm text-muted-foreground">
        <Clock className="w-4 h-4" />
        <span>Last updated: {formattedDate}</span>
      </div>
    </div>
  );
}
