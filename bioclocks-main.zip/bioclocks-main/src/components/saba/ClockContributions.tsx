'use client';

import { Activity, Moon, Heart, Footprints, ClipboardList } from 'lucide-react';
import type { ShapeClockResult, ShapeContributingFactor } from '@/lib/saba/types';

interface ClockContributionsProps {
  result: ShapeClockResult;
}

const CATEGORY_ICONS = {
  circadian: Activity,
  hrv: Heart,
  sleep: Moon,
  activity: Footprints,
  questionnaire: ClipboardList,
};

const STATUS_COLORS = {
  optimal: {
    bar: 'bg-success',
    text: 'text-success',
    bg: 'bg-success-light',
    label: 'Optimal',
  },
  moderate: {
    bar: 'bg-warning',
    text: 'text-amber-600',
    bg: 'bg-warning-light',
    label: 'Moderate',
  },
  suboptimal: {
    bar: 'bg-error',
    text: 'text-error',
    bg: 'bg-error-light',
    label: 'Needs Attention',
  },
};

export default function ClockContributions({ result }: ClockContributionsProps) {
  const { compositeAge, chronologicalAge, ageDifference, confidenceInterval, contributingFactors } = result;

  // Sort factors by absolute contribution (largest impact first)
  const sortedFactors = [...contributingFactors].sort(
    (a, b) => Math.abs(b.contribution) - Math.abs(a.contribution)
  );

  return (
    <div className="card p-6">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">SHAPE Clock Breakdown</h3>
          <p className="text-sm text-muted-foreground">
            Contributing factors to biological age calculation
          </p>
        </div>
      </div>

      {/* Primary result display */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-xl bg-white/30 border border-white/40 text-center">
          <p className="text-sm text-muted-foreground mb-1">Chronological Age</p>
          <p className="text-3xl font-bold text-foreground">{chronologicalAge}</p>
        </div>
        <div className={`p-4 rounded-xl text-center ${ageDifference < 0 ? 'bg-success-light border border-green-200' : 'bg-error-light border border-red-200'}`}>
          <p className="text-sm text-muted-foreground mb-1">SHAPE Biological Age</p>
          <p className={`text-3xl font-bold ${ageDifference < 0 ? 'text-success' : 'text-error'}`}>
            {compositeAge.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            95% CI: [{confidenceInterval.lower.toFixed(1)}, {confidenceInterval.upper.toFixed(1)}]
          </p>
        </div>
        <div className={`p-4 rounded-xl text-center ${ageDifference < 0 ? 'bg-success-light border border-green-200' : 'bg-error-light border border-red-200'}`}>
          <p className="text-sm text-muted-foreground mb-1">Age Difference</p>
          <p className={`text-3xl font-bold ${ageDifference < 0 ? 'text-success' : 'text-error'}`}>
            {ageDifference > 0 ? '+' : ''}{ageDifference.toFixed(1)}
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            years {ageDifference < 0 ? 'younger' : 'older'}
          </p>
        </div>
      </div>

      {/* Contributing factors */}
      <div className="space-y-4">
        <h4 className="text-sm font-medium text-foreground">Factor Contributions</h4>

        {sortedFactors.map((factor) => {
          const Icon = CATEGORY_ICONS[factor.category] || Activity;
          const statusConfig = STATUS_COLORS[factor.status];
          const maxContribution = Math.max(...contributingFactors.map((f) => Math.abs(f.contribution)));
          const barWidth = (Math.abs(factor.contribution) / maxContribution) * 100;

          return (
            <div key={factor.name} className="p-4 rounded-xl bg-white/20 border border-white/30">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg ${statusConfig.bg} flex items-center justify-center`}>
                    <Icon className={`w-5 h-5 ${statusConfig.text}`} />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{factor.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{factor.category}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-lg font-bold ${factor.contribution < 0 ? 'text-success' : 'text-error'}`}>
                    {factor.contribution > 0 ? '+' : ''}{factor.contribution.toFixed(1)} years
                  </p>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${statusConfig.bg} ${statusConfig.text}`}>
                    {statusConfig.label}
                  </span>
                </div>
              </div>

              {/* Progress bar */}
              <div className="flex items-center gap-3">
                <div className="flex-1 h-2 bg-white/30 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${statusConfig.bar}`}
                    style={{ width: `${barWidth}%` }}
                  />
                </div>
                {factor.percentile && (
                  <span className="text-xs text-muted-foreground whitespace-nowrap">
                    {factor.percentile}th percentile
                  </span>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Interpretation */}
      <div className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-100">
        <p className="text-sm text-blue-800">
          <span className="font-semibold">Interpretation:</span> This participant shows a biological age{' '}
          <span className="font-semibold">{Math.abs(ageDifference).toFixed(1)} years {ageDifference < 0 ? 'younger' : 'older'}</span>{' '}
          than their chronological age. The largest positive contributors are{' '}
          <span className="font-semibold">{sortedFactors.filter((f) => f.contribution < 0).slice(0, 2).map((f) => f.name.toLowerCase()).join(' and ')}</span>.
        </p>
      </div>
    </div>
  );
}
