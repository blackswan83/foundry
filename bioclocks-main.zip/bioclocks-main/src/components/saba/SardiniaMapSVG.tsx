'use client';

// Accurate Sardinia island outline with Blue Zone (Ogliastra/Barbagia) highlighted

interface SardiniaMapSVGProps {
  className?: string;
  width?: number;
  height?: number;
}

export function SardiniaMapSVG({ className = '', width = 300, height = 400 }: SardiniaMapSVGProps) {
  return (
    <svg
      viewBox="0 0 200 280"
      width={width}
      height={height}
      className={className}
      aria-label="Map of Sardinia showing Blue Zone region"
    >
      {/* Sardinia Island Outline - Accurate shape */}
      <path
        d="M95 5
           C105 3 115 8 125 12
           L140 18 C148 22 155 28 160 35
           L165 45 C168 52 172 60 175 68
           L180 82 C182 90 183 98 182 106
           L180 120 C178 130 175 140 172 150
           L168 162 C165 172 160 182 155 190
           L148 202 C142 212 135 220 128 228
           L118 238 C110 246 100 252 90 256
           L78 262 C68 266 58 268 48 268
           L38 266 C28 264 20 258 15 250
           L10 238 C6 228 5 218 6 208
           L8 195 C10 185 14 175 18 165
           L24 152 C28 142 32 132 35 122
           L38 110 C40 100 42 90 45 80
           L50 68 C54 58 60 48 68 40
           L78 30 C85 22 90 12 95 5
           Z"
        fill="#f5f0e8"
        stroke="#8b7355"
        strokeWidth="1.5"
      />

      {/* Blue Zone Region - Ogliastra/Barbagia (mountainous interior) */}
      <path
        d="M85 95
           C92 92 100 94 108 98
           L118 105 C124 110 128 118 130 126
           L132 138 C132 148 130 158 126 166
           L120 176 C114 184 106 190 98 192
           L88 193 C80 192 72 188 66 182
           L60 174 C56 166 54 156 54 146
           L56 134 C58 124 62 114 68 106
           L78 98 C80 96 82 95 85 95
           Z"
        fill="#7fa8b8"
        fillOpacity="0.4"
        stroke="#5a8a9a"
        strokeWidth="1"
        strokeDasharray="3,2"
      />

      {/* Blue Zone Label */}
      <text
        x="93"
        y="145"
        textAnchor="middle"
        fontSize="8"
        fill="#3d6a7a"
        fontWeight="500"
      >
        Blue Zone
      </text>

      {/* Key cities - small dots */}
      {/* Cagliari (south) */}
      <circle cx="95" cy="245" r="3" fill="#d97459" />
      <text x="105" y="248" fontSize="7" fill="#666">Cagliari</text>

      {/* Sassari (north) */}
      <circle cx="55" cy="45" r="2.5" fill="#8b7355" />
      <text x="62" y="48" fontSize="6" fill="#666">Sassari</text>

      {/* Nuoro (Blue Zone) */}
      <circle cx="98" cy="130" r="2.5" fill="#5a8a9a" />
      <text x="105" y="133" fontSize="6" fill="#3d6a7a">Nuoro</text>

      {/* Olbia (northeast) */}
      <circle cx="145" cy="55" r="2" fill="#8b7355" />
      <text x="127" y="52" fontSize="6" fill="#666">Olbia</text>

      {/* Oristano (west) */}
      <circle cx="45" cy="145" r="2" fill="#8b7355" />
      <text x="25" y="148" fontSize="6" fill="#666">Oristano</text>

      {/* Legend */}
      <g transform="translate(10, 255)">
        <rect x="0" y="0" width="8" height="8" fill="#7fa8b8" fillOpacity="0.4" stroke="#5a8a9a" strokeWidth="0.5" />
        <text x="12" y="7" fontSize="6" fill="#666">Blue Zone (Ogliastra/Barbagia)</text>
      </g>
    </svg>
  );
}

export default SardiniaMapSVG;
