'use client';

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  ReferenceLine,
  ReferenceDot,
} from 'recharts';
import { TrendingUp, Flag } from 'lucide-react';
import type { EnrollmentTrend, EnrollmentMilestone } from '@/lib/saba/types';

interface EnrollmentChartProps {
  trends: EnrollmentTrend[];
  milestones: EnrollmentMilestone[];
}

export default function EnrollmentChart({ trends, milestones }: EnrollmentChartProps) {
  // Find milestone data points for reference dots
  const milestonePoints = milestones
    .filter((m) => m.type === 'milestone' || m.type === 'centenarian')
    .map((m) => {
      const trend = trends.find((t) => t.date === m.date) ||
                   trends.reduce((prev, curr) =>
                     Math.abs(curr.cumulative - m.count) < Math.abs(prev.cumulative - m.count) ? curr : prev
                   );
      return { ...m, cumulative: trend?.cumulative || m.count };
    });

  const chartData = trends.map((t) => ({
    ...t,
    displayDate: new Date(t.date).toLocaleDateString('en-US', { month: 'short', year: '2-digit' }),
  }));

  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Enrollment Timeline</h3>
          <p className="text-sm text-muted-foreground">Cumulative participant enrollment since study launch</p>
        </div>
      </div>

      <div className="h-80">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={chartData} margin={{ top: 20, right: 30, left: 10, bottom: 10 }}>
            <defs>
              <linearGradient id="enrollmentGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(25 38% 67%)" stopOpacity={0.3} />
                <stop offset="95%" stopColor="hsl(25 38% 67%)" stopOpacity={0} />
              </linearGradient>
            </defs>
            <XAxis
              dataKey="displayDate"
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: 'hsl(33 27% 26%)' }}
              interval="preserveStartEnd"
            />
            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fontSize: 12, fill: 'hsl(33 27% 26%)' }}
              tickFormatter={(value) => value.toLocaleString()}
            />
            <Tooltip
              contentStyle={{
                backgroundColor: 'rgba(255, 255, 255, 0.95)',
                border: 'none',
                borderRadius: '12px',
                boxShadow: '0 4px 20px rgba(0, 0, 0, 0.1)',
                padding: '12px 16px',
              }}
              labelStyle={{ color: 'hsl(33 27% 26%)', fontWeight: 600, marginBottom: '4px' }}
              formatter={(value: number, name: string) => [
                name === 'cumulative'
                  ? `${value.toLocaleString()} total participants`
                  : `${value} new this week`,
                '',
              ]}
            />
            <Line
              type="monotone"
              dataKey="cumulative"
              stroke="hsl(25 38% 67%)"
              strokeWidth={3}
              dot={false}
              fill="url(#enrollmentGradient)"
            />
            {/* Milestone markers would go here */}
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Milestones legend */}
      <div className="mt-6 border-t border-white/20 pt-4">
        <h4 className="text-sm font-medium text-foreground mb-3 flex items-center gap-2">
          <Flag className="w-4 h-4 text-primary" />
          Key Milestones
        </h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {milestones
            .filter((m) => m.type === 'milestone' || m.type === 'centenarian')
            .slice(-4)
            .map((milestone) => (
              <div
                key={milestone.date}
                className={`p-3 rounded-lg border ${
                  milestone.type === 'centenarian'
                    ? 'bg-success-light/50 border-green-200'
                    : 'bg-white/30 border-white/40'
                }`}
              >
                <p className="text-xs text-muted-foreground">
                  {new Date(milestone.date).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                </p>
                <p className={`text-sm font-medium ${milestone.type === 'centenarian' ? 'text-green-700' : 'text-foreground'}`}>
                  {milestone.label}
                </p>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
