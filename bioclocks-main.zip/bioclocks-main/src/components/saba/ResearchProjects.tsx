'use client';

import { Beaker, Building2, Calendar, BookOpen, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import type { ResearchProject, AccessTier } from '@/lib/saba/types';

interface ResearchProjectsProps {
  projects: ResearchProject[];
}

const STATUS_CONFIG = {
  active: {
    label: 'Active',
    icon: Clock,
    class: 'bg-blue-100 text-blue-700',
  },
  completed: {
    label: 'Completed',
    icon: CheckCircle,
    class: 'bg-green-100 text-green-700',
  },
  pending: {
    label: 'Pending',
    icon: AlertCircle,
    class: 'bg-amber-100 text-amber-700',
  },
};

const TIER_COLORS = {
  public: 'bg-gray-100 text-gray-700',
  registered: 'bg-blue-100 text-blue-700',
  controlled: 'bg-purple-100 text-purple-700',
  collaborative: 'bg-emerald-100 text-emerald-700',
};

export default function ResearchProjects({ projects }: ResearchProjectsProps) {
  const activeCount = projects.filter((p) => p.status === 'active').length;
  const completedCount = projects.filter((p) => p.status === 'completed').length;
  const totalPublications = projects.reduce((sum, p) => sum + (p.publications || 0), 0);

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Beaker className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Research Projects</h3>
            <p className="text-sm text-muted-foreground">
              Active collaborations using SABA data
            </p>
          </div>
        </div>
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-xl bg-blue-50 border border-blue-100 text-center">
          <p className="text-2xl font-bold text-blue-700">{activeCount}</p>
          <p className="text-xs text-blue-600">Active Projects</p>
        </div>
        <div className="p-4 rounded-xl bg-green-50 border border-green-100 text-center">
          <p className="text-2xl font-bold text-green-700">{completedCount}</p>
          <p className="text-xs text-green-600">Completed</p>
        </div>
        <div className="p-4 rounded-xl bg-purple-50 border border-purple-100 text-center">
          <p className="text-2xl font-bold text-purple-700">{totalPublications}</p>
          <p className="text-xs text-purple-600">Publications</p>
        </div>
      </div>

      {/* Project cards */}
      <div className="space-y-4">
        {projects.map((project) => {
          const statusConfig = STATUS_CONFIG[project.status];
          const StatusIcon = statusConfig.icon;

          return (
            <div
              key={project.id}
              className="p-5 rounded-xl bg-white/30 border border-white/40 hover:bg-white/40 transition-colors"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full flex items-center gap-1 ${statusConfig.class}`}>
                      <StatusIcon className="w-3 h-3" />
                      {statusConfig.label}
                    </span>
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${TIER_COLORS[project.tier]}`}>
                      {project.tier.charAt(0).toUpperCase() + project.tier.slice(1)}
                    </span>
                  </div>
                  <h4 className="font-semibold text-foreground mb-2">{project.title}</h4>
                  <div className="flex flex-wrap gap-4 text-sm">
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Building2 className="w-4 h-4" />
                      {project.institution}
                    </div>
                    <div className="flex items-center gap-1.5 text-muted-foreground">
                      <Calendar className="w-4 h-4" />
                      Started {new Date(project.startDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                    </div>
                    {project.publications !== undefined && project.publications > 0 && (
                      <div className="flex items-center gap-1.5 text-success">
                        <BookOpen className="w-4 h-4" />
                        {project.publications} publication{project.publications > 1 ? 's' : ''}
                      </div>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground mb-1">PI</p>
                  <p className="text-sm font-medium text-foreground">{project.principalInvestigator}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Call to action */}
      <div className="mt-6 p-5 rounded-xl bg-gradient-to-r from-primary/10 to-purple-500/10 border border-primary/20">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-semibold text-foreground mb-1">Interested in collaborating?</h4>
            <p className="text-sm text-muted-foreground">
              Submit a research proposal to access SABA data for your study
            </p>
          </div>
          <button className="btn-primary">
            Apply for Access
          </button>
        </div>
      </div>
    </div>
  );
}
