'use client';

import Link from 'next/link';
import Image from 'next/image';
import { useLanguage } from '@/lib/saba/language-context';

interface NuraxiHeaderProps {
  activePage: 'public' | 'science' | 'research';
}

export function NuraxiHeader({ activePage }: NuraxiHeaderProps) {
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="fixed top-0 left-0 right-0 z-50 px-4 py-4">
      <div className="max-w-6xl mx-auto">
        <div className="bg-white/95 backdrop-blur-sm rounded-full px-6 py-3 shadow-sm border border-[#e8e4dc] flex items-center justify-between">
          {/* Logo */}
          <Link href="/saba" className="flex items-center gap-2">
            <Image
              src="/images/nuraxi_horizontal_rgb.svg"
              alt="Nuraxi"
              width={120}
              height={28}
              className="h-7 w-auto"
            />
          </Link>

          {/* Navigation */}
          <nav className="flex items-center gap-8">
            <Link
              href="/saba"
              className={`text-sm font-medium transition-colors ${
                activePage === 'public'
                  ? 'text-[#8b7355]'
                  : 'text-[#a89f91] hover:text-[#8b7355]'
              }`}
            >
              {t('nav.public')}
            </Link>
            <Link
              href="/saba/science"
              className={`text-sm font-medium transition-colors ${
                activePage === 'science'
                  ? 'text-[#8b7355]'
                  : 'text-[#a89f91] hover:text-[#8b7355]'
              }`}
            >
              {t('nav.science')}
            </Link>
            <Link
              href="/saba/research"
              className={`text-sm font-medium transition-colors ${
                activePage === 'research'
                  ? 'text-[#8b7355]'
                  : 'text-[#a89f91] hover:text-[#8b7355]'
              }`}
            >
              {t('nav.research')}
            </Link>
          </nav>

          {/* Right side: Language toggle + CTA */}
          <div className="flex items-center gap-4">
            {/* Language Toggle */}
            <div className="flex items-center bg-[#f5f3ed] rounded-full p-0.5">
              <button
                onClick={() => setLanguage('en')}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                  language === 'en'
                    ? 'bg-white text-[#8b7355] shadow-sm'
                    : 'text-[#a89f91] hover:text-[#8b7355]'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('it')}
                className={`px-3 py-1 text-xs font-medium rounded-full transition-colors ${
                  language === 'it'
                    ? 'bg-white text-[#8b7355] shadow-sm'
                    : 'text-[#a89f91] hover:text-[#8b7355]'
                }`}
              >
                IT
              </button>
            </div>

            {/* CTA Button */}
            <Link
              href="/saba"
              className="bg-[#c9a86c] hover:bg-[#b89a5e] text-white text-sm font-medium px-5 py-2 rounded-full transition-colors"
            >
              {t('nav.sabaStudy')}
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
}

export default NuraxiHeader;
