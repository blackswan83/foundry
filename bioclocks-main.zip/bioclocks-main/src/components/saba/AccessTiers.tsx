'use client';

import { useState } from 'react';
import { Globe, UserCheck, Shield, Handshake, ChevronRight, Clock, Euro, CheckCircle } from 'lucide-react';
import type { AccessTierInfo } from '@/lib/saba/types';

interface AccessTiersProps {
  tiers: AccessTierInfo[];
}

const TIER_ICONS = {
  public: Globe,
  registered: UserCheck,
  controlled: Shield,
  collaborative: Handshake,
};

const TIER_COLORS = {
  public: {
    bg: 'bg-gray-100',
    border: 'border-gray-300',
    text: 'text-gray-700',
    accent: 'bg-gray-500',
  },
  registered: {
    bg: 'bg-blue-50',
    border: 'border-blue-300',
    text: 'text-blue-700',
    accent: 'bg-blue-500',
  },
  controlled: {
    bg: 'bg-purple-50',
    border: 'border-purple-300',
    text: 'text-purple-700',
    accent: 'bg-purple-500',
  },
  collaborative: {
    bg: 'bg-emerald-50',
    border: 'border-emerald-300',
    text: 'text-emerald-700',
    accent: 'bg-emerald-500',
  },
};

export default function AccessTiers({ tiers }: AccessTiersProps) {
  const [selectedTier, setSelectedTier] = useState<AccessTierInfo | null>(null);

  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <Shield className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Data Access Tiers</h3>
          <p className="text-sm text-muted-foreground">
            Four-tier access system based on UK Biobank model
          </p>
        </div>
      </div>

      {/* Tier cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {tiers.map((tier, index) => {
          const Icon = TIER_ICONS[tier.tier];
          const colors = TIER_COLORS[tier.tier];
          const isSelected = selectedTier?.tier === tier.tier;

          return (
            <button
              key={tier.tier}
              onClick={() => setSelectedTier(isSelected ? null : tier)}
              className={`p-5 rounded-xl border-2 text-left transition-all ${
                isSelected
                  ? `${colors.border} ${colors.bg} shadow-lg`
                  : 'border-white/40 bg-white/30 hover:bg-white/50'
              }`}
            >
              {/* Tier indicator */}
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-lg ${colors.bg} flex items-center justify-center`}>
                  <Icon className={`w-5 h-5 ${colors.text}`} />
                </div>
                <div className={`w-6 h-6 rounded-full ${colors.accent} flex items-center justify-center text-white text-xs font-bold`}>
                  {index + 1}
                </div>
              </div>

              <h4 className="font-semibold text-foreground mb-1">{tier.name}</h4>
              <p className="text-xs text-muted-foreground mb-3 line-clamp-2">{tier.description}</p>

              {/* Quick info */}
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-xs">
                  <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-muted-foreground">{tier.estimatedTimeline}</span>
                </div>
                {tier.cost && (
                  <div className="flex items-center gap-2 text-xs">
                    <Euro className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className={tier.cost === 'Free' ? 'text-success' : 'text-foreground'}>{tier.cost}</span>
                  </div>
                )}
              </div>

              <div className={`mt-3 text-xs font-medium ${colors.text} flex items-center gap-1`}>
                {isSelected ? 'Hide details' : 'View details'}
                <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isSelected ? 'rotate-90' : ''}`} />
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected tier details */}
      {selectedTier && (
        <div className={`p-6 rounded-xl ${TIER_COLORS[selectedTier.tier].bg} border ${TIER_COLORS[selectedTier.tier].border}`}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Requirements */}
            <div>
              <h5 className="font-medium text-foreground mb-3 flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-muted-foreground" />
                Requirements
              </h5>
              <ul className="space-y-2">
                {selectedTier.requirements.map((req, idx) => (
                  <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-primary mt-1">•</span>
                    {req}
                  </li>
                ))}
              </ul>
            </div>

            {/* Data Access */}
            <div>
              <h5 className="font-medium text-foreground mb-3 flex items-center gap-2">
                <Shield className="w-4 h-4 text-muted-foreground" />
                Data Access
              </h5>
              <ul className="space-y-2">
                {selectedTier.dataAccess.map((data, idx) => (
                  <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-success mt-1">✓</span>
                    {data}
                  </li>
                ))}
              </ul>
            </div>

            {/* Process */}
            <div>
              <h5 className="font-medium text-foreground mb-3 flex items-center gap-2">
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
                Process
              </h5>
              <ol className="space-y-2">
                {selectedTier.process.map((step, idx) => (
                  <li key={idx} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="w-5 h-5 rounded-full bg-primary/20 text-primary text-xs flex items-center justify-center flex-shrink-0">
                      {idx + 1}
                    </span>
                    {step}
                  </li>
                ))}
              </ol>
            </div>
          </div>
        </div>
      )}

      {/* Comparison note */}
      <div className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-100">
        <p className="text-sm text-blue-800">
          <span className="font-semibold">Based on UK Biobank model:</span> Our tiered access system follows international best practices
          with a <span className="font-semibold">99% approval rate</span> for qualified research applications.
          Average processing time: <span className="font-semibold">4-8 weeks</span> for controlled access.
        </p>
      </div>
    </div>
  );
}
