'use client';

import { useState } from 'react';
import { ChevronLeft, ChevronRight, Lightbulb, Heart, Moon, Users, Utensils, Activity } from 'lucide-react';
import type { AggregateFinding } from '@/lib/saba/types';

interface FindingsCarouselProps {
  findings: AggregateFinding[];
}

const CATEGORY_CONFIG = {
  lifestyle: { icon: Activity, color: 'bg-blue-500/10 text-blue-600 border-blue-500/30' },
  biomarker: { icon: Heart, color: 'bg-red-500/10 text-red-600 border-red-500/30' },
  circadian: { icon: Moon, color: 'bg-purple-500/10 text-purple-600 border-purple-500/30' },
  social: { icon: Users, color: 'bg-emerald-500/10 text-emerald-600 border-emerald-500/30' },
  dietary: { icon: Utensils, color: 'bg-amber-500/10 text-amber-600 border-amber-500/30' },
};

const SIGNIFICANCE_BADGES = {
  preliminary: { label: 'Preliminary', class: 'bg-gray-100 text-gray-600' },
  significant: { label: 'Significant', class: 'bg-blue-100 text-blue-700' },
  validated: { label: 'Validated', class: 'bg-green-100 text-green-700' },
};

export default function FindingsCarousel({ findings }: FindingsCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);

  const goToPrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? findings.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentIndex((prev) => (prev === findings.length - 1 ? 0 : prev + 1));
  };

  const currentFinding = findings[currentIndex];
  const CategoryIcon = CATEGORY_CONFIG[currentFinding.category]?.icon || Lightbulb;
  const categoryColor = CATEGORY_CONFIG[currentFinding.category]?.color || 'bg-primary/10 text-primary border-primary/30';
  const significanceBadge = SIGNIFICANCE_BADGES[currentFinding.significance];

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Lightbulb className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Emerging Patterns</h3>
            <p className="text-sm text-muted-foreground">Anonymized aggregate findings</p>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center gap-2">
          <button
            onClick={goToPrevious}
            className="w-8 h-8 rounded-full bg-white/40 border border-white/40 flex items-center justify-center hover:bg-white/60 transition-colors"
          >
            <ChevronLeft className="w-4 h-4 text-foreground" />
          </button>
          <span className="text-sm text-muted-foreground min-w-[3rem] text-center">
            {currentIndex + 1} / {findings.length}
          </span>
          <button
            onClick={goToNext}
            className="w-8 h-8 rounded-full bg-white/40 border border-white/40 flex items-center justify-center hover:bg-white/60 transition-colors"
          >
            <ChevronRight className="w-4 h-4 text-foreground" />
          </button>
        </div>
      </div>

      {/* Finding card */}
      <div className="p-6 rounded-xl bg-white/30 border border-white/40">
        <div className="flex items-start gap-4">
          <div className={`w-12 h-12 rounded-xl border flex items-center justify-center flex-shrink-0 ${categoryColor}`}>
            <CategoryIcon className="w-6 h-6" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${significanceBadge.class}`}>
                {significanceBadge.label}
              </span>
              <span className="text-xs text-muted-foreground capitalize">
                {currentFinding.category}
              </span>
            </div>
            <h4 className="text-lg font-semibold text-foreground mb-2">
              {currentFinding.title}
            </h4>
            <p className="text-sm text-muted-foreground mb-4">
              {currentFinding.description}
            </p>

            {/* Key metric */}
            <div className="flex items-center justify-between p-3 rounded-lg bg-success-light/50 border border-green-200">
              <div>
                <p className="text-2xl font-bold text-success">{currentFinding.metric}</p>
                <p className="text-xs text-green-700">vs. {currentFinding.comparisonGroup}</p>
              </div>
              <span className="text-xs text-muted-foreground">
                Published {new Date(currentFinding.publishedDate).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Dots indicator */}
      <div className="flex items-center justify-center gap-2 mt-4">
        {findings.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`w-2 h-2 rounded-full transition-all ${
              index === currentIndex
                ? 'bg-primary w-6'
                : 'bg-primary/30 hover:bg-primary/50'
            }`}
          />
        ))}
      </div>
    </div>
  );
}
