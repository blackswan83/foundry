'use client';

import { useState } from 'react';
import { Database, Search, Filter, Download, ChevronDown, Lock, Unlock, FileText } from 'lucide-react';
import type { DataCatalogEntry, DataCategory, AccessTier } from '@/lib/saba/types';

interface DataCatalogProps {
  categories: DataCategory[];
  entries: DataCatalogEntry[];
}

const TIER_BADGES = {
  public: { label: 'Public', class: 'bg-gray-100 text-gray-700' },
  registered: { label: 'Registered', class: 'bg-blue-100 text-blue-700' },
  controlled: { label: 'Controlled', class: 'bg-purple-100 text-purple-700' },
  collaborative: { label: 'Collaborative', class: 'bg-emerald-100 text-emerald-700' },
};

const TYPE_LABELS = {
  continuous: 'Numeric',
  categorical: 'Categorical',
  binary: 'Binary',
  date: 'Date',
  text: 'Text',
};

export default function DataCatalog({ categories, entries }: DataCatalogProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedTier, setSelectedTier] = useState<AccessTier | null>(null);

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      searchQuery === '' ||
      entry.variableName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = !selectedCategory || entry.category.toLowerCase().includes(selectedCategory.toLowerCase());
    const matchesTier = !selectedTier || entry.tier === selectedTier;
    return matchesSearch && matchesCategory && matchesTier;
  });

  const totalVariables = categories.reduce((sum, c) => sum + c.variableCount, 0);

  return (
    <div className="card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <Database className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground">Data Catalog</h3>
            <p className="text-sm text-muted-foreground">
              {totalVariables.toLocaleString()} variables across {categories.length} categories
            </p>
          </div>
        </div>

        <button className="btn-secondary flex items-center gap-2">
          <Download className="w-4 h-4" />
          Download Dictionary
        </button>
      </div>

      {/* Category overview */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {categories.map((category) => (
          <button
            key={category.id}
            onClick={() => setSelectedCategory(selectedCategory === category.id ? null : category.id)}
            className={`p-3 rounded-xl border transition-all text-left ${
              selectedCategory === category.id
                ? 'border-primary bg-primary/10'
                : 'border-white/40 bg-white/30 hover:bg-white/50'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-lg font-bold text-foreground">{category.variableCount}</span>
              {selectedCategory === category.id && (
                <ChevronDown className="w-4 h-4 text-primary" />
              )}
            </div>
            <p className="text-xs font-medium text-foreground truncate">{category.name}</p>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-3 mb-6">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search variables..."
            className="input-field pl-10"
          />
        </div>
        <div className="flex gap-2">
          {(['public', 'registered', 'controlled', 'collaborative'] as AccessTier[]).map((tier) => (
            <button
              key={tier}
              onClick={() => setSelectedTier(selectedTier === tier ? null : tier)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                selectedTier === tier
                  ? TIER_BADGES[tier].class + ' ring-2 ring-offset-2 ring-primary/30'
                  : 'bg-white/40 text-muted-foreground hover:bg-white/60'
              }`}
            >
              {TIER_BADGES[tier].label}
            </button>
          ))}
        </div>
      </div>

      {/* Variable table */}
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/20">
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Variable</th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Category</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Type</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">N</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Completeness</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Access</th>
            </tr>
          </thead>
          <tbody>
            {filteredEntries.map((entry) => (
              <tr key={entry.variableId} className="border-b border-white/10 hover:bg-white/10 transition-colors">
                <td className="py-3 px-4">
                  <p className="font-medium text-foreground">{entry.variableName}</p>
                  <p className="text-xs text-muted-foreground">{entry.description}</p>
                  {entry.unit && (
                    <p className="text-xs text-muted-foreground mt-1">Unit: {entry.unit}</p>
                  )}
                </td>
                <td className="py-3 px-4 text-sm text-muted-foreground">{entry.category}</td>
                <td className="py-3 px-4 text-center">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-white/40 text-foreground">
                    {TYPE_LABELS[entry.dataType]}
                  </span>
                </td>
                <td className="py-3 px-4 text-center text-sm text-foreground">
                  {entry.sampleSize.toLocaleString()}
                </td>
                <td className="py-3 px-4 text-center">
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-16 h-2 bg-white/30 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${entry.completeness >= 90 ? 'bg-success' : entry.completeness >= 70 ? 'bg-warning' : 'bg-error'}`}
                        style={{ width: `${entry.completeness}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground">{entry.completeness}%</span>
                  </div>
                </td>
                <td className="py-3 px-4 text-center">
                  <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${TIER_BADGES[entry.tier].class}`}>
                    {entry.tier === 'controlled' || entry.tier === 'collaborative' ? (
                      <Lock className="w-3 h-3 inline mr-1" />
                    ) : (
                      <Unlock className="w-3 h-3 inline mr-1" />
                    )}
                    {TIER_BADGES[entry.tier].label}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {filteredEntries.length === 0 && (
        <div className="text-center py-12">
          <FileText className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">No variables match your search criteria</p>
        </div>
      )}

      {/* Info note */}
      <div className="mt-6 p-4 rounded-xl bg-white/20 border border-white/30">
        <p className="text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Data Quality:</span> All variables undergo rigorous quality control.
          Completeness indicates the percentage of participants with valid data for each variable.
          Variables with &lt;70% completeness are flagged for review.
        </p>
      </div>
    </div>
  );
}
