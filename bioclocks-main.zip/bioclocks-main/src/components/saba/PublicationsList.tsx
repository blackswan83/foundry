'use client';

import { BookOpen, ExternalLink, Award, Users } from 'lucide-react';
import type { Publication, TeamMember, AdvisoryBoardMember } from '@/lib/saba/types';

interface PublicationsListProps {
  publications: Publication[];
  team?: TeamMember[];
  advisoryBoard?: AdvisoryBoardMember[];
}

const CATEGORY_COLORS = {
  methodology: 'bg-purple-100 text-purple-700',
  validation: 'bg-blue-100 text-blue-700',
  findings: 'bg-green-100 text-green-700',
  review: 'bg-amber-100 text-amber-700',
};

export default function PublicationsList({ publications, team, advisoryBoard }: PublicationsListProps) {
  const totalCitations = publications.reduce((sum, p) => sum + (p.citations || 0), 0);

  return (
    <div className="space-y-6">
      {/* Publications */}
      <div className="card p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-500/10 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-foreground">Publications</h3>
              <p className="text-sm text-muted-foreground">
                {publications.length} peer-reviewed papers • {totalCitations} total citations
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {publications.map((pub) => (
            <div
              key={pub.id}
              className="p-4 rounded-xl bg-white/30 border border-white/40 hover:bg-white/40 transition-colors group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${CATEGORY_COLORS[pub.category]}`}>
                      {pub.category.charAt(0).toUpperCase() + pub.category.slice(1)}
                    </span>
                    <span className="text-xs text-muted-foreground">{pub.year}</span>
                  </div>
                  <h4 className="font-medium text-foreground mb-1 group-hover:text-primary transition-colors">
                    {pub.title}
                  </h4>
                  <p className="text-sm text-muted-foreground mb-2">{pub.authors}</p>
                  <div className="flex items-center gap-4 text-xs">
                    <span className="font-medium text-foreground">{pub.journal}</span>
                    {pub.impactFactor && (
                      <span className="text-muted-foreground">IF: {pub.impactFactor}</span>
                    )}
                    {pub.citations !== undefined && (
                      <span className="text-muted-foreground">{pub.citations} citations</span>
                    )}
                  </div>
                </div>
                <a
                  href={`https://doi.org/${pub.doi}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-sm text-primary hover:underline flex-shrink-0"
                >
                  <ExternalLink className="w-4 h-4" />
                  DOI
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Team & Advisory Board */}
      {(team || advisoryBoard) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Core Team */}
          {team && (
            <div className="card p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Users className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Core Team</h3>
                  <p className="text-sm text-muted-foreground">Study leadership</p>
                </div>
              </div>

              <div className="space-y-4">
                {team.map((member) => (
                  <div key={member.name} className="flex items-start gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center flex-shrink-0">
                      <span className="text-sm font-semibold text-primary">
                        {member.name.split(' ').map((n) => n[0]).join('')}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{member.name}</p>
                      <p className="text-sm text-muted-foreground">{member.role}</p>
                      <p className="text-xs text-muted-foreground">{member.affiliation}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Advisory Board */}
          {advisoryBoard && (
            <div className="card p-6">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-amber-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-foreground">Scientific Advisory Board</h3>
                  <p className="text-sm text-muted-foreground">World-leading experts</p>
                </div>
              </div>

              <div className="space-y-4">
                {advisoryBoard.map((advisor) => (
                  <div key={advisor.name} className="p-3 rounded-lg bg-white/20 border border-white/30">
                    <p className="font-medium text-foreground">{advisor.name}</p>
                    <p className="text-sm text-muted-foreground">{advisor.title}</p>
                    <p className="text-xs text-muted-foreground mb-2">{advisor.affiliation}</p>
                    <div className="flex flex-wrap gap-1">
                      {advisor.notableAchievements.slice(0, 2).map((achievement, idx) => (
                        <span
                          key={idx}
                          className="text-xs px-2 py-0.5 rounded-full bg-amber-100 text-amber-700"
                        >
                          {achievement}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
