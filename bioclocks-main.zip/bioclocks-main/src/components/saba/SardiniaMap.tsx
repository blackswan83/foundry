'use client';

import { useState } from 'react';
import { MapPin, Star } from 'lucide-react';
import type { CommuneData } from '@/lib/saba/types';

interface SardiniaMapProps {
  communes: CommuneData[];
}

function getDensityColor(count: number, isBlueZone: boolean): string {
  if (isBlueZone) {
    if (count >= 160) return 'fill-emerald-500';
    if (count >= 120) return 'fill-emerald-400';
    if (count >= 80) return 'fill-emerald-300';
    return 'fill-emerald-200';
  } else {
    if (count >= 280) return 'fill-primary';
    if (count >= 200) return 'fill-primary/80';
    if (count >= 140) return 'fill-primary/60';
    return 'fill-primary/40';
  }
}

export default function SardiniaMap({ communes }: SardiniaMapProps) {
  const [hoveredCommune, setHoveredCommune] = useState<CommuneData | null>(null);

  const blueZoneCommunes = communes.filter((c) => c.isBlueZone);
  const otherCommunes = communes.filter((c) => !c.isBlueZone);
  const totalBlueZoneEnrollment = blueZoneCommunes.reduce((sum, c) => sum + c.enrollmentCount, 0);
  const totalOtherEnrollment = otherCommunes.reduce((sum, c) => sum + c.enrollmentCount, 0);

  // Normalize coordinates to SVG viewBox
  const normalizeCoord = (lat: number, lng: number) => {
    // Sardinia approximate bounds
    const minLat = 38.8, maxLat = 41.3;
    const minLng = 8.1, maxLng = 9.9;

    const x = ((lng - minLng) / (maxLng - minLng)) * 380 + 10;
    const y = ((maxLat - lat) / (maxLat - minLat)) * 480 + 10;

    return { x, y };
  };

  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <MapPin className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Geographic Coverage</h3>
          <p className="text-sm text-muted-foreground">Enrollment across Sardinian communes</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Map SVG */}
        <div className="lg:col-span-2 relative">
          <svg viewBox="0 0 400 500" className="w-full h-auto max-h-96">
            {/* Simplified Sardinia outline */}
            <path
              d="M180 20 L240 30 L280 60 L320 100 L350 160 L370 220 L380 300 L370 360 L340 420 L280 460 L220 480 L160 470 L100 440 L60 380 L40 300 L30 220 L50 140 L80 80 L120 40 Z"
              fill="hsl(44 45% 90%)"
              stroke="hsl(25 38% 67%)"
              strokeWidth="2"
            />

            {/* Province regions (simplified) */}
            <path
              d="M160 200 L220 180 L260 220 L240 280 L180 300 L140 260 Z"
              fill="hsl(142 40% 90%)"
              stroke="hsl(142 40% 60%)"
              strokeWidth="1"
              strokeDasharray="4,2"
              opacity="0.5"
            />
            <text x="195" y="245" fontSize="10" fill="hsl(142 40% 40%)" textAnchor="middle" fontWeight="500">
              Blue Zone
            </text>

            {/* Commune markers */}
            {communes.map((commune) => {
              const { x, y } = normalizeCoord(commune.coordinates.lat, commune.coordinates.lng);
              const size = commune.isBlueZone ? 8 : 6;

              return (
                <g
                  key={commune.name}
                  onMouseEnter={() => setHoveredCommune(commune)}
                  onMouseLeave={() => setHoveredCommune(null)}
                  className="cursor-pointer"
                >
                  <circle
                    cx={x}
                    cy={y}
                    r={size + 4}
                    fill="transparent"
                  />
                  <circle
                    cx={x}
                    cy={y}
                    r={size}
                    className={`${getDensityColor(commune.enrollmentCount, commune.isBlueZone)} transition-all duration-200`}
                    stroke={commune.isBlueZone ? 'hsl(142 69% 45%)' : 'hsl(25 38% 52%)'}
                    strokeWidth={commune.isBlueZone ? 2 : 1}
                    opacity={hoveredCommune === commune ? 1 : 0.85}
                  />
                  {commune.isBlueZone && (
                    <circle
                      cx={x}
                      cy={y}
                      r={size + 3}
                      fill="none"
                      stroke="hsl(142 69% 45%)"
                      strokeWidth="1"
                      strokeDasharray="2,2"
                      opacity="0.5"
                    />
                  )}
                </g>
              );
            })}
          </svg>

          {/* Tooltip */}
          {hoveredCommune && (
            <div className="absolute top-4 left-4 bg-white/95 backdrop-blur-sm rounded-lg shadow-lg p-3 border border-white/40 max-w-48">
              <div className="flex items-center gap-2 mb-1">
                {hoveredCommune.isBlueZone && <Star className="w-4 h-4 text-success" />}
                <p className="font-semibold text-foreground">{hoveredCommune.name}</p>
              </div>
              <p className="text-xs text-muted-foreground mb-2">{hoveredCommune.province}</p>
              <div className="space-y-1">
                <p className="text-sm">
                  <span className="text-muted-foreground">Enrolled:</span>{' '}
                  <span className="font-medium">{hoveredCommune.enrollmentCount}+</span>
                </p>
                {hoveredCommune.centenarianRate && (
                  <p className="text-sm">
                    <span className="text-muted-foreground">Centenarian rate:</span>{' '}
                    <span className="font-medium text-success">{hoveredCommune.centenarianRate}/10k</span>
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Legend and stats */}
        <div className="space-y-4">
          {/* Blue Zone highlight */}
          <div className="p-4 rounded-xl bg-success-light/50 border border-green-200">
            <div className="flex items-center gap-2 mb-2">
              <Star className="w-5 h-5 text-success" />
              <h4 className="font-semibold text-green-800">Blue Zone Communes</h4>
            </div>
            <p className="text-3xl font-bold text-success mb-1">
              {totalBlueZoneEnrollment.toLocaleString()}+
            </p>
            <p className="text-sm text-green-700">
              participants from {blueZoneCommunes.length} traditional Blue Zone villages
            </p>
          </div>

          {/* Comparison regions */}
          <div className="p-4 rounded-xl bg-white/30 border border-white/40">
            <h4 className="font-semibold text-foreground mb-2">Comparison Regions</h4>
            <p className="text-2xl font-bold text-foreground mb-1">
              {totalOtherEnrollment.toLocaleString()}+
            </p>
            <p className="text-sm text-muted-foreground">
              participants from {otherCommunes.length} urban and coastal areas
            </p>
          </div>

          {/* Legend */}
          <div className="p-4 rounded-xl bg-white/20 border border-white/30">
            <h4 className="text-sm font-medium text-foreground mb-3">Enrollment Density</h4>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-emerald-500 border-2 border-emerald-600" />
                <span className="text-xs text-muted-foreground">Blue Zone (high)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-emerald-300 border border-emerald-400" />
                <span className="text-xs text-muted-foreground">Blue Zone (moderate)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-primary" />
                <span className="text-xs text-muted-foreground">Urban/Comparison (high)</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-full bg-primary/40" />
                <span className="text-xs text-muted-foreground">Urban/Comparison (moderate)</span>
              </div>
            </div>
          </div>

          {/* Privacy note */}
          <p className="text-xs text-muted-foreground italic">
            All counts rounded to nearest 20 for privacy protection.
          </p>
        </div>
      </div>
    </div>
  );
}
