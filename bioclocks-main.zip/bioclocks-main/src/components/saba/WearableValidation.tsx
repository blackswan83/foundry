'use client';

import { Watch, CheckCircle, ExternalLink } from 'lucide-react';
import type { WearableValidation as WearableValidationType, PopulationNorm } from '@/lib/saba/types';

interface WearableValidationProps {
  validations: WearableValidationType[];
  norms: PopulationNorm[];
}

export default function WearableValidation({ validations, norms }: WearableValidationProps) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
          <Watch className="w-5 h-5 text-blue-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Wearable Data Validation</h3>
          <p className="text-sm text-muted-foreground">
            Accuracy metrics against gold-standard measurements
          </p>
        </div>
      </div>

      {/* Validation table */}
      <div className="overflow-x-auto mb-6">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/20">
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Metric</th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Device</th>
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Gold Standard</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Correlation</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Bland-Altman Bias</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">n</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Source</th>
            </tr>
          </thead>
          <tbody>
            {validations.map((validation, idx) => (
              <tr key={idx} className="border-b border-white/10 hover:bg-white/10 transition-colors">
                <td className="py-3 px-4 font-medium text-foreground">{validation.metric}</td>
                <td className="py-3 px-4 text-sm text-muted-foreground">{validation.deviceType}</td>
                <td className="py-3 px-4 text-sm text-muted-foreground">{validation.goldStandard}</td>
                <td className="py-3 px-4 text-center">
                  <span className={`font-semibold ${validation.correlation >= 0.9 ? 'text-success' : 'text-foreground'}`}>
                    r = {validation.correlation.toFixed(3)}
                  </span>
                </td>
                <td className="py-3 px-4 text-center text-sm">
                  <span className="text-foreground">{validation.blandAltmanBias.toFixed(1)}</span>
                  <span className="text-muted-foreground text-xs block">
                    [{validation.limitsOfAgreement.lower.toFixed(1)}, {validation.limitsOfAgreement.upper.toFixed(1)}]
                  </span>
                </td>
                <td className="py-3 px-4 text-center text-sm text-muted-foreground">{validation.sampleSize}</td>
                <td className="py-3 px-4 text-center">
                  {validation.publication ? (
                    <span className="text-xs text-blue-600 font-medium">{validation.publication}</span>
                  ) : (
                    <span className="text-xs text-muted-foreground">Internal</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Validation summary cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Heart Rate Accuracy', value: 'r = 0.996', status: 'excellent' },
          { label: 'HRV Accuracy', value: 'r = 0.98', status: 'excellent' },
          { label: 'Sleep Staging', value: 'r = 0.89', status: 'good' },
          { label: 'Step Count', value: 'r = 0.994', status: 'excellent' },
        ].map((item) => (
          <div key={item.label} className="p-4 rounded-xl bg-white/30 border border-white/40 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <CheckCircle className={`w-4 h-4 ${item.status === 'excellent' ? 'text-success' : 'text-blue-500'}`} />
              <span className={`text-xs font-medium ${item.status === 'excellent' ? 'text-success' : 'text-blue-600'}`}>
                {item.status === 'excellent' ? 'Excellent' : 'Good'}
              </span>
            </div>
            <p className="text-lg font-bold text-foreground">{item.value}</p>
            <p className="text-xs text-muted-foreground">{item.label}</p>
          </div>
        ))}
      </div>

      {/* Population norms */}
      <div className="pt-6 border-t border-white/20">
        <h4 className="text-sm font-medium text-foreground mb-4">Sardinian Population Norms (HRV RMSSD)</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {norms
            .filter((n) => n.metric === 'HRV (RMSSD)')
            .map((norm) => (
              <div key={norm.ageRange} className="p-4 rounded-xl bg-white/20 border border-white/30">
                <p className="text-sm font-medium text-foreground mb-2">Age {norm.ageRange}</p>
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">5th %ile</span>
                    <span className="text-foreground">{norm.percentile5} ms</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">Median</span>
                    <span className="font-medium text-foreground">{norm.percentile50} ms</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-muted-foreground">95th %ile</span>
                    <span className="text-foreground">{norm.percentile95} ms</span>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>

      {/* Credibility note */}
      <div className="mt-6 p-4 rounded-xl bg-blue-50 border border-blue-100 flex items-start gap-3">
        <ExternalLink className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
        <div>
          <p className="text-sm font-medium text-blue-800 mb-1">Independently Validated</p>
          <p className="text-sm text-blue-700">
            All wearable metrics have been validated in peer-reviewed publications including JMIR, Sensors, and Sleep Medicine.
            Full methodology available in our published protocols.
          </p>
        </div>
      </div>
    </div>
  );
}
