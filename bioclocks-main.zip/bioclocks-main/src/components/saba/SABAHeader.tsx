'use client';

import Link from 'next/link';
import Image from 'next/image';
import { usePathname } from 'next/navigation';
import { Globe, FlaskConical, Database, ChevronRight } from 'lucide-react';

const NAV_ITEMS = [
  { href: '/saba', label: 'Public Dashboard', icon: Globe },
  { href: '/saba/science', label: 'Scientific Showcase', icon: FlaskConical },
  { href: '/saba/research', label: 'Researcher Portal', icon: Database },
];

export default function SABAHeader() {
  const pathname = usePathname();

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      {/* Gradient overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/90 via-white/80 to-transparent backdrop-blur-md" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between py-4">
          {/* Logo and title */}
          <Link href="/saba" className="flex items-center gap-3 group">
            <div className="relative w-10 h-10">
              <Image
                src="/images/nora-logo.png"
                alt="SABA Study"
                fill
                className="object-contain"
                unoptimized
              />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground group-hover:text-primary transition-colors">
                SABA Study
              </h1>
              <p className="text-xs text-muted-foreground">
                Sardinian Blue Zone Longevity Research
              </p>
            </div>
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center">
            <div className="flex items-center bg-white/60 backdrop-blur-sm rounded-full p-1 border border-white/40 shadow-sm">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = pathname === item.href;

                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-primary text-white shadow-sm'
                        : 'text-foreground hover:bg-white/60'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </nav>

          {/* CTA */}
          <div className="hidden lg:flex items-center gap-3">
            <Link
              href="/saba/research"
              className="text-sm text-primary hover:text-primary/80 font-medium flex items-center gap-1"
            >
              Access Data
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* Mobile navigation */}
        <nav className="md:hidden pb-3">
          <div className="flex items-center justify-center bg-white/60 backdrop-blur-sm rounded-full p-1 border border-white/40 shadow-sm">
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const isActive = pathname === item.href;

              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center justify-center gap-1 px-3 py-2 rounded-full text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-primary text-white shadow-sm'
                      : 'text-foreground hover:bg-white/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{item.label.split(' ')[0]}</span>
                </Link>
              );
            })}
          </div>
        </nav>
      </div>
    </header>
  );
}
