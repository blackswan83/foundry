'use client';

import { Star, Heart, Moon, Footprints, Utensils } from 'lucide-react';
import type { SuperAgerProfile } from '@/lib/saba/types';

interface SuperAgerProfilesProps {
  profiles: SuperAgerProfile[];
}

const ACTIVITY_LABELS = {
  low: { label: 'Low', color: 'text-orange-600 bg-orange-100' },
  moderate: { label: 'Moderate', color: 'text-blue-600 bg-blue-100' },
  high: { label: 'High', color: 'text-green-600 bg-green-100' },
  'very-high': { label: 'Very High', color: 'text-emerald-600 bg-emerald-100' },
};

export default function SuperAgerProfiles({ profiles }: SuperAgerProfilesProps) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400/20 to-yellow-500/20 flex items-center justify-center">
          <Star className="w-5 h-5 text-amber-600" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Super-Ager Profiles</h3>
          <p className="text-sm text-muted-foreground">
            Anonymized composite profiles of exceptional agers
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {profiles.map((profile) => {
          const activityConfig = ACTIVITY_LABELS[profile.activityLevel];

          return (
            <div
              key={profile.id}
              className="p-5 rounded-xl bg-gradient-to-br from-white/40 to-white/20 border border-white/40 hover:shadow-lg transition-shadow"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center">
                    <Star className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Age Range</p>
                    <p className="font-semibold text-foreground">{profile.ageRange}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-success">{profile.biologicalAgeGap}</p>
                  <p className="text-xs text-muted-foreground">years younger</p>
                </div>
              </div>

              {/* Key metrics */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="p-3 rounded-lg bg-white/30">
                  <div className="flex items-center gap-2 mb-1">
                    <Heart className="w-4 h-4 text-red-500" />
                    <span className="text-xs text-muted-foreground">HRV</span>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{profile.hrv.rmssd} ms</p>
                  <p className="text-xs text-success">
                    {profile.hrv.percentileVsAgeMatched}th percentile
                  </p>
                </div>
                <div className="p-3 rounded-lg bg-white/30">
                  <div className="flex items-center gap-2 mb-1">
                    <Moon className="w-4 h-4 text-indigo-500" />
                    <span className="text-xs text-muted-foreground">Sleep</span>
                  </div>
                  <p className="text-lg font-semibold text-foreground">{profile.sleepEfficiency}%</p>
                  <p className="text-xs text-muted-foreground">efficiency</p>
                </div>
              </div>

              {/* Activity level */}
              <div className="flex items-center gap-2 mb-4">
                <Footprints className="w-4 h-4 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Activity:</span>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${activityConfig.color}`}>
                  {activityConfig.label}
                </span>
              </div>

              {/* Dietary pattern */}
              <div className="flex items-center gap-2 mb-4">
                <Utensils className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{profile.dietaryPattern}</span>
              </div>

              {/* Key characteristics */}
              <div className="pt-3 border-t border-white/20">
                <p className="text-xs text-muted-foreground mb-2">Key Characteristics:</p>
                <ul className="space-y-1">
                  {profile.keyCharacteristics.map((char, idx) => (
                    <li key={idx} className="text-xs text-foreground flex items-start gap-2">
                      <span className="text-success mt-0.5">•</span>
                      {char}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          );
        })}
      </div>

      {/* Privacy note */}
      <p className="text-xs text-muted-foreground text-center mt-4 italic">
        Profiles are anonymized composites based on grouped participant data. Individual identities are never disclosed.
      </p>
    </div>
  );
}
