'use client';

import { Watch, FileText, Droplets, Users } from 'lucide-react';
import type { StudyStats } from '@/lib/saba/types';

interface StatsGridProps {
  stats: StudyStats;
}

type ColorKey = 'blue' | 'purple' | 'red' | 'green';

const STAT_CONFIG: Array<{
  key: keyof StudyStats;
  label: string;
  description: string;
  icon: typeof Watch;
  format: (v: number) => string;
  color: ColorKey;
}> = [
  {
    key: 'totalWearableDays',
    label: 'Wearable Days',
    description: 'Continuous health monitoring data',
    icon: Watch,
    format: (v: number) => `${(v / 1000).toFixed(0)}K+`,
    color: 'blue',
  },
  {
    key: 'questionnairesCompleted',
    label: 'Questionnaires',
    description: 'Lifestyle and health assessments',
    icon: FileText,
    format: (v: number) => v.toLocaleString(),
    color: 'purple',
  },
  {
    key: 'biomarkerSamplesAnalyzed',
    label: 'Biomarker Samples',
    description: 'Blood and tissue analyses',
    icon: Droplets,
    format: (v: number) => `${(v / 1000).toFixed(1)}K+`,
    color: 'red',
  },
  {
    key: 'superAgerParticipants',
    label: 'Super-Agers',
    description: '80+ with exceptional health',
    icon: Users,
    format: (v: number) => v.toLocaleString(),
    color: 'green',
  },
];

const COLOR_CLASSES = {
  blue: {
    bg: 'bg-blue-500/10',
    border: 'border-blue-500/30',
    text: 'text-blue-600',
  },
  purple: {
    bg: 'bg-purple-500/10',
    border: 'border-purple-500/30',
    text: 'text-purple-600',
  },
  red: {
    bg: 'bg-red-500/10',
    border: 'border-red-500/30',
    text: 'text-red-600',
  },
  green: {
    bg: 'bg-emerald-500/10',
    border: 'border-emerald-500/30',
    text: 'text-emerald-600',
  },
};

export default function StatsGrid({ stats }: StatsGridProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
      {STAT_CONFIG.map((config) => {
        const Icon = config.icon;
        const colors = COLOR_CLASSES[config.color];
        const value = stats[config.key] as number;

        return (
          <div
            key={config.key}
            className="card p-5 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl ${colors.bg} ${colors.border} border flex items-center justify-center flex-shrink-0`}>
                <Icon className={`w-5 h-5 ${colors.text}`} />
              </div>
              <div className="min-w-0">
                <p className="text-2xl font-bold text-foreground">
                  {config.format(value)}
                </p>
                <p className="text-sm font-medium text-foreground truncate">
                  {config.label}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  {config.description}
                </p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
