'use client';

import Image from 'next/image';

interface EuropeMapSVGProps {
  className?: string;
  width?: number;
  height?: number;
}

export function EuropeMapSVG({ className = '', width = 400, height = 520 }: EuropeMapSVGProps) {
  // The italy-regions.svg has viewBox "0 0 610 793"
  // Sardinia center is approximately at (110, 490) in that coordinate system
  // We scale our overlay positions to match

  const scaleX = width / 610;
  const scaleY = height / 793;

  // Sardinia data points (coordinates in original 610x793 viewBox)
  const sardiniaPoints = [
    { x: 110, y: 470, r: 14, label: 'Blue Zone highlands', count: 280 },
    { x: 125, y: 448, r: 10, label: 'Nuoro province', count: 180 },
    { x: 132, y: 495, r: 9, label: 'Ogliastra', count: 150 },
    { x: 95, y: 488, r: 8, label: 'Central Sardinia', count: 120 },
    { x: 105, y: 538, r: 7, label: 'Cagliari region', count: 100 },
    { x: 92, y: 432, r: 6, label: 'Sassari area', count: 95 },
    { x: 78, y: 478, r: 5, label: 'Oristano', count: 72 },
    { x: 118, y: 422, r: 5, label: 'Gallura', count: 55 },
  ];

  // Italy mainland control points
  const italyPoints = [
    { x: 175, y: 115, r: 6, label: 'Northern Italy', count: 35 },
    { x: 270, y: 280, r: 5, label: 'Central Italy', count: 30 },
    { x: 320, y: 360, r: 4, label: 'Rome region', count: 25 },
    { x: 380, y: 420, r: 4, label: 'Southern Italy', count: 20 },
    { x: 400, y: 680, r: 3, label: 'Sicily', count: 15 },
  ];

  return (
    <div className={`relative ${className}`} style={{ width, height }}>
      {/* Real geographic map as background */}
      <Image
        src="/images/italy-regions.svg"
        alt="Map of Italy"
        width={width}
        height={height}
        className="w-full h-full"
        style={{ objectFit: 'contain' }}
        priority
      />

      {/* Data overlay */}
      <svg
        viewBox="0 0 610 793"
        width={width}
        height={height}
        className="absolute inset-0 pointer-events-none"
        aria-label="SABA study participant distribution"
      >
        <defs>
          <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {/* Sardinia highlight overlay */}
        <ellipse
          cx="105"
          cy="480"
          rx="50"
          ry="80"
          fill="#7fa8b8"
          opacity="0.25"
        />

        {/* Blue Zone indicator */}
        <ellipse
          cx="110"
          cy="470"
          rx="25"
          ry="40"
          fill="none"
          stroke="#2d5a6a"
          strokeWidth="2"
          strokeDasharray="6,4"
          opacity="0.8"
        />

        {/* Sardinia data bubbles */}
        {sardiniaPoints.map((point, i) => (
          <circle
            key={`sardinia-${i}`}
            cx={point.x}
            cy={point.y}
            r={point.r}
            fill="#d97459"
            opacity={0.9 - i * 0.05}
            filter={i === 0 ? 'url(#glow)' : undefined}
          >
            <title>{point.label}: {point.count} participants</title>
          </circle>
        ))}

        {/* Italy control group bubbles */}
        {italyPoints.map((point, i) => (
          <circle
            key={`italy-${i}`}
            cx={point.x}
            cy={point.y}
            r={point.r}
            fill="#8b7355"
            opacity={0.7 - i * 0.05}
          >
            <title>{point.label}: {point.count} participants</title>
          </circle>
        ))}

        {/* Labels */}
        <text x="105" y="590" textAnchor="middle" fontSize="16" fill="#2d5a6a" fontWeight="700" fontFamily="Georgia, serif">
          Sardinia
        </text>
        <text x="105" y="606" textAnchor="middle" fontSize="10" fill="#4a7a8c">
          90% of participants
        </text>

        {/* Blue Zone badge */}
        <g transform="translate(35, 455)">
          <rect x="0" y="0" width="60" height="18" rx="9" fill="white" opacity="0.9" />
          <text x="30" y="13" textAnchor="middle" fontSize="9" fill="#2d5a6a" fontWeight="600">
            Blue Zone
          </text>
        </g>

        {/* Legend */}
        <g transform="translate(420, 40)">
          <rect x="-10" y="-15" width="145" height="110" rx="8" fill="white" opacity="0.95" stroke="#e0dcd5" strokeWidth="1" />
          <text x="0" y="0" fontSize="11" fill="#1a202c" fontWeight="700">Data Distribution</text>

          <circle cx="10" cy="25" r="8" fill="#d97459" opacity="0.85" />
          <text x="26" y="23" fontSize="10" fill="#2d3748">Sardinian cohort</text>
          <text x="26" y="35" fontSize="9" fill="#718096">(1,122 participants)</text>

          <circle cx="10" cy="58" r="6" fill="#8b7355" opacity="0.7" />
          <text x="26" y="56" fontSize="10" fill="#2d3748">Italian control</text>
          <text x="26" y="68" fontSize="9" fill="#718096">(125 participants)</text>

          <rect x="5" y="78" width="12" height="12" rx="3" fill="#7fa8b8" opacity="0.5" stroke="#4a7a8c" strokeWidth="1" />
          <text x="26" y="88" fontSize="10" fill="#2d3748">Blue Zone</text>
        </g>

        {/* Title */}
        <text x="305" y="25" textAnchor="middle" fontSize="16" fill="#1a202c" fontWeight="700" fontFamily="Georgia, serif">
          SABA Study: Geographic Distribution
        </text>
      </svg>
    </div>
  );
}

export default EuropeMapSVG;
