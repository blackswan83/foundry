'use client';

import { useState, useMemo, useCallback } from 'react';
import {
  ComposableMap,
  Geographies,
  Geography,
  Marker,
  ZoomableGroup,
} from 'react-simple-maps';
import { Plus, Minus, RotateCcw } from 'lucide-react';

// Nuraxi color palette - warm Mediterranean tones
const colors = {
  sea: '#f0ede4',
  land: '#e8e4dc',
  landHover: '#d9c9a3',
  italy: '#d9c9a3',
  italyHover: '#c9b893',
  sardinia: '#8fb3c4',
  sardiniaHover: '#7fa8b8',
  border: '#c4bfb3',
  // Updated: Sardinia bubble is now blue to match the region
  bubbleSardinia: '#7fa8b8',
  bubbleItaly: '#8b7355',
  text: '#2d3a3a',
  textMuted: '#5a6a72',
  warmSand: '#c9a86c',
};

// Geographic centers (longitude, latitude)
const SARDINIA_CENTER: [number, number] = [9.1, 40.1];
const ITALY_CENTER: [number, number] = [12.5, 42.5];
const EUROPE_CENTER: [number, number] = [10, 50];
const WORLD_CENTER: [number, number] = [0, 20];

// View presets - scalable for global expansion
const VIEWS = {
  world: { coordinates: WORLD_CENTER, zoom: 0.8 },
  europe: { coordinates: EUROPE_CENTER, zoom: 1 },
  italy: { coordinates: [12, 42] as [number, number], zoom: 3.5 },
  sardinia: { coordinates: SARDINIA_CENTER, zoom: 8 },
};

// GeoJSON sources
const GEO_SOURCES = {
  world: 'https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json',
  europe: '/geo/europe.json',
  italy: '/geo/italy-regions.json',
};

interface MapMarker {
  id: string;
  name: string;
  coordinates: [number, number];
  participants: number;
  region: string; // e.g., 'sardinia', 'italy', 'usa', 'japan' etc.
}

interface SabaMapProps {
  className?: string;
  width?: number;
  height?: number;
  sardiniaParticipants?: number;
  italyControlParticipants?: number;
  // Future: additional regions
  additionalMarkers?: MapMarker[];
  showTitle?: boolean;
  initialView?: 'world' | 'europe' | 'italy' | 'sardinia';
  // Future: enable world view
  enableWorldView?: boolean;
}

export function SabaMap({
  className = '',
  width = 600,
  height = 450,
  sardiniaParticipants = 1122,
  italyControlParticipants = 125,
  additionalMarkers = [],
  showTitle = false,
  initialView = 'italy', // Default to Italy view as requested
  enableWorldView = false,
}: SabaMapProps) {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);
  const [position, setPosition] = useState({
    coordinates: VIEWS[initialView].coordinates,
    zoom: VIEWS[initialView].zoom,
  });

  const handleMoveEnd = useCallback((position: { coordinates: [number, number]; zoom: number }) => {
    setPosition(position);
  }, []);

  const handleZoomIn = useCallback(() => {
    if (position.zoom < 12) {
      setPosition((pos) => ({ ...pos, zoom: pos.zoom * 1.5 }));
    }
  }, [position.zoom]);

  const handleZoomOut = useCallback(() => {
    if (position.zoom > 0.5) {
      setPosition((pos) => ({ ...pos, zoom: pos.zoom / 1.5 }));
    }
  }, [position.zoom]);

  const handleReset = useCallback(() => {
    setPosition(VIEWS[initialView]);
  }, [initialView]);


  const markers: MapMarker[] = useMemo(() => {
    const baseMarkers: MapMarker[] = [
      {
        id: 'sardinia-total',
        name: 'Sardinia',
        coordinates: SARDINIA_CENTER,
        participants: sardiniaParticipants,
        region: 'sardinia',
      },
      {
        id: 'italy-control',
        name: 'Italy (Control)',
        coordinates: ITALY_CENTER,
        participants: italyControlParticipants,
        region: 'italy',
      },
    ];

    return [...baseMarkers, ...additionalMarkers];
  }, [sardiniaParticipants, italyControlParticipants, additionalMarkers]);

  const getBubbleRadius = (participants: number, region: string) => {
    // Scale bubbles based on zoom level - smaller for cleaner look
    const baseMaxRadius = region === 'sardinia' ? 22 : 14;
    const baseMinRadius = 6;
    const maxParticipants = sardiniaParticipants;
    const scale = Math.sqrt(participants / maxParticipants);
    const baseRadius = baseMinRadius + scale * (baseMaxRadius - baseMinRadius);
    // Adjust for zoom
    return baseRadius / Math.sqrt(position.zoom);
  };

  const getBubbleColor = (region: string) => {
    switch (region) {
      case 'sardinia':
        return colors.bubbleSardinia; // Now blue
      case 'italy':
        return colors.bubbleItaly;
      default:
        return colors.warmSand; // Default for future regions
    }
  };

  const totalParticipants = markers.reduce((sum, m) => sum + m.participants, 0);

  return (
    <div className={`flex flex-col ${className}`}>
      {/* Map Container */}
      <div className="relative rounded-xl overflow-hidden border border-[#e5e0d8] bg-[#f5f3ed]" style={{ width, height }}>
        <ComposableMap
          projection="geoMercator"
          projectionConfig={{
            center: [10, 50],
            scale: 800,
          }}
          width={width}
          height={height}
          style={{ width: '100%', height: '100%' }}
        >
          <defs>
            <linearGradient id="seaGradient" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#f5f3ed" />
              <stop offset="100%" stopColor="#ebe8e0" />
            </linearGradient>

            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="1" dy="2" stdDeviation="2" floodOpacity="0.25" />
            </filter>
          </defs>

          <rect x={0} y={0} width={width} height={height} fill="url(#seaGradient)" />

          <ZoomableGroup
            center={position.coordinates}
            zoom={position.zoom}
            onMoveEnd={handleMoveEnd}
            minZoom={0.5}
            maxZoom={12}
          >
            {/* World countries - shown when zoomed out */}
            {enableWorldView && position.zoom < 1.5 && (
              <Geographies geography={GEO_SOURCES.world}>
                {({ geographies }) =>
                  geographies.map((geo) => {
                    const isItaly = geo.properties.name === 'Italy';
                    return (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        fill={isItaly ? colors.italy : colors.land}
                        stroke={colors.border}
                        strokeWidth={0.3 / position.zoom}
                        style={{
                          default: { outline: 'none' },
                          hover: { fill: colors.landHover, outline: 'none' },
                          pressed: { outline: 'none' },
                        }}
                      />
                    );
                  })
                }
              </Geographies>
            )}

            {/* Europe countries */}
            <Geographies geography={GEO_SOURCES.europe}>
              {({ geographies }) =>
                geographies.map((geo) => {
                  const isItaly = geo.properties.NAME === 'Italy';
                  return (
                    <Geography
                      key={geo.rsmKey}
                      geography={geo}
                      fill={isItaly ? colors.italy : colors.land}
                      stroke={colors.border}
                      strokeWidth={0.5 / position.zoom}
                      style={{
                        default: { outline: 'none', transition: 'fill 0.2s ease' },
                        hover: {
                          fill: isItaly ? colors.italyHover : colors.landHover,
                          outline: 'none',
                          cursor: 'pointer',
                        },
                        pressed: { outline: 'none' },
                      }}
                      onMouseEnter={() => setHoveredRegion(geo.properties.NAME)}
                      onMouseLeave={() => setHoveredRegion(null)}
                    />
                  );
                })
              }
            </Geographies>

            {/* Italy regions */}
            <Geographies geography={GEO_SOURCES.italy}>
              {({ geographies }) =>
                geographies.map((geo) => {
                  const isSardinia = geo.properties.reg_name === 'Sardegna';
                  return (
                    <Geography
                      key={geo.rsmKey}
                      geography={geo}
                      fill={isSardinia ? colors.sardinia : colors.italy}
                      stroke={isSardinia ? '#4a7a8c' : colors.border}
                      strokeWidth={(isSardinia ? 1.5 : 0.5) / position.zoom}
                      style={{
                        default: { outline: 'none', transition: 'fill 0.2s ease' },
                        hover: {
                          fill: isSardinia ? colors.sardiniaHover : colors.italyHover,
                          outline: 'none',
                          cursor: 'pointer',
                        },
                        pressed: { outline: 'none' },
                      }}
                      onMouseEnter={() => setHoveredRegion(geo.properties.reg_name)}
                      onMouseLeave={() => setHoveredRegion(null)}
                    />
                  );
                })
              }
            </Geographies>

            {/* Data bubbles */}
            {markers.map((marker) => (
              <Marker key={marker.id} coordinates={marker.coordinates}>
                <circle
                  r={getBubbleRadius(marker.participants, marker.region)}
                  fill={getBubbleColor(marker.region)}
                  fillOpacity={0.9}
                  stroke="#fff"
                  strokeWidth={2 / position.zoom}
                  filter="url(#shadow)"
                  style={{ cursor: 'pointer', transition: 'r 0.3s ease' }}
                />
                {position.zoom > 4 && (
                  <text
                    textAnchor="middle"
                    y={2 / position.zoom}
                    style={{
                      fontFamily: 'system-ui, sans-serif',
                      fontSize: `${Math.max(4, 8 / position.zoom)}px`,
                      fontWeight: 600,
                      fill: '#fff',
                      pointerEvents: 'none',
                    }}
                  >
                    {marker.participants.toLocaleString()}
                  </text>
                )}
              </Marker>
            ))}
          </ZoomableGroup>
        </ComposableMap>

        {/* Zoom Controls */}
        <div className="absolute top-3 right-3 flex flex-col gap-1">
          <button
            onClick={handleZoomIn}
            className="w-8 h-8 bg-white/90 hover:bg-white rounded-lg shadow-sm border border-[#e5e0d8] flex items-center justify-center transition-colors"
            title="Zoom in"
          >
            <Plus className="w-4 h-4 text-[#5a6a72]" />
          </button>
          <button
            onClick={handleZoomOut}
            className="w-8 h-8 bg-white/90 hover:bg-white rounded-lg shadow-sm border border-[#e5e0d8] flex items-center justify-center transition-colors"
            title="Zoom out"
          >
            <Minus className="w-4 h-4 text-[#5a6a72]" />
          </button>
          <button
            onClick={handleReset}
            className="w-8 h-8 bg-white/90 hover:bg-white rounded-lg shadow-sm border border-[#e5e0d8] flex items-center justify-center transition-colors"
            title="Reset view"
          >
            <RotateCcw className="w-4 h-4 text-[#5a6a72]" />
          </button>
        </div>


        {/* Hover tooltip */}
        {hoveredRegion && (
          <div className="absolute top-3 left-3 bg-white/95 px-3 py-1.5 rounded-lg shadow-sm text-sm text-[#2d3748] font-medium">
            {hoveredRegion}
          </div>
        )}

        {/* Zoom level indicator */}
        <div className="absolute bottom-3 left-3 bg-white/90 px-2 py-1 rounded text-xs text-[#718096]">
          {position.zoom.toFixed(1)}x
        </div>
      </div>

      {/* Legend - Below the map */}
      <div className="mt-4 px-2">
        {showTitle && (
          <h3 className="text-lg font-semibold text-[#2d3748] mb-3" style={{ fontFamily: 'Georgia, serif' }}>
            Geographic Distribution
          </h3>
        )}

        <div className="flex flex-wrap items-center justify-center gap-6">
          {/* Sardinia */}
          <div className="flex items-center gap-2">
            <div
              className="w-5 h-5 rounded-full shadow-sm"
              style={{ backgroundColor: colors.bubbleSardinia }}
            />
            <div>
              <span className="text-sm font-medium text-[#2d3748]">Sardinia</span>
              <span className="text-sm text-[#718096] ml-1">
                ({sardiniaParticipants.toLocaleString()})
              </span>
            </div>
          </div>

          {/* Italy Control */}
          <div className="flex items-center gap-2">
            <div
              className="w-4 h-4 rounded-full shadow-sm"
              style={{ backgroundColor: colors.bubbleItaly }}
            />
            <div>
              <span className="text-sm font-medium text-[#2d3748]">Italy Control</span>
              <span className="text-sm text-[#718096] ml-1">
                ({italyControlParticipants.toLocaleString()})
              </span>
            </div>
          </div>

          {/* Total */}
          <div className="text-sm text-[#a0aec0]">
            Total: <span className="font-medium text-[#4a5568]">{totalParticipants.toLocaleString()}</span> participants
          </div>
        </div>
      </div>
    </div>
  );
}

export default SabaMap;
