'use client';

import { ArrowDown, ArrowUp, Minus, BarChart3 } from 'lucide-react';
import type { CohortComparison as CohortComparisonType } from '@/lib/saba/types';

interface CohortComparisonProps {
  comparisons: CohortComparisonType[];
}

function formatValue(value: number, metric: string): string {
  if (metric.includes('Steps')) return value.toLocaleString();
  if (metric.includes('Amplitude')) return value.toFixed(2);
  if (metric.includes('%')) return `${value}%`;
  return value.toFixed(1);
}

function getDifferenceIcon(diff: number) {
  if (diff > 5) return <ArrowUp className="w-4 h-4 text-success" />;
  if (diff < -5) return <ArrowDown className="w-4 h-4 text-success" />;
  return <Minus className="w-4 h-4 text-muted-foreground" />;
}

function getDifferenceColor(diff: number, metric: string): string {
  // For metrics where lower is better (like CRP, Heart Rate)
  const lowerIsBetter = metric.includes('CRP') || metric.includes('Heart Rate');
  const isPositive = lowerIsBetter ? diff < 0 : diff > 0;
  return isPositive ? 'text-success' : diff === 0 ? 'text-muted-foreground' : 'text-error';
}

export default function CohortComparison({ comparisons }: CohortComparisonProps) {
  return (
    <div className="card p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <BarChart3 className="w-5 h-5 text-primary" />
        </div>
        <div>
          <h3 className="text-lg font-semibold text-foreground">Blue Zone vs. General Population</h3>
          <p className="text-sm text-muted-foreground">Key health metrics comparison</p>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/20">
              <th className="text-left py-3 px-4 text-sm font-medium text-muted-foreground">Metric</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-success">
                SABA Blue Zone
                <span className="block text-xs font-normal">(mean ± SD)</span>
              </th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">
                General Population
                <span className="block text-xs font-normal">(mean ± SD)</span>
              </th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">Difference</th>
              <th className="text-center py-3 px-4 text-sm font-medium text-muted-foreground">p-value</th>
            </tr>
          </thead>
          <tbody>
            {comparisons.map((comparison) => (
              <tr key={comparison.metric} className="border-b border-white/10 hover:bg-white/10 transition-colors">
                <td className="py-4 px-4">
                  <p className="font-medium text-foreground">{comparison.metric}</p>
                  <p className="text-xs text-muted-foreground">{comparison.unit}</p>
                </td>
                <td className="py-4 px-4 text-center">
                  <span className="font-semibold text-success">
                    {formatValue(comparison.sabaBlueZone.mean, comparison.metric)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {' '}± {formatValue(comparison.sabaBlueZone.std, comparison.metric)}
                  </span>
                  <p className="text-xs text-muted-foreground">n = {comparison.sabaBlueZone.n}</p>
                </td>
                <td className="py-4 px-4 text-center">
                  <span className="font-semibold text-foreground">
                    {formatValue(comparison.generalPopulation.mean, comparison.metric)}
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {' '}± {formatValue(comparison.generalPopulation.std, comparison.metric)}
                  </span>
                  <p className="text-xs text-muted-foreground">n = {comparison.generalPopulation.n}</p>
                </td>
                <td className="py-4 px-4 text-center">
                  <div className="flex items-center justify-center gap-1">
                    {getDifferenceIcon(comparison.percentDifference)}
                    <span className={`font-semibold ${getDifferenceColor(comparison.percentDifference, comparison.metric)}`}>
                      {comparison.percentDifference > 0 ? '+' : ''}{comparison.percentDifference.toFixed(1)}%
                    </span>
                  </div>
                </td>
                <td className="py-4 px-4 text-center">
                  {comparison.pValue && (
                    <span className={`text-sm ${comparison.pValue < 0.05 ? 'font-semibold text-success' : 'text-muted-foreground'}`}>
                      {comparison.pValue < 0.001 ? '< 0.001' : comparison.pValue.toFixed(3)}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-success-light/50 border border-green-200">
          <h4 className="text-sm font-medium text-green-800 mb-2">Key Advantage</h4>
          <p className="text-sm text-green-700">
            Blue Zone participants show <span className="font-semibold">23.5% higher HRV</span> and{' '}
            <span className="font-semibold">57% lower CRP levels</span>, indicating better cardiovascular health and reduced inflammation.
          </p>
        </div>
        <div className="p-4 rounded-xl bg-blue-50 border border-blue-100">
          <h4 className="text-sm font-medium text-blue-800 mb-2">Methodology Note</h4>
          <p className="text-sm text-blue-700">
            All comparisons are age-adjusted. General population data sourced from European aging cohort studies (2020-2024).
          </p>
        </div>
      </div>
    </div>
  );
}
