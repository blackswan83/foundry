'use client';

import Image from 'next/image';

interface NoraLogoProps {
  className?: string;
  height?: number;
}

export function NoraLogo({ className = '', height = 32 }: NoraLogoProps) {
  // Calculate width based on aspect ratio (approximately 4.2:1)
  const width = Math.round(height * 4.2);

  return (
    <Image
      src="/images/nora-logo-header-dark-warmSand.svg"
      alt="Nora by Nuraxi"
      width={width}
      height={height}
      className={className}
      priority
    />
  );
}

export default NoraLogo;
