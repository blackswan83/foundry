'use client';

import { useState, useEffect } from 'react';
import { Trash2, TrendingDown, TrendingUp, Minus, Calendar, ChevronDown, ChevronUp } from 'lucide-react';
import { HistoryEntry, BiologicalAgeResult } from '@/lib/clocks/types';
import { loadFromStorage, saveToStorage, cn, getAgeColor, getAgeInterpretationText } from '@/lib/utils';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ReferenceLine,
} from 'recharts';

const HISTORY_STORAGE_KEY = 'bioclock-history';

interface HistoryProps {
  newEntry?: HistoryEntry | null;
  onEntrySaved?: () => void;
}

export default function History({ newEntry, onEntrySaved }: HistoryProps) {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Load history from storage
  useEffect(() => {
    const savedHistory = loadFromStorage<HistoryEntry[]>(HISTORY_STORAGE_KEY);
    if (savedHistory) {
      setHistory(savedHistory);
    }
  }, []);

  // Save new entry if provided
  useEffect(() => {
    if (newEntry) {
      const updatedHistory = [newEntry, ...history];
      setHistory(updatedHistory);
      saveToStorage(HISTORY_STORAGE_KEY, updatedHistory);
      onEntrySaved?.();
    }
  }, [newEntry]);

  const deleteEntry = (id: string) => {
    const updatedHistory = history.filter(h => h.id !== id);
    setHistory(updatedHistory);
    saveToStorage(HISTORY_STORAGE_KEY, updatedHistory);
  };

  const clearHistory = () => {
    if (confirm('Are you sure you want to clear all history?')) {
      setHistory([]);
      saveToStorage(HISTORY_STORAGE_KEY, []);
    }
  };

  // Prepare chart data
  const chartData = [...history]
    .reverse()
    .map(entry => {
      const phenoAge = entry.results.find(r => r.clockName === 'PhenoAge');
      const kdmAge = entry.results.find(r => r.clockName === 'KDM Biological Age');

      return {
        date: new Date(entry.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        chronologicalAge: phenoAge?.chronologicalAge || kdmAge?.chronologicalAge,
        phenoAge: phenoAge?.biologicalAge,
        kdmAge: kdmAge?.biologicalAge,
      };
    });

  if (history.length === 0) {
    return (
      <div className="card p-12 text-center">
        <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-900 mb-2">No History Yet</h3>
        <p className="text-slate-500">
          Calculate your biological age and save results to track your progress over time.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Trend Chart */}
      {chartData.length >= 2 && (
        <div className="card">
          <div className="card-header">
            <h3 className="font-semibold text-slate-900">Biological Age Trend</h3>
            <p className="text-sm text-slate-500">Track your biological age over time</p>
          </div>
          <div className="card-body">
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={12} />
                  <YAxis stroke="#64748b" fontSize={12} domain={['auto', 'auto']} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '8px',
                    }}
                  />
                  <Legend />
                  <ReferenceLine
                    y={chartData[0]?.chronologicalAge}
                    stroke="#94a3b8"
                    strokeDasharray="5 5"
                    label={{ value: 'Chronological', fill: '#94a3b8', fontSize: 11 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="phenoAge"
                    name="PhenoAge"
                    stroke="#0891b2"
                    strokeWidth={2}
                    dot={{ fill: '#0891b2', strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                  />
                  <Line
                    type="monotone"
                    dataKey="kdmAge"
                    name="KDM Age"
                    stroke="#7c3aed"
                    strokeWidth={2}
                    dot={{ fill: '#7c3aed', strokeWidth: 2 }}
                    activeDot={{ r: 6 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* History List */}
      <div className="card">
        <div className="card-header flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-slate-900">History</h3>
            <p className="text-sm text-slate-500">{history.length} saved results</p>
          </div>
          <button
            onClick={clearHistory}
            className="text-sm text-red-600 hover:text-red-700 font-medium"
          >
            Clear All
          </button>
        </div>
        <div className="divide-y divide-slate-100">
          {history.map((entry) => {
            const primaryResult = entry.results.find(r => r.clockName === 'PhenoAge') || entry.results[0];
            const isExpanded = expandedId === entry.id;

            return (
              <div key={entry.id} className="p-4">
                <div
                  className="flex items-center justify-between cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : entry.id)}
                >
                  <div className="flex items-center gap-4">
                    <div className="text-sm text-slate-500">
                      {new Date(entry.date).toLocaleDateString('en-US', {
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-slate-900">
                        {primaryResult.biologicalAge}
                      </span>
                      <span className="text-slate-400">vs</span>
                      <span className="text-xl text-slate-500">
                        {primaryResult.chronologicalAge}
                      </span>
                    </div>
                    <div className={cn('flex items-center gap-1', getAgeColor(primaryResult.interpretation))}>
                      {primaryResult.interpretation === 'younger' && <TrendingDown className="w-4 h-4" />}
                      {primaryResult.interpretation === 'older' && <TrendingUp className="w-4 h-4" />}
                      {primaryResult.interpretation === 'ontrack' && <Minus className="w-4 h-4" />}
                      <span className="text-sm font-medium">
                        {getAgeInterpretationText(primaryResult.ageDifference)}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteEntry(entry.id);
                      }}
                      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5 text-slate-400" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-slate-400" />
                    )}
                  </div>
                </div>

                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-100">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      {entry.results.map(result => (
                        <div key={result.clockName} className="bg-slate-50 rounded-lg p-3">
                          <div className="text-xs text-slate-500">{result.clockName}</div>
                          <div className="text-lg font-semibold text-slate-900">
                            {result.biologicalAge} yrs
                          </div>
                          <div className={cn('text-sm', getAgeColor(result.interpretation))}>
                            {result.ageDifference > 0 ? '+' : ''}{result.ageDifference} years
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
