'use client';

import { AlertTriangle, BookOpen, Shield, Clock, Activity, ExternalLink } from 'lucide-react';
import { PHENOAGE_INFO } from '@/lib/clocks/phenoage';
import { KDM_INFO } from '@/lib/clocks/kdm';

export default function About() {
  return (
    <div className="space-y-6">
      {/* Important Disclaimer */}
      <div className="card border-amber-200 bg-amber-50">
        <div className="card-header border-amber-200">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-amber-600" />
            <h3 className="font-semibold text-amber-900">Important Disclaimer</h3>
          </div>
        </div>
        <div className="card-body text-amber-800 space-y-3">
          <p>
            <strong>This tool is for informational and educational purposes only.</strong> The biological
            age calculations provided are estimates based on published scientific research and should not
            be used as a substitute for professional medical advice, diagnosis, or treatment.
          </p>
          <ul className="list-disc list-inside space-y-2 text-sm">
            <li>This is <strong>not</strong> an FDA-approved or reviewed medical device</li>
            <li>Results are <strong>not</strong> intended to diagnose, treat, cure, or prevent any disease</li>
            <li>Biological age estimates are based on statistical models with inherent limitations</li>
            <li>Results may vary based on sample collection, laboratory methods, and individual factors</li>
            <li>Always consult with qualified healthcare providers for medical decisions</li>
            <li>Acute conditions (illness, inflammation) can significantly affect results</li>
          </ul>
          <p className="text-sm">
            By using this tool, you acknowledge that you understand these limitations and agree to use
            the results responsibly and in conjunction with professional medical guidance.
          </p>
        </div>
      </div>

      {/* Data Privacy */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">Data Privacy</h3>
          </div>
        </div>
        <div className="card-body text-slate-600 space-y-3">
          <p>
            <strong>Your data stays on your device.</strong> BioClock is designed with privacy in mind:
          </p>
          <ul className="list-disc list-inside space-y-2 text-sm">
            <li>All calculations are performed locally in your browser</li>
            <li>No biomarker data is sent to any server</li>
            <li>History is stored only in your browser&apos;s local storage</li>
            <li>You can clear your history at any time</li>
            <li>We do not collect or store any personal health information</li>
          </ul>
        </div>
      </div>

      {/* About Biological Age */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">What is Biological Age?</h3>
          </div>
        </div>
        <div className="card-body text-slate-600 space-y-4">
          <p>
            Biological age represents how well your body is functioning compared to average people of
            different chronological ages. While chronological age simply counts years since birth,
            biological age attempts to measure physiological aging—how your cells, tissues, and organ
            systems are actually performing.
          </p>
          <p>
            Research shows that individuals of the same chronological age can have dramatically different
            biological ages. A 50-year-old with excellent health habits may have the physiological function
            of a typical 40-year-old, while another 50-year-old with poor metabolic health may function
            more like a 60-year-old.
          </p>
          <p>
            Blood biomarker-based clocks use patterns across multiple physiological systems—immune function,
            metabolic health, liver and kidney function, and inflammation—to estimate biological age.
            Second-generation clocks like PhenoAge were trained directly on mortality outcomes, making them
            strong predictors of healthspan and longevity.
          </p>
        </div>
      </div>

      {/* Scientific Background - PhenoAge */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">{PHENOAGE_INFO.name}</h3>
          </div>
        </div>
        <div className="card-body text-slate-600 space-y-4">
          <p>
            PhenoAge is a second-generation biological aging clock developed by Morgan Levine and colleagues
            at Yale University. Unlike first-generation clocks that simply predict chronological age, PhenoAge
            was trained on <strong>mortality data from NHANES III</strong> (n=9,926), making it a powerful
            predictor of remaining lifespan and healthspan.
          </p>

          <div className="bg-slate-50 rounded-lg p-4">
            <h4 className="font-medium text-slate-900 mb-2">Validation Metrics</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-500">Correlation with age:</span>
                <span className="font-medium text-slate-900 ml-2">r = {PHENOAGE_INFO.validationMetrics.correlationWithAge}</span>
              </div>
              <div>
                <span className="text-slate-500">Mortality HR (per 1 SD):</span>
                <span className="font-medium text-slate-900 ml-2">
                  {PHENOAGE_INFO.validationMetrics.mortalityHazardRatio} (95% CI: {PHENOAGE_INFO.validationMetrics.mortalityHazardRatioCI[0]}-{PHENOAGE_INFO.validationMetrics.mortalityHazardRatioCI[1]})
                </span>
              </div>
            </div>
          </div>

          <p className="text-sm">
            <strong>Publication:</strong> {PHENOAGE_INFO.publication.authors} &quot;{PHENOAGE_INFO.publication.title}.&quot;
            <em> {PHENOAGE_INFO.publication.journal}</em> ({PHENOAGE_INFO.publication.year}).
            {PHENOAGE_INFO.publication.doi && (
              <a
                href={`https://doi.org/${PHENOAGE_INFO.publication.doi}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary-600 hover:text-primary-700 ml-1 inline-flex items-center gap-1"
              >
                DOI <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </p>
        </div>
      </div>

      {/* Scientific Background - KDM */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">{KDM_INFO.name}</h3>
          </div>
        </div>
        <div className="card-body text-slate-600 space-y-4">
          <p>
            The Klemera-Doubal Method uses a fundamentally different mathematical approach. Rather than
            training directly on mortality, KDM uses a series of regressions of individual biomarkers on
            chronological age in a reference population, then combines these into a biological age estimate
            weighted by their reliability.
          </p>
          <p>
            This approach has been validated in the <strong>CALERIE caloric restriction trial</strong>,
            demonstrating that lifestyle interventions can measurably slow biological aging as assessed
            by this algorithm.
          </p>

          <div className="bg-slate-50 rounded-lg p-4">
            <h4 className="font-medium text-slate-900 mb-2">Validation Metrics</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-slate-500">Correlation with age:</span>
                <span className="font-medium text-slate-900 ml-2">r = {KDM_INFO.validationMetrics.correlationWithAge}</span>
              </div>
              <div>
                <span className="text-slate-500">Mortality HR (per 1 SD):</span>
                <span className="font-medium text-slate-900 ml-2">
                  {KDM_INFO.validationMetrics.mortalityHazardRatio} (95% CI: {KDM_INFO.validationMetrics.mortalityHazardRatioCI[0]}-{KDM_INFO.validationMetrics.mortalityHazardRatioCI[1]})
                </span>
              </div>
            </div>
          </div>

          <p className="text-sm">
            <strong>Publication:</strong> {KDM_INFO.publication.authors}. &quot;{KDM_INFO.publication.title}.&quot;
            <em> {KDM_INFO.publication.journal}</em> ({KDM_INFO.publication.year}).
            {KDM_INFO.publication.doi && (
              <a
                href={`https://doi.org/${KDM_INFO.publication.doi}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary-600 hover:text-primary-700 ml-1 inline-flex items-center gap-1"
              >
                DOI <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </p>
        </div>
      </div>

      {/* Required Tests */}
      <div className="card">
        <div className="card-header">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-primary-600" />
            <h3 className="font-semibold text-slate-900">Required Blood Tests</h3>
          </div>
        </div>
        <div className="card-body text-slate-600 space-y-4">
          <p>
            All biomarkers used by BioClock are available from standard blood panels offered by most
            clinical laboratories:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 rounded-lg p-4">
              <h4 className="font-medium text-slate-900 mb-2">Complete Blood Count (CBC)</h4>
              <ul className="text-sm space-y-1">
                <li>White Blood Cell Count</li>
                <li>Lymphocyte Percentage</li>
                <li>Mean Cell Volume (MCV)</li>
                <li>Red Cell Distribution Width (RDW)</li>
              </ul>
            </div>
            <div className="bg-slate-50 rounded-lg p-4">
              <h4 className="font-medium text-slate-900 mb-2">Comprehensive Metabolic Panel</h4>
              <ul className="text-sm space-y-1">
                <li>Albumin</li>
                <li>Creatinine</li>
                <li>Fasting Glucose</li>
                <li>Alkaline Phosphatase</li>
              </ul>
            </div>
            <div className="bg-slate-50 rounded-lg p-4">
              <h4 className="font-medium text-slate-900 mb-2">Additional Tests</h4>
              <ul className="text-sm space-y-1">
                <li>C-Reactive Protein (hs-CRP)</li>
                <li>Blood Urea Nitrogen (optional)</li>
                <li>Total Cholesterol (optional)</li>
                <li>Blood Pressure (optional)</li>
              </ul>
            </div>
          </div>

          <p className="text-sm text-slate-500">
            These tests are typically available for $50-150 from major laboratories like Quest Diagnostics
            or LabCorp, and are often included in annual health checkups.
          </p>
        </div>
      </div>

      {/* Open Source Notice */}
      <div className="card">
        <div className="card-header">
          <h3 className="font-semibold text-slate-900">Open Source</h3>
        </div>
        <div className="card-body text-slate-600">
          <p>
            BioClock is built using published scientific algorithms. The calculation methods are based on
            peer-reviewed research and open-source implementations including the
            <a
              href="https://github.com/dayoonkwon/BioAge"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-600 hover:text-primary-700 mx-1 inline-flex items-center gap-1"
            >
              BioAge R package <ExternalLink className="w-3 h-3" />
            </a>
            and
            <a
              href="https://github.com/bio-learn/biolearn"
              target="_blank"
              rel="noopener noreferrer"
              className="text-primary-600 hover:text-primary-700 mx-1 inline-flex items-center gap-1"
            >
              biolearn Python library <ExternalLink className="w-3 h-3" />
            </a>.
          </p>
        </div>
      </div>
    </div>
  );
}
