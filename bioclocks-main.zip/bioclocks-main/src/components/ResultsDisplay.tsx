'use client';

import { TrendingDown, TrendingUp, Minus, AlertTriangle, CheckCircle, XCircle, Lightbulb, Download, Save } from 'lucide-react';
import { BiologicalAgeResult, CalculationResult } from '@/lib/clocks';
import { cn, getAgeColor, getAgeBgColor, getAgeInterpretationText } from '@/lib/utils';

interface ResultsDisplayProps {
  results: CalculationResult;
  onSave?: () => void;
}

export default function ResultsDisplay({ results, onSave }: ResultsDisplayProps) {
  if (!results.success || results.results.length === 0) {
    return (
      <div className="card p-8 text-center">
        <AlertTriangle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-slate-900 mb-2">Unable to Calculate</h3>
        <p className="text-slate-600">
          {results.errors.length > 0
            ? results.errors.map(e => e.error).join('. ')
            : 'Please fill in all required biomarkers.'}
        </p>
      </div>
    );
  }

  // Use PhenoAge as primary result if available
  const primaryResult = results.results.find(r => r.clockName === 'PhenoAge') || results.results[0];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Warnings */}
      {results.warnings.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-medium text-amber-800">Important Notice</h4>
              {results.warnings.map((warning, i) => (
                <p key={i} className="text-sm text-amber-700 mt-1">{warning}</p>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Primary Age Display */}
      <div className={cn('card overflow-hidden', getAgeBgColor(primaryResult.interpretation))}>
        <div className="p-8 text-center">
          <h2 className="text-sm font-medium text-slate-600 uppercase tracking-wide mb-4">
            Your Biological Age ({primaryResult.clockName})
          </h2>

          <div className="flex items-center justify-center gap-8 mb-6">
            {/* Biological Age */}
            <div>
              <div className={cn('text-6xl font-bold', getAgeColor(primaryResult.interpretation))}>
                {primaryResult.biologicalAge}
              </div>
              <div className="text-sm text-slate-500 mt-1">Biological Age</div>
            </div>

            {/* Arrow indicator */}
            <div className="flex flex-col items-center">
              {primaryResult.interpretation === 'younger' && (
                <TrendingDown className="w-10 h-10 text-emerald-500" />
              )}
              {primaryResult.interpretation === 'older' && (
                <TrendingUp className="w-10 h-10 text-red-500" />
              )}
              {primaryResult.interpretation === 'ontrack' && (
                <Minus className="w-10 h-10 text-amber-500" />
              )}
              <span className={cn('text-sm font-medium mt-1', getAgeColor(primaryResult.interpretation))}>
                {getAgeInterpretationText(primaryResult.ageDifference)}
              </span>
            </div>

            {/* Chronological Age */}
            <div>
              <div className="text-6xl font-bold text-slate-400">
                {primaryResult.chronologicalAge}
              </div>
              <div className="text-sm text-slate-500 mt-1">Chronological Age</div>
            </div>
          </div>

          {/* Confidence Score */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/50 rounded-full">
            <div className="w-2 h-2 rounded-full bg-primary-500" />
            <span className="text-sm text-slate-600">
              Confidence: {primaryResult.confidenceScore}%
            </span>
          </div>
        </div>
      </div>

      {/* All Clock Results */}
      {results.results.length > 1 && (
        <div className="card">
          <div className="card-header">
            <h3 className="font-semibold text-slate-900">All Clock Results</h3>
          </div>
          <div className="card-body">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {results.results.map((result) => (
                <div
                  key={result.clockName}
                  className={cn(
                    'p-4 rounded-xl border-2',
                    result.clockName === primaryResult.clockName
                      ? 'border-primary-200 bg-primary-50'
                      : 'border-slate-100 bg-slate-50'
                  )}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-medium text-slate-900">{result.clockName}</h4>
                      <p className="text-xs text-slate-500">v{result.clockVersion}</p>
                    </div>
                    <span className={cn(
                      'age-badge',
                      result.interpretation === 'younger' && 'age-badge-younger',
                      result.interpretation === 'ontrack' && 'age-badge-ontrack',
                      result.interpretation === 'older' && 'age-badge-older',
                    )}>
                      {result.biologicalAge} yrs
                    </span>
                  </div>
                  <div className="text-sm text-slate-600">
                    {getAgeInterpretationText(result.ageDifference)} than chronological age
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Biomarker Contributions */}
      <div className="card">
        <div className="card-header">
          <h3 className="font-semibold text-slate-900">Biomarker Analysis</h3>
          <p className="text-sm text-slate-500 mt-1">How each biomarker contributes to your biological age</p>
        </div>
        <div className="card-body divide-y divide-slate-100">
          {primaryResult.biomarkerContributions.map((contribution) => (
            <div key={contribution.name} className="biomarker-row">
              <div className="flex items-center gap-3">
                {contribution.status === 'optimal' && (
                  <CheckCircle className="w-5 h-5 text-emerald-500" />
                )}
                {contribution.status === 'suboptimal' && (
                  <AlertTriangle className="w-5 h-5 text-amber-500" />
                )}
                {contribution.status === 'concerning' && (
                  <XCircle className="w-5 h-5 text-red-500" />
                )}
                <div>
                  <div className="font-medium text-slate-900">{contribution.name}</div>
                  <div className="text-sm text-slate-500">
                    {contribution.value} {contribution.unit}
                    <span className="text-slate-400 ml-2">
                      (Ref: {contribution.referenceRange.min} - {contribution.referenceRange.max})
                    </span>
                  </div>
                </div>
              </div>
              <div className={cn(
                'text-sm font-medium',
                contribution.status === 'optimal' && 'text-emerald-600',
                contribution.status === 'suboptimal' && 'text-amber-600',
                contribution.status === 'concerning' && 'text-red-600',
              )}>
                {contribution.status === 'optimal' && 'Optimal'}
                {contribution.status === 'suboptimal' && 'Suboptimal'}
                {contribution.status === 'concerning' && 'Needs Attention'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Recommendations */}
      {primaryResult.recommendations.length > 0 && (
        <div className="card">
          <div className="card-header flex items-center gap-2">
            <Lightbulb className="w-5 h-5 text-amber-500" />
            <h3 className="font-semibold text-slate-900">Personalized Recommendations</h3>
          </div>
          <div className="card-body space-y-3">
            {primaryResult.recommendations.map((rec, index) => (
              <div key={index} className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <div className="w-6 h-6 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center text-sm font-medium flex-shrink-0">
                  {index + 1}
                </div>
                <p className="text-slate-700">{rec}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Actions */}
      <div className="flex gap-3">
        {onSave && (
          <button onClick={onSave} className="btn-primary">
            <Save className="w-4 h-4 mr-2" />
            Save to History
          </button>
        )}
        <button
          onClick={() => {
            const dataStr = JSON.stringify(results, null, 2);
            const blob = new Blob([dataStr], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `bioclock-results-${new Date().toISOString().split('T')[0]}.json`;
            a.click();
          }}
          className="btn-secondary"
        >
          <Download className="w-4 h-4 mr-2" />
          Export Results
        </button>
      </div>
    </div>
  );
}
