'use client';

import { useState } from 'react';
import { Calculator, RotateCcw, User, FlaskConical, Droplets, Heart } from 'lucide-react';
import BiomarkerInput from './BiomarkerInput';
import { BIOMARKER_INFO, PHENOAGE_REQUIRED_BIOMARKERS } from '@/lib/clocks/biomarkers';
import { UnitSystem, BiomarkerInput as BiomarkerInputType } from '@/lib/clocks/types';

interface BiomarkerFormProps {
  onCalculate: (data: BiomarkerInputType, unitSystem: UnitSystem) => void;
  isCalculating: boolean;
}

interface FormValues {
  chronologicalAge: string;
  sex: 'male' | 'female';
  whiteBloodCellCount: string;
  lymphocytePercent: string;
  meanCellVolume: string;
  redCellDistributionWidth: string;
  albumin: string;
  creatinine: string;
  glucose: string;
  alkalinePhosphatase: string;
  cReactiveProtein: string;
  bloodUreaNitrogen: string;
  totalCholesterol: string;
  systolicBloodPressure: string;
}

const initialValues: FormValues = {
  chronologicalAge: '',
  sex: 'male',
  whiteBloodCellCount: '',
  lymphocytePercent: '',
  meanCellVolume: '',
  redCellDistributionWidth: '',
  albumin: '',
  creatinine: '',
  glucose: '',
  alkalinePhosphatase: '',
  cReactiveProtein: '',
  bloodUreaNitrogen: '',
  totalCholesterol: '',
  systolicBloodPressure: '',
};

export default function BiomarkerForm({ onCalculate, isCalculating }: BiomarkerFormProps) {
  const [values, setValues] = useState<FormValues>(initialValues);
  const [unitSystem, setUnitSystem] = useState<UnitSystem>('us');
  const [errors, setErrors] = useState<Partial<Record<keyof FormValues, string>>>({});

  const updateValue = (field: keyof FormValues, value: string) => {
    setValues(prev => ({ ...prev, [field]: value }));
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: undefined }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Partial<Record<keyof FormValues, string>> = {};

    // Check chronological age
    const age = parseFloat(values.chronologicalAge);
    if (!values.chronologicalAge || isNaN(age)) {
      newErrors.chronologicalAge = 'Age is required';
    } else if (age < 20 || age > 120) {
      newErrors.chronologicalAge = 'Age must be between 20 and 120';
    }

    // Check required PhenoAge biomarkers
    const requiredFields: (keyof FormValues)[] = [
      'whiteBloodCellCount',
      'lymphocytePercent',
      'meanCellVolume',
      'redCellDistributionWidth',
      'albumin',
      'creatinine',
      'glucose',
      'alkalinePhosphatase',
      'cReactiveProtein',
    ];

    requiredFields.forEach(field => {
      const val = parseFloat(values[field]);
      if (!values[field] || isNaN(val)) {
        newErrors[field] = 'This field is required';
      } else if (val <= 0) {
        newErrors[field] = 'Value must be positive';
      }
    });

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) return;

    const biomarkerData: BiomarkerInputType = {
      chronologicalAge: parseFloat(values.chronologicalAge),
      sex: values.sex,
      whiteBloodCellCount: parseFloat(values.whiteBloodCellCount),
      lymphocytePercent: parseFloat(values.lymphocytePercent),
      meanCellVolume: parseFloat(values.meanCellVolume),
      redCellDistributionWidth: parseFloat(values.redCellDistributionWidth),
      albumin: parseFloat(values.albumin),
      creatinine: parseFloat(values.creatinine),
      glucose: parseFloat(values.glucose),
      alkalinePhosphatase: parseFloat(values.alkalinePhosphatase),
      cReactiveProtein: parseFloat(values.cReactiveProtein),
      bloodUreaNitrogen: values.bloodUreaNitrogen ? parseFloat(values.bloodUreaNitrogen) : undefined,
      totalCholesterol: values.totalCholesterol ? parseFloat(values.totalCholesterol) : undefined,
      systolicBloodPressure: values.systolicBloodPressure ? parseFloat(values.systolicBloodPressure) : undefined,
    };

    onCalculate(biomarkerData, unitSystem);
  };

  const handleReset = () => {
    setValues(initialValues);
    setErrors({});
  };

  const loadSampleData = () => {
    // Sample data for a healthy 45-year-old (US units)
    setValues({
      chronologicalAge: '45',
      sex: 'male',
      whiteBloodCellCount: '6.2',
      lymphocytePercent: '32',
      meanCellVolume: '89',
      redCellDistributionWidth: '12.8',
      albumin: '4.3',
      creatinine: '0.95',
      glucose: '92',
      alkalinePhosphatase: '65',
      cReactiveProtein: '0.12',
      bloodUreaNitrogen: '14',
      totalCholesterol: '185',
      systolicBloodPressure: '118',
    });
    setUnitSystem('us');
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Unit System Toggle */}
      <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl">
        <span className="text-sm font-medium text-slate-700">Unit System</span>
        <div className="flex rounded-lg bg-white border border-slate-200 p-1">
          <button
            type="button"
            onClick={() => setUnitSystem('us')}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
              unitSystem === 'us'
                ? 'bg-primary-600 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            US (mg/dL)
          </button>
          <button
            type="button"
            onClick={() => setUnitSystem('si')}
            className={`px-4 py-1.5 text-sm font-medium rounded-md transition-colors ${
              unitSystem === 'si'
                ? 'bg-primary-600 text-white'
                : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            SI (mmol/L)
          </button>
        </div>
      </div>

      {/* Demographics */}
      <div className="card">
        <div className="card-header flex items-center gap-2">
          <User className="w-5 h-5 text-primary-600" />
          <h3 className="font-semibold text-slate-900">Demographics</h3>
        </div>
        <div className="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="input-label">
              Age <span className="text-red-500">*</span>
            </label>
            <input
              type="number"
              value={values.chronologicalAge}
              onChange={(e) => updateValue('chronologicalAge', e.target.value)}
              placeholder="Enter your age"
              className={`input-field ${errors.chronologicalAge ? 'border-red-300' : ''}`}
            />
            {errors.chronologicalAge && (
              <p className="mt-1 text-xs text-red-500">{errors.chronologicalAge}</p>
            )}
          </div>
          <div>
            <label className="input-label">
              Biological Sex <span className="text-red-500">*</span>
            </label>
            <div className="flex gap-4 mt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="sex"
                  value="male"
                  checked={values.sex === 'male'}
                  onChange={() => updateValue('sex', 'male')}
                  className="w-4 h-4 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-slate-700">Male</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  name="sex"
                  value="female"
                  checked={values.sex === 'female'}
                  onChange={() => updateValue('sex', 'female')}
                  className="w-4 h-4 text-primary-600 focus:ring-primary-500"
                />
                <span className="text-slate-700">Female</span>
              </label>
            </div>
          </div>
        </div>
      </div>

      {/* CBC Biomarkers */}
      <div className="card">
        <div className="card-header flex items-center gap-2">
          <Droplets className="w-5 h-5 text-red-500" />
          <h3 className="font-semibold text-slate-900">Complete Blood Count (CBC)</h3>
        </div>
        <div className="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.whiteBloodCellCount}
            value={values.whiteBloodCellCount}
            onChange={(v) => updateValue('whiteBloodCellCount', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.whiteBloodCellCount}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.lymphocytePercent}
            value={values.lymphocytePercent}
            onChange={(v) => updateValue('lymphocytePercent', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.lymphocytePercent}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.meanCellVolume}
            value={values.meanCellVolume}
            onChange={(v) => updateValue('meanCellVolume', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.meanCellVolume}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.redCellDistributionWidth}
            value={values.redCellDistributionWidth}
            onChange={(v) => updateValue('redCellDistributionWidth', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.redCellDistributionWidth}
          />
        </div>
      </div>

      {/* Metabolic Panel */}
      <div className="card">
        <div className="card-header flex items-center gap-2">
          <FlaskConical className="w-5 h-5 text-blue-500" />
          <h3 className="font-semibold text-slate-900">Metabolic Panel (CMP)</h3>
        </div>
        <div className="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.albumin}
            value={values.albumin}
            onChange={(v) => updateValue('albumin', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.albumin}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.creatinine}
            value={values.creatinine}
            onChange={(v) => updateValue('creatinine', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.creatinine}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.glucose}
            value={values.glucose}
            onChange={(v) => updateValue('glucose', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.glucose}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.alkalinePhosphatase}
            value={values.alkalinePhosphatase}
            onChange={(v) => updateValue('alkalinePhosphatase', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.alkalinePhosphatase}
          />
        </div>
      </div>

      {/* Inflammation Marker */}
      <div className="card">
        <div className="card-header flex items-center gap-2">
          <Heart className="w-5 h-5 text-orange-500" />
          <h3 className="font-semibold text-slate-900">Inflammation & Additional Markers</h3>
        </div>
        <div className="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.cReactiveProtein}
            value={values.cReactiveProtein}
            onChange={(v) => updateValue('cReactiveProtein', v)}
            unitSystem={unitSystem}
            sex={values.sex}
            required
            error={errors.cReactiveProtein}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.bloodUreaNitrogen}
            value={values.bloodUreaNitrogen}
            onChange={(v) => updateValue('bloodUreaNitrogen', v)}
            unitSystem={unitSystem}
            sex={values.sex}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.totalCholesterol}
            value={values.totalCholesterol}
            onChange={(v) => updateValue('totalCholesterol', v)}
            unitSystem={unitSystem}
            sex={values.sex}
          />
          <BiomarkerInput
            biomarker={BIOMARKER_INFO.systolicBloodPressure}
            value={values.systolicBloodPressure}
            onChange={(v) => updateValue('systolicBloodPressure', v)}
            unitSystem={unitSystem}
            sex={values.sex}
          />
        </div>
      </div>

      {/* Actions */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          type="submit"
          disabled={isCalculating}
          className="btn-primary flex-1"
        >
          {isCalculating ? (
            <>
              <svg className="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Calculating...
            </>
          ) : (
            <>
              <Calculator className="w-4 h-4 mr-2" />
              Calculate Biological Age
            </>
          )}
        </button>
        <button
          type="button"
          onClick={handleReset}
          className="btn-secondary"
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Reset
        </button>
        <button
          type="button"
          onClick={loadSampleData}
          className="btn-outline"
        >
          Load Sample
        </button>
      </div>
    </form>
  );
}
